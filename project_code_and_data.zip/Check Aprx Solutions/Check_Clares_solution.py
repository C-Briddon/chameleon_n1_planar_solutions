#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jul 20 12:02:46 2026

@author: chad-briddon

Test approximate analytic solution from "https://arxiv.org/pdf/1604.00342".

*This code ran using SELCIE v2.0.0.

"""

import numpy as np
import matplotlib.pyplot as plt

from SELCIE.Solvers import Chameleon
from SELCIE.Mesh import MeshingTools_1D
from scipy.optimize import minimize_scalar


' --------------------------------------------------------------------------- '
' ---------------------------- Define parameters ---------------------------- '
' --------------------------------------------------------------------------- '


alpha = 1e-20
n = 1
P_V = 1
P_L = 1e16
P_R = 1e14


R1 = 0.5
R2 = 1

R_right = R1 + 1
vac_centre = R1 + 0.5
X_max = R_right + R2

z = np.linspace(0, X_max, 10001)
alphas = 10**np.linspace(10, 20, 41)

phiL = 1/np.sqrt(P_L)
phiR = 1/np.sqrt(P_R)


' -------------------------------------------------------------------------- '
' ------------------------- Functions for numerics ------------------------- '
' -------------------------------------------------------------------------- '


def create_mesh_parellel_plates(show_mesh=True):

    filename = "parellel_plates"

    # Make mesh.
    MT = MeshingTools_1D(display_messages=False)

    plate_L = MT.create_1D_line(0, R1)
    MT.create_subdomain(CellSizeMin=1e-6, CellSizeMax=0.001, DistMin=0.0,
                        DistMax=0.2)

    vac = MT.create_1D_line(R1-0.01, R_right, embed=plate_L)
    MT.create_subdomain(CellSizeMin=1e-6, CellSizeMax=0.001, DistMin=0.0,
                        DistMax=0.2)

    MT.create_1D_line(R_right-0.01, X_max, embed=plate_L+vac)
    MT.create_subdomain(CellSizeMin=1e-6, CellSizeMax=0.001, DistMin=0.0,
                        DistMax=0.2)

    MT.generate_mesh(filename, show_mesh)
    MT.msh_2_xdmf(filename, auto_override=True)

    return filename


def vac(x):
    return P_V


def left(x):
    return P_L


def right(x):
    return P_R


' -------------------------------------------------------------------------- '
' ------------------- Three-layer case (parallel plates) ------------------- '
' -------------------------------------------------------------------------- '


mesh_name = create_mesh_parellel_plates(show_mesh=False)


z0_list = []
phi0_list = []

for alpha in alphas:

    s = Chameleon(alpha, n=1, mesh_name=mesh_name, dimension=1,
                  symmetry="translation symmetry")

    s.solve_static(density_profiles=[left, vac, right], tol_du=1e-12,
                   maxiter=100)

    field = np.array([s.field(zi, 0) for zi in z])

    # Find maximum of field.
    f_min = minimize_scalar(fun=lambda x: -s.field(x, 0),
                            bounds=(R1, R_right))

    z0_list.append(f_min.x)
    phi0_list.append(abs(f_min.fun))

    ' ---------------------------------------------------------------------- '
    ' ------------------------ Plot field if wanted ------------------------ '
    ' ---------------------------------------------------------------------- '

    if True:
        fig, ax = plt.subplots(figsize=(8, 6))
        ax.set_ylabel(r"$\phi/\phi_V$")
        ax.set_xlabel("$z/L$")
        ax.set_xlim([0, X_max])

        # Fill in mirror regions.
        ax.axvspan(0, R1, alpha=0.4)
        ax.axvspan(R_right, X_max, alpha=0.4)

        ax.axhline(phiL, linestyle="dashed", color="r")
        ax.axhline(phiR, linestyle="dashed", color="r")

        ax.plot(z, field, linestyle="solid", color="k")
        ax.plot([f_min.x], [-f_min.fun], "r.")

        plt.show()


' --------------------------------------------------------------------------- '
' ---------------------------- Plot change in z0 ---------------------------- '
' --------------------------------------------------------------------------- '

z0 = np.array(z0_list)
phi0 = np.array(phi0_list)

U = phi0/phiL

A = (np.sqrt(2*alphas)/3)*phiL**1.5
B = (3*np.pi/4)*U**1.5
C1 = (2/(np.sqrt(5)-1))
C2 = 2

func1 = R1 + A*(B - C1)
func2 = R1 + A*(B - C2)

c = (B - (z0 - R1)/A)**(2/3)


# Plot for z0's.
fig1, ax1 = plt.subplots(figsize=(8, 6))
ax1.set_ylabel(r"$z_0$")
ax1.set_xlabel(r"$\alpha$")

ax1.set_yscale('log')
ax1.set_xscale('log')

ax1.plot(alphas, z0)
ax1.plot(alphas, func1, linestyle="dashed", label=r"$c=\frac{2}{\sqrt{5}-1}$")
ax1.plot(alphas, func2, linestyle="dashdot", label="$c=2^{3/2}$")

ax1.legend()
plt.show()


# Plot for constant c.
fig2, ax2 = plt.subplots(figsize=(8, 6))
ax2.set_ylabel(r"$c$")
ax2.set_xlabel(r"$\alpha$")

# ax2.set_yscale('log')
ax2.set_xscale('log')

ax2.axhline(C1, label="C1", color="r")
ax2.axhline(C2, label="C2", color="k")

ax2.plot(alphas, c)

ax2.legend()
plt.show()


# Plot phi0's.
fig3, ax3 = plt.subplots(figsize=(8, 6))
ax3.set_ylabel(r"$\phi_L/\phi_0$")
ax3.set_xlabel(r"$\alpha$")

ax3.set_yscale('log')
ax3.set_xscale('log')

ax3.plot(alphas, 1/U)

plt.show()
