#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 11 22:13:08 2026

@author: chad-briddon

Check integral solution for profile that passes through VEV.

"""

import numpy as np
import matplotlib.pyplot as plt

from scipy.special import ellipj, ellipk, ellipkinc


if True:

    c = 10

    def func(x):
        return 1/np.sqrt(c**2 + ((1-x)**2)/x)

    x = np.linspace(1, 10, 10001)
    y = func(x)

    plt.figure()
    plt.xlabel("x")
    plt.ylabel("f(x)")
    plt.plot(x, y)

    ' ----------------------------------------------------------------------- '

    I_num = np.array([np.trapz(y[:i], x[:i]) for i, _ in enumerate(y)])

    plt.figure()
    plt.xlabel("x")
    plt.ylabel("I")
    plt.plot(x, I_num, label="num")

    def solution(c, x):
        mu2 = 1 - 4/c**2

        y = 1 - 2/(1+x)
        u = ellipkinc(np.arcsin(y), mu2)

        # E = ellipeinc(u, mu2)
        sn, cn, dn, _ = ellipj(u, mu2)
        dc = dn/cn

        # Sc = (sn*dc - E)/(1 - mu2)

        Sc_list = []
        for ui in u:
            X = np.linspace(0, ui, 1000)
            sn_, cn_, _, _ = ellipj(X, mu2)
            sc_ = sn_/cn_
            Sc_list.append(np.trapz(sc_**2, X))
        Sc = np.array(Sc_list)
        print(Sc)

        return (2/c)*(u + 2*Sc) + (c)*(dc - 1)

    y_2 = solution(c, x)

    plt.plot(x, y_2, label="Anal")
    plt.legend()


' --------------------------------------------------------------------------- '
' --------------------------------------------------------------------------- '

# Test each section of derivation.

if True:
    ' Returns same. Thi section is correct.'
    k2 = 0.5

    K_k = ellipk(k2)
    u = np.linspace(0, K_k/2, 1000)

    # dc().
    sn, cn, dn, _ = ellipj(u, 1 - k2)
    dc = dn/cn

    # Equiv.
    phi = np.arctanh(sn)
    y = np.sqrt(1 + k2*np.sinh(phi)**2)

    # Plot.
    plt.figure()
    plt.plot(u, dc, label="dn(u|m)")
    plt.plot(u, y, label="equiv")

    plt.legend()

if False:
    c = 0.1
    k = 2/c
    k2 = k**2

    K_k = ellipk(k2)
    x = np.linspace(0, 1000, 100000)

    y = 1 - 2/(1+x)
    u = ellipkinc(np.arcsin(y), 1 - k2)

    # dc().
    sn, cn, dn, _ = ellipj(u, 1 - k2)
    cd = cn/dn

    # Equiv.
    y = c/np.sqrt(c**2 + ((x-1)**2)/x)

    # Plot.
    plt.figure()
    plt.plot(u, cd, label="dn(u|m)")
    plt.plot(u, y, label="equiv")

    plt.legend()
