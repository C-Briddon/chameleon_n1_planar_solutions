#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 18 13:47:26 2025

@author: chad-briddon

*This code ran using SELCIE v2.0.0.

"""

import numpy as np
import matplotlib.pyplot as plt

from scipy.special import ellipj

from SELCIE.Mesh import MeshingTools_1D
from SELCIE.Solvers import Chameleon

from General_solution import Sn, inverse_Sn
from General_solution import Chameleon_Parallel_Plates_Solution


' -------------------------------------------------------------------------- '
' ---------------------- Functions for wrong solution ---------------------- '
' -------------------------------------------------------------------------- '


def field_ivanov(z, k):

    Ls = np.sqrt(2*alpha*(k**3))

    y = Sn(np.pi/2, k) - abs(z)/Ls

    theta = inverse_Sn(y, k)

    field = k*np.sin(theta)**2

    return field


' -------------------------------------------------------------------------- '
' ------------------------- Functions for numerics ------------------------- '
' -------------------------------------------------------------------------- '


def create_mesh_parellel_plates(show_mesh=True):

    filename = "parellel_plates"

    # Make mesh.
    MT = MeshingTools_1D(display_messages=False)

    plate_L = MT.create_1D_line(-1.6, -0.5)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.010, DistMin=0.0,
                        DistMax=0.1)

    plate_R = MT.create_1D_line(0.5, 2.6)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.010, DistMin=0.0,
                        DistMax=0.1)

    MT.create_1D_line(-0.51, 0.51,
                      embed=plate_L+plate_R)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.05,
                        DistMax=0.1)

    MT.generate_mesh(filename, show_mesh)
    MT.msh_2_xdmf(filename, auto_override=True)

    return filename


def make_density_func(p):

    def f(x):
        return p

    return f


def solve_numc():

    mesh_name = create_mesh_parellel_plates(show_mesh=False)

    left = make_density_func(P_L)
    right = make_density_func(P_R)
    vacuum = make_density_func(P_V)

    s = Chameleon(alpha, n=1, mesh_name=mesh_name, dimension=1,
                  symmetry="translation symmetry")

    s.solve_static(density_profiles=[left, right, vacuum], tol_du=1e-12)

    return np.array([s.field(zi, 0) for zi in z])


' -------------------------------------------------------------------------- '
' ------------------- Function of first order correction ------------------- '
' -------------------------------------------------------------------------- '


def first_order_correction(field, k):

    x = field/k

    y1 = np.pi/(2*x)

    y2 = np.arcsin(np.sqrt(x))

    y3 = np.sqrt(x*(1 - x))

    return 0.5*(k**2)*y3*(y1 - y2 + y3)


' -------------------------------------------------------------------------- '
' -------------------------- Make comparison plot -------------------------- '
' -------------------------------------------------------------------------- '


P_R = 1e10
P_L = 1e10
P_V = 1

z = np.linspace(-0.5, 0.5, 1000)

omega_L = np.sqrt(P_V/P_L)
omega_R = np.sqrt(P_V/P_R)

compton_wl = [3, 3e2, 1.1e4]
compton_wl = [10.02805, 3.183e2, 1.008e4]


# Create figure for field profiles.
fig1, ax1 = plt.subplots(figsize=(8, 6))
ax1.set_ylabel(r"$\hat{\phi}/k$")
ax1.set_xlabel(r"$z$")

ax1.set_xlim([-0.5, +0.5])
# ax1.set_yscale("log")


# Create figure for differences.
fig2, ax2 = plt.subplots(ncols=2, sharey=True, figsize=(8, 6))

ax2[0].set_xlabel(r"$z$")
ax2[0].set_ylabel(r"$\left| x - x^* \right|$")

ax2[1].set_xlabel(r"$z$")
ax2[1].set_ylabel(r"$\left| \delta \right|$")


ax2[0].set_xlim([0.0, 0.5])
ax2[1].set_xlim([0.0, 0.5])

ax2[0].set_ylim([1e-14, 1])
ax2[1].set_ylim([1e-14, 1])

ax2[0].set_yscale("log")


# Iterate.
c = ["b", "r", "orange"]

for lam, ci in zip(compton_wl[1:], c[1:]):

    alpha = 2*lam**2

    C = Chameleon_Parallel_Plates_Solution(omega_L, omega_R, alpha, L=1)
    k = C.get_k(0.00714)

    f_me = C.field_profile(z, k)
    f_ivanov = field_ivanov(z, k)
    # f_numc = solve_numc()

    # Plot.
    ax1.plot(z, f_me/k, color=ci, linestyle="solid",
             label=r"$k = %.3f$" % k)
    ax1.plot(z, f_ivanov/k, color=ci, linestyle="dashed",
             label=r"$k = %.3f$" % k)
    # plt.plot(z, f_numc, label="numc")

    # Plot difference.
    diff_numc = f_me - f_ivanov
    diff_anal = first_order_correction(f_me, k)

    ax2[0].plot(z, abs(diff_numc), color=ci, linestyle="solid",
                label=r"$k = %.3f$" % k)
    ax2[1].plot(z, abs(diff_anal), color=ci, linestyle="dashed",
                label=r"$k = %.3f$" % k)

    # Plot residual to k^4.
    '''
    delta_4 = abs(f_me - f_ivanov - first_order_correction(f_me, k))

    plt.figure()
    plt.ylabel(r"$\delta^{(4)}$")
    plt.xlabel(r"$z$")

    plt.xlim([-0.5, 0.5])

    plt.yscale("log")

    plt.plot(z, delta_4)
    '''
    # break

ax1.legend()
ax2[0].legend(loc="upper left")
ax2[1].legend(loc="upper left")

# fig1.savefig("Plots/solution_error", dpi=300, bbox_inches='tight')
# fig2.savefig("Plots/solution_error_difference", dpi=300, bbox_inches='tight')


' -------------- Check error regarding arguments of sin and sn -------------- '


def sn(u, m):
    return ellipj(u, m**2)[0]


def inverse_sn(y, k, range_=(0, np.pi/2)):
    'Since sn is monotoic function, use bisection method to find its inverse.'
    'Find f(x) = Sn(x, k) - y = 0.'

    inv = []
    for yi in y:

        a, b = range_
        while b-a > 1e-10:

            c = (b+a)/2

            if sn(c, k) - yi > 0:
                b = c
            else:
                a = c

        inv.append(c)

    return np.array(inv)


theta_0 = np.arcsin(np.sqrt(f_ivanov))
theta_1 = inverse_sn(np.sqrt(f_me), k)

fig3, ax3 = plt.subplots(figsize=(8, 6))

ax3.set_xlabel(r"$z$")
# ax3.set_ylabel(r"$\left| x - x^* \right|$")

ax3.set_xlim([0.0, 0.5])

ax3.set_yscale("log")

ax3.plot(z, abs(theta_0), color="r", linestyle="solid", label="Ivanov")
ax3.plot(z, abs(theta_1), color="k", linestyle="dashed", label="me")

ax3.legend()


# Plot difference.
fig4, ax4 = plt.subplots(figsize=(8, 6))

ax4.set_xlabel(r"$z$")
# ax4.set_ylabel(r"$\left| x - x^* \right|$")

ax4.set_xlim([0.0, 0.5])

ax4.set_yscale("log")

ax4.plot(z, abs(theta_0 - theta_1), color="r", linestyle="solid")

# ax4.legend()
