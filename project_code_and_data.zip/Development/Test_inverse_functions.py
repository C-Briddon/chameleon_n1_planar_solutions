#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb 28 22:58:14 2026

@author: chad-briddon

Test inverse functions.

"""

import numpy as np
import matplotlib.pyplot as plt

from scipy.special import ellipj
from scipy.special import ellipk as K
from scipy.special import ellipkinc as F
from scipy.special import ellipeinc as E


def sn(u, m):
    return ellipj(u, m)[0]


def ns(u, m):
    return 1/ellipj(u, m)[0]


def sn_Inverse(u, m):
    return F(np.arcsin(u), m)


def ns_Inverse(u, m):
    return F(np.arcsin(1/u), m)


def Sn(u, m):
    '''
    Use identity in 'Handbook of Mathematical Functions With Formulas, Graphs,
    and Mathematical Tables', Eq. 16.26.1.'

    '''

    ph = ellipj(u, m)[3]

    return (u - E(ph, m))/m


def Ns(u, m):
    '''
    Use identity in 'Handbook of Mathematical Functions With Formulas, Graphs,
    and Mathematical Tables', Eq. 16.26.10.'

    '''

    sn, cn, dn, ph = ellipj(u, m)

    return u - E(ph, m) - cn*dn/sn


def Sn_Inverse(y, m):
    '''
    Inverse of function Sn(u, m). Obtained using bisection method.

    '''

    inv = []
    for yi in y:

        a, b = 0, K(m)+1e-14
        while abs(b-a) > 1e-14:

            c = (b+a)/2

            if Sn(c, m) > yi:
                b = c
            else:
                a = c

        inv.append((a+b)/2)

    inverse = np.array(inv)

    return inverse


def Ns_Inverse(y, m):
    '''
    Inverse of function Ns(u, m). Obtained using bisection method.

    '''

    inv = []
    for yi in y:

        a, b = 0, K(m)+1e-14
        while abs(b-a) > 1e-14:

            c = (b+a)/2

            if Ns(c, m) > yi:
                b = c
            else:
                a = c

        inv.append((a+b)/2)

    inverse = np.array(inv)

    return inverse


' -------------------------------- Check sn -------------------------------- '

if False:
    m = 0.5

    u = np.linspace(0, K(m), 10001)
    y = sn(u, m)

    plt.figure()
    plt.plot(u, y)

    x = sn_Inverse(y, m)

    plt.figure()
    plt.plot(u, x)

    print(max(abs(u-x)))


' -------------------------------- Check Sn -------------------------------- '

if False:
    m = 0.5

    u = np.linspace(0, K(m), 1000)
    y = Sn(u, m)

    plt.figure()
    plt.plot(u, y)

    x = Sn_Inverse(y, m)

    # plt.figure()
    plt.plot(u, x)

    print(max(abs(u-x)))
    print(sn(Sn_Inverse([Sn(K(m), m)], m), m))


' -------------------------------- Check ns -------------------------------- '

if False:
    m = 0.5

    u = np.linspace(0, K(m), 1000)
    y = ns(u, m)

    plt.figure()
    plt.plot(u, y)

    x = ns_Inverse(y, m)

    # plt.figure()
    plt.plot(u, x)

    print(max(abs(u-x)))


' -------------------------------- Check Ns -------------------------------- '

if False:
    m = 0.5

    u = np.linspace(0.1, K(m), 1000)
    y = Ns(u, m)

    plt.figure()
    plt.plot(u, y)

    x = Ns_Inverse(y, m)

    # plt.figure()
    plt.plot(u, x)

    print(max(abs(u-x)))
    print(ns(Ns_Inverse([Ns(K(m), m)], m), m))
