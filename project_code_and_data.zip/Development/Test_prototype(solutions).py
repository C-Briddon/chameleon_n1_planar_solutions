#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Mar  1 18:08:23 2026

@author: chad-briddon

Use SELCIE to check all four solution types. Check functions in
'_prototype_for_general_solver.py' work for all allowed values.

*This code ran using SELCIE v2.0.0.

"""

import numpy as np
import matplotlib.pyplot as plt

from SELCIE.Solvers import Chameleon
from SELCIE.Mesh import MeshingTools_1D

from _prototype_for_general_solver import exterior, interior

z_L = -1.1
z_R = +0.1


def create_mesh():

    filename = "single_region"

    MT = MeshingTools_1D(display_messages=False)

    MT.create_1D_line(x_start=z_L, x_end=z_R)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=1e-3, DistMax=0.5)

    MT.generate_mesh(filename, show_mesh=False)
    MT.msh_2_xdmf(filename, auto_override=True)

    return None


def create_func(value):
    def f(x):
        return value
    return f


def create_initial(field_L, field_R):
    def f(x):
        z = x[0]
        m = (field_R - field_L)/(z_R - z_L)
        return m*(z - z_L) + field_L
    return f


def create_initial_ext(z_b, field_b):
    def f(x):
        z = x[0]
        ext = exterior(field_VEV, compton_WL, z_b, field_b)
        return ext(z)
    return f


def left(x):
    return x[0] < z_L + 1e-6


def right(x):
    return x[0] > z_R - 1e-6


create_mesh()


' -------------------------------- Exterior -------------------------------- '
# Passed.
if True:
    compton_WL = 0.05
    field_L = 2.0
    field_R = 1.0

    alpha = 2*compton_WL**2  # Set length scale to 1.
    background = create_func(1.0)  # sets field_VEV = 1.
    field_VEV = 1

    # Compute with SELCIE.
    s = Chameleon(alpha=alpha, n=1, mesh_name="single_region", dimension=1,
                  symmetry="translation symmetry")

    # initial = create_initial(field_L, field_R)
    initial = create_initial_ext(z_R, field_R)
    BC = ('Dirichlet', create_func(field_R), right)

    initial = create_initial_ext(z_L, field_L)
    BC = ('Dirichlet', create_func(field_L), left)

    s.solve_static(density_profiles=[background],
                   initial_field_profiles=[initial],
                   BoundaryConditions=[BC],
                   tol_du=1e-12, maxiter=0)

    # Get analytic profile and compare with plots.
    x = np.linspace(z_L, z_R, 1001)

    field_numc = np.array([s.field(xi, 0) for xi in x])

    func = exterior(field_VEV, compton_WL, z_R, field_R)
    func = exterior(field_VEV, compton_WL, z_L, field_L)

    field_anal = np.array([func(xi) for xi in x])

    plt.figure()
    plt.plot(x, field_numc, label="Numeric", linestyle="solid")
    plt.plot(x, field_anal, label="Analytic", linestyle="dashed")
    plt.legend()

    plt.figure()
    plt.plot(x, abs(field_anal - field_numc))


' -------------------------------- Interior -------------------------------- '


def find_root(field, range_):
    a, b = range_

    c = (a + b)/2

    while abs(b-a) > 1e-14:

        c = (b+a)/2

        if field(c, 0) > 1:
            b = c
        else:
            a = c

    return (a + b)/2


# Passed.
if False:
    compton_WL = 7
    field_L = 1.1
    field_R = 0.8

    alpha = 2*compton_WL**2  # Set length scale to 1.
    background = create_func(1.0)  # sets field_VEV = 1.
    field_VEV = 1

    # Compute with SELCIE.
    s = Chameleon(alpha=alpha, n=1, mesh_name="single_region", dimension=1,
                  symmetry="translation symmetry")

    initial = create_initial(field_L, field_R)
    BC = [('Dirichlet', create_func(field_R), right),
          ('Dirichlet', create_func(field_L), left)]

    s.solve_static(density_profiles=[background],
                   initial_field_profiles=[initial],
                   BoundaryConditions=BC,
                   tol_du=1e-10, maxiter=100)

    # Get curve parameter from field.
    if field_L < field_VEV and field_R < field_VEV:
        gamma = max(s.field.vector()[:])

    elif field_L > field_VEV and field_R > field_VEV:
        gamma = min(s.field.vector()[:])

    else:
        s.calc_field_grad_vector()

        # Find pos of VEV.
        z_star = find_root(s.field, range_=(z_R, z_L))
        print(z_star)
        C = compton_WL*s.field_grad(z_star, 0)[0]/2
        gamma = C

    # Get analytic profile and compare with plots.
    x = np.linspace(z_L, z_R, 1001)
    # x = np.array([-0.8])

    field_numc = np.array([s.field(xi, 0) for xi in x])

    field_func = interior(field_VEV, compton_WL, z_L, z_R, field_L, field_R,
                          gamma)

    # from scipy.special import ellipkinc as F
    # y = field_numc/field_VEV
    # u_numc = F(np.arcsin((y-1)/(y+1)), 1 - 1/gamma**2)

    field_anal = field_func(x)

    plt.figure()
    plt.plot(x, field_numc, label="Numeric", linestyle="solid")
    # plt.plot(x, u_numc, label="Numeric", linestyle="solid")
    plt.plot(x, field_anal, label="Analytic", linestyle="dashed")
    plt.legend()

    plt.plot([z_star], [field_VEV], "r.")

    plt.figure()
    plt.plot(x, abs(field_anal - field_numc))

    # print(gamma)
