#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Oct 24 12:33:56 2025

@author: chad-briddon

Test every step of derivation for correction term to find mistakes.

*This code ran using SELCIE v2.0.0.

"""

import numpy as np
import dolfin as d
import matplotlib.pyplot as plt

from scipy.special import ellipeinc
from SELCIE.Mesh import MeshingTools_1D
from SELCIE.Solvers import Chameleon


# Set parameters.
L = 1
plate_thickness = 0.1
Ps, Pv = 1e10, 1

n = 1
compton_wl_s = 0.0000001
alpha = (n+1)*(compton_wl_s**2)*(Ps**((n+2)/(n+1)))
print(np.sqrt(alpha/(n+1)))
# alpha = 100


' ---------------------------- Create functions ---------------------------- '


def create_mesh_parellel_plates(L, plate_thickness, show_mesh=True):

    filename = "parellel_plates"

    # Make mesh.
    MT = MeshingTools_1D(display_messages=False)

    plate_L = MT.create_1D_line(-plate_thickness, 0)
    plate_R = MT.create_1D_line(L, L+plate_thickness)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.010, DistMin=0.0,
                        DistMax=0.1)

    MT.create_1D_line(-plate_thickness, L+plate_thickness,
                      embed=plate_L+plate_R)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.05,
                        DistMax=0.1)

    MT.generate_mesh(filename, show_mesh)
    MT.msh_2_xdmf(filename, auto_override=True)

    return filename


def plate(x):
    return Ps


def vacuum(x):
    return Pv


def Sn(u, k):

    E = ellipeinc(u, k**2)
    Sn = (u - E)/k**2

    return Sn


def inverse_Sn(y, k, range_):
    'Since sn is monotoic function, use bisection method to find its inverse.'
    'Find f(x) = sn(x, k) - y = 0.'

    sn_inv = []
    for yi in y:

        a, b = range_
        while b-a > 1e-10:

            c = (b+a)/2

            if Sn(c, k) - yi > 0:
                b = c
            else:
                a = c

        sn_inv.append(c)

    return np.array(sn_inv)


mesh_name = create_mesh_parellel_plates(L, plate_thickness, show_mesh=False)


s = Chameleon(alpha, n, mesh_name, dimension=1,
              symmetry="translation symmetry")

s.solve_static(density_profiles=[plate, vacuum], tol_du=1e-12)

' --------------------- Compare field profiles --------------------- '

# Get analytic profile.
x = np.linspace(0, 1, 1001)
k = d.norm(s.field.vector(), 'linf')
Ls = np.sqrt(2*alpha*(k**3))

y_Anal = Sn(np.pi/2, k) - abs(1 - 2*x)/(4*Ls)

theta_Anal = inverse_Sn(y_Anal, k, range_=(0, np.pi/2))

field_Anal = k*np.sin(theta_Anal)**2

# Get Numeric profile.
field_Numc = np.array([s.field(xi, 0) for xi in x])

theta_Numc = np.arcsin(np.sqrt(field_Numc/k))

y_Numc = Sn(theta_Numc, k)


# Plot.
fig, ax = plt.subplots()
ax.set_xlabel("x")

ax.set_ylabel(r"$\Delta y = g(z)$")

ax.plot(x, y_Numc - y_Anal, linestyle="solid", label=r"$\Delta y$")

g1 = ((1 - k**2/2) - np.sqrt(1 - k**2))/(Ls*k**2)
ax.plot(x, g1*abs(x - 0.5), linestyle="dashdot", color="k",
        label="g'(0.5) |x-0.5|")
ax.legend()

plt.figure()
plt.title("Diff from linear")
plt.plot(x, y_Numc - y_Anal - g1*abs(x - 0.5))


' --------------------------------------------------------------------------- '
' --------------------------------------------------------------------------- '
k2 = k**2
X = field_Numc/k

i = ellipeinc(np.arcsin(np.sqrt(X)), k2) - ellipeinc(np.pi/2, k2) \
    - abs(1 - 2*x)/(2*Ls)

# i = -Sn(np.arcsin(np.sqrt(X)), k) + Sn(np.pi/2, k) #- abs(1 - 2*x)/(2*Ls)

plt.figure()
plt.plot(x, i)
