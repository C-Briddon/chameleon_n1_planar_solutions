#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 11 19:35:48 2026

@author: chad-briddon

Check analytic solution for when field profile passes VEV.

For identites see Handbook ... :
    https://personal.math.ubc.ca/~cbm/aands/abramowitz_and_stegun.pdf

*This code ran using SELCIE v2.0.0.

"""

import numpy as np
import matplotlib.pyplot as plt

from SELCIE.Mesh import MeshingTools_1D
from SELCIE.Solvers import Chameleon

from scipy.special import ellipj, ellipkinc


' --------------------------- Analytic functions --------------------------- '


def F(u, m):
    return ellipkinc(u, m)


def inverse_sn(u, m):
    return np.arcsin(F(u, m))


def dc(u, m):

    sn, cn, dn, _ = ellipj(u, m**2)

    return dn/cn


def sc(u, m):

    sn, cn, dn, _ = ellipj(u, m**2)

    return sn/cn


def Sc(u, k):

    t = np.linspace(0, u, 1000)
    sc2 = sc(t, k)**2

    return np.trapz(sc2, t)


def field_analytic_new(alpha, g, field):

    x = field/1

    m = np.sqrt(2/alpha)
    c = g/m

    mu2 = 1 - 4/c**2

    y = 1 - 2/(1+x)
    u = ellipkinc(np.arcsin(y), mu2)

    sn, cn, dn, _ = ellipj(u, mu2)
    dc = dn/cn

    Sc_list = []
    for ui in u:
        X = np.linspace(0, ui, 1000)
        sn_, cn_, _, _ = ellipj(X, mu2)
        sc_ = sn_/cn_
        Sc_list.append(np.trapz(sc_**2, X))
    Sc = np.array(Sc_list)

    I_anal = (2/c)*(u + 2*Sc) + (c)*(dc - 1)

    return I_anal/m


' ------------------------- Functions for numerics ------------------------- '


def create_mesh_parellel_plates(show_mesh=True):

    filename = "empty"

    # Make mesh.
    MT = MeshingTools_1D(display_messages=False)

    MT.create_1D_line(-0.5, 0.5)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.010, DistMin=0.0,
                        DistMax=0.1)

    MT.generate_mesh(filename, show_mesh)
    MT.msh_2_xdmf(filename, auto_override=True)

    return filename


def vacuum(x):
    return 1


def BC_L(x):
    return x[0] < -0.5 + 1e-5


def BC_R(x):
    return x[0] > 0.5 - 1e-5


fL = 0.1
fR = 2


def field_L(x):
    return fL


def field_R(x):
    return fR


' ------------------------ Compute numeric solution ------------------------ '

mesh_name = create_mesh_parellel_plates(show_mesh=False)

s = Chameleon(alpha=100, n=1, mesh_name=mesh_name, dimension=1,
              symmetry="translation symmetry")

s.solve_static(density_profiles=[vacuum], tol_du=1e-12,
               BoundaryConditions=[('Dirichlet', field_L, BC_L),
                                   ('Dirichlet', field_R, BC_R)])


' --------------------- Compare field profiles --------------------- '

# Get analytic profile.
x = np.linspace(-0.5, 0.5, 1001)
field_numc = np.array([s.field(xi, 0) for xi in x])

# Get location of VEV pass.
a, b = -0.5, 0.5

while b-a > 1e-10:

    c = (b+a)/2

    if s.field(c, 0) - 1 > 0:
        b = c
    else:
        a = c

zeta_0 = c

# Get gradient at zeta origin.
s.calc_field_grad_vector()
g = s.field_grad(zeta_0, 0)[0]

field_anal = np.linspace(fL, fR, 1000)
x_anal = field_analytic_new(s.alpha, g, field_anal) + zeta_0

plt.figure()
plt.axhline(1, linestyle="dashed")
plt.plot([zeta_0], [1], 'r.')
plt.plot(x, field_numc, label="Numeric", linestyle="solid")
plt.plot(x_anal, field_anal, label="Analytic", linestyle="dashed")
plt.legend()

# plt.figure()
# plt.yscale('log')
# plt.plot(x, abs(field_numc - field_anal))
