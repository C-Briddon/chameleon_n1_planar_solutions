#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 10 19:09:27 2026

@author: chad-briddon

Check analytic solution for when field profile has a minimum against numerics.

For identites see Handbook ... :
    https://personal.math.ubc.ca/~cbm/aands/abramowitz_and_stegun.pdf

*This code ran using SELCIE v2.0.0.

"""

import numpy as np
import matplotlib.pyplot as plt

from SELCIE.Mesh import MeshingTools_1D
from SELCIE.Solvers import Chameleon

from scipy.special import ellipj
from scipy.special import ellipk, ellipkinc, ellipeinc


' --------------------------- Analytic functions --------------------------- '


def K(m):
    return ellipk(m**2)


def F(u, m):
    return ellipkinc(u, m**2)


def E(u, m):
    return ellipeinc(u, m**2)


def inverse_F(y, k, range_=(0, np.pi/2)):
    'Since sn is monotoic function, use bisection method to find its inverse.'
    'Find f(x) = F(x, k) - y = 0.'

    inv = []
    for yi in y:

        a, b = range_
        while b-a > 1e-10:

            c = (b+a)/2

            if F(c, k) - yi > 0:
                b = c
            else:
                a = c

        inv.append(c)

    return np.array(inv)


def cn(u, m):
    return ellipj(u, m**2)[1]


def ns(u, m):
    return 1/ellipj(u, m**2)[0]


def Ns(u, k):

    t = np.linspace(1e-8, u, 10000)
    ns2 = ns(t, k)**2 - 1/(t**2)

    return np.trapz(ns2, t) - 1/u


def Ns_2(u, k):

    sn, cn, dn, _ = ellipj(u, k**2)

    return u - E(inverse_F([u], k), k) - cn*dn/sn


def inverse_Ns(y, k, range_=(0, 2*np.pi)):
    'Since sn is monotoic function, use bisection method to find its inverse.'
    'Find f(x) = Ns(x, k) - y = 0.'

    inv = []
    for yi in y:

        a, b = range_
        while b-a > 1e-10:

            c = (b+a)/2

            if Ns_2(c, k) - yi > 0:
                b = c
            else:
                a = c

        inv.append(c)

    return np.array(inv)


def field_analytic_new(alpha, k):

    g = 1/k

    Ls = np.sqrt(2*alpha*(k))

    y_Anal = Ns_2(K(g), g) - abs(0.5 - x)/Ls

    theta_Anal = inverse_Ns(y_Anal, g)

    field_Anal = k*ns(theta_Anal, g)**2

    return field_Anal


' ------------------------- Functions for numerics ------------------------- '


def create_mesh_parellel_plates(show_mesh=True):

    filename = "parellel_plates"

    # Make mesh.
    MT = MeshingTools_1D(display_messages=False)

    plate_L = MT.create_1D_line(-0.1, 0.0)
    plate_R = MT.create_1D_line(1.0, 1.1)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.010, DistMin=0.0,
                        DistMax=0.1)

    MT.create_1D_line(-0.1, 1.1,
                      embed=plate_L+plate_R)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.05,
                        DistMax=0.1)

    MT.generate_mesh(filename, show_mesh)
    MT.msh_2_xdmf(filename, auto_override=True)

    return filename


def plate(x):
    return 1e-2


vac = 1


def vacuum(x):
    return vac


' ------------------------ Compute numeric solution ------------------------ '

mesh_name = create_mesh_parellel_plates(show_mesh=False)

s = Chameleon(alpha=1, n=1, mesh_name=mesh_name, dimension=1,
              symmetry="translation symmetry")

s.solve_static(density_profiles=[plate, vacuum], tol_du=1e-12)


' --------------------- Compare field profiles --------------------- '

# Get analytic profile.
x = np.linspace(-0., 1.0, 1001)
field_min = min(s.field.vector()[:])
field_VEV = 1/np.sqrt(vac)

k = field_min/field_VEV


field_numc = np.array([s.field(xi, 0) for xi in x])

field_anal = field_analytic_new(s.alpha, k)

plt.figure()
plt.plot(x, field_numc, label="Numeric", linestyle="solid")
plt.plot(x, field_anal, label="Analytic", linestyle="dashed")
plt.legend()

plt.figure()
plt.yscale('log')
plt.plot(x, abs(field_numc - field_anal))
