#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 10 17:58:49 2026

@author: chad-briddon

General solver for N-layers of parallel regions of different density.

For derivations of equations used see paper :

    !!!!!# after paper is published double check Eq labels are still correct.

* Uses scipy.optimize.least_squares().
* Use linear constraint equation. Eq(48) in our paper.

"""

import numpy as np

from scipy.special import ellipj
from scipy.special import ellipk as K
from scipy.special import ellipkinc as F
from scipy.special import ellipeinc as E

from scipy.optimize import least_squares
from astropy import units, constants


' -------------------------------------------------------------------------- '
' -------------------- Define Jacobi elliptic functions -------------------- '
' -------------------------------------------------------------------------- '


def sn(u, m):
    return ellipj(u, m)[0]


def ns(u, m):
    return 1/ellipj(u, m)[0]


def nc(u, m):
    return 1/ellipj(u, m)[1]


def sd(u, m):
    sn, dn = ellipj(u, m)[::2]
    return sn/dn


def dc(u, m):
    cn, dn = ellipj(u, m)[1:3]
    return dn/cn


def sn_Inverse(u, m):
    return F(np.arcsin(u), m)


def ns_Inverse(u, m):
    return F(np.arcsin(1/u), m)


def Sn(u, m):
    '''
    Use identity in 'Handbook of Mathematical Functions With Formulas, Graphs,
    and Mathematical Tables', Eq. 16.26.1.'

    '''

    ph = ellipj(u, m)[3]

    return (u - E(ph, m))/m


def Ns(u, m):
    '''
    Use identity in 'Handbook of Mathematical Functions With Formulas, Graphs,
    and Mathematical Tables', Eq. 16.26.10.'

    '''

    sn, cn, dn, ph = ellipj(u, m)

    return u - E(ph, m) - cn*dn/sn


def Sc(u, m):
    '''
    Use identity in 'Handbook of Mathematical Functions With Formulas, Graphs,
    and Mathematical Tables', Eq. 16.26.9.'

    '''

    sn, cn, dn, ph = ellipj(u, m)

    return ((sn*dn/cn) - E(ph, m))/(1 - m)


def Sn_Inverse(y, m):
    '''
    Inverse of function Sn(u, m). Obtained using bisection method.

    '''

    if isinstance(y, float):

        a, b = 0, K(m)+1e-14

        while abs(b-a) > 1e-14:

            c = (a + b)/2

            if Sn(c, m) > y:
                b = c
            else:
                a = c

        inverse = (a + b)/2

    else:

        inv = []
        for yi in y:

            a, b = 0, K(m)+1e-14

            while abs(b-a) > 1e-14:

                c = (a + b)/2

                if Sn(c, m) > yi:
                    b = c
                else:
                    a = c

            inv.append((a + b)/2)

        inverse = np.array(inv)

    return inverse


def Ns_Inverse(y, m):
    '''
    Inverse of function Ns(u, m). Obtained using bisection method.

    '''

    if isinstance(y, float):

        a, b = 0, K(m)+1e-14

        while abs(b-a) > 1e-14:

            c = (a + b)/2

            if Ns(c, m) > y:
                b = c
            else:
                a = c

        inverse = (a + b)/2

    else:

        inv = []
        for yi in y:

            a, b = 0, K(m)+1e-14

            while abs(b-a) > 1e-14:

                c = (a + b)/2

                if Ns(c, m) > yi:
                    b = c
                else:
                    a = c

            inv.append((a + b)/2)

        inverse = np.array(inv)

    return inverse


' -------------------------------------------------------------------------- '
' ------------------- Define solutions for each scenario ------------------- '
' -------------------------------------------------------------------------- '


def exterior(field_VEV, compton_WL, z_boundary, field_boundary):
    '''
    Generate solution inside exterior regions, see Eq.~(9).

    Parameters
    ----------
    field_VEV : float
        VEV corresponding to region.
    compton_WL : float
        Compton wavelength corresponding to field VEV.
    z_boundary : float
        Location of the boundary.
    field_boundary : float
        Value of field at boundary.
    z : float
        Position value.

    Returns
    -------
    field : float
        Field value in exterior at position z.

    '''

    x_b = np.sqrt(field_boundary/field_VEV)  # Rescaled.

    constant = np.exp(2*x_b)*(x_b - 1)/(x_b + 1)

    def f(z):

        # Use Bisection method to invert function.
        a = min(1, x_b)
        b = max(1, x_b)

        def residual_ext(x):
            return (np.exp(2*x)*(x - 1)/(x + 1)
                    - constant*np.exp(-abs(z-z_boundary)/compton_WL))

        while abs(b-a) > 1e-14:

            c = (b+a)/2

            if residual_ext(c) > 0:
                b = c
            else:
                a = c

        x = (b+a)/2

        return field_VEV*x**2

    return f


def interior(field_VEV, compton_WL, z_boundary_L, z_boundary_R,
             field_boundary_L, field_boundary_R, gamma):

    L_i = z_boundary_R - z_boundary_L
    z_c = (z_boundary_R + z_boundary_L)/2  # Centre coordinate.

    if field_boundary_L < field_VEV and field_boundary_R < field_VEV:
        ' ---- Scenario : extrema (maximum) ---- '

        k2 = gamma**2
        L_c = 2*compton_WL*gamma**1.5

        x_L = field_boundary_L/(field_VEV*gamma)
        x_R = field_boundary_R/(field_VEV*gamma)

        # Calculate x_c.
        Sn_K = Sn(K(k2), k2)
        x_c = sn(Sn_Inverse(Sn_K - (L_i/L_c), k2), k2)**2

        # Calculate z_0.
        if min(x_L, x_R) > x_c:
            # Maximum occurs inside region.
            z_0 = (Sn(sn_Inverse(np.sqrt(x_L), k2), k2) -
                   Sn(sn_Inverse(np.sqrt(x_R), k2), k2))/2
        else:
            # Maximum occurs outside region (is fictitious).
            z_0 = Sn_K - (Sn(sn_Inverse(np.sqrt(x_L), k2), k2) +
                          Sn(sn_Inverse(np.sqrt(x_R), k2), k2))/2

            # Get correct sign.
            if x_L < x_R:
                z_0 *= -1
            else:
                pass

        # Give field profile as a callable function.
        def f(z):
            zprime = z - z_c
            return field_VEV*gamma*sn(Sn_Inverse(
                Sn_K - abs((zprime/L_c) + z_0), k2), k2)**2

    elif field_boundary_L > field_VEV and field_boundary_R > field_VEV:
        ' ---- Scenario : extrema (minimum) ---- '

        g2 = 1/gamma**2  # use g := 1/k.
        L_c = 2*compton_WL*np.sqrt(gamma)

        x_L = field_boundary_L/(field_VEV*gamma)
        x_R = field_boundary_R/(field_VEV*gamma)

        # Calculate x_c.
        Ns_K = Ns(K(g2), g2)
        x_c = ns(Ns_Inverse(Ns_K - (L_i/L_c), g2), g2)**2

        # Calculate z_0.
        if max(x_L, x_R) < x_c:
            # Minimum occurs inside region.
            z_0 = (Ns(ns_Inverse(np.sqrt(x_L), g2), g2) -
                   Ns(ns_Inverse(np.sqrt(x_R), g2), g2))/2
        else:
            # Minimum occurs outside region (is fictitious).
            z_0 = Ns_K - (Ns(ns_Inverse(np.sqrt(x_L), g2), g2) +
                          Ns(ns_Inverse(np.sqrt(x_R), g2), g2))/2

            # Get correct sign.
            if x_L > x_R:
                z_0 *= -1
            else:
                pass

        # Give field profile as a callable function.
        def f(z):
            zprime = z - z_c
            return field_VEV*gamma*ns(Ns_Inverse(
                Ns_K - abs((zprime/L_c) + z_0), g2), g2)**2

    else:
        ' ---- Scenario : passes VEV ---- '

        C_abs = abs(gamma)
        C2 = C_abs**2

        y_L = field_boundary_L/field_VEV
        y_R = field_boundary_R/field_VEV

        if C_abs >= 1:
            ' ---- Scenario : passes VEV (C^2 >= 1) ---- '

            mu2 = 1 - 1/C2

            u_L = sn_Inverse((y_L - 1)/(y_L + 1), mu2)
            u_R = sn_Inverse((y_R - 1)/(y_R + 1), mu2)

            u_min = min(u_L, u_R)
            u_max = max(u_L, u_R)

            sig = np.sign(y_R - y_L)

            # Calculate z_0 by evaluating Eq. (50) at left boundary.
            def residual_int(u):
                return (u + 2*Sc(u, mu2))/C_abs + 2*C_abs*(dc(u, mu2) - 1)

            z_star = z_boundary_L - sig*compton_WL*residual_int(u_L)

            # Give field profile as a callable function using bisection method.
            def f(z):
                'Solve residual equation using bisection method.'

                Z = sig*(z - z_star)/compton_WL

                if isinstance(Z, float):

                    a, b = u_min, u_max

                    while abs(b-a) > 1e-14:

                        c = (a + b)/2

                        if residual_int(c) > Z:
                            b = c
                        else:
                            a = c

                    u = (a + b)/2

                else:

                    inv = []
                    for Zi in Z:

                        a, b = u_min, u_max

                        while abs(b-a) > 1e-14:

                            c = (a + b)/2

                            if residual_int(c) > Zi:
                                b = c
                            else:
                                a = c

                        inv.append((a + b)/2)

                    u = np.array(inv)

                # Convert from u to phi.
                field = field_VEV*((2/(1 - sn(u, mu2))) - 1)

                return field

        else:
            ' ---- Scenario : passes VEV (C^2 < 1) ---- '

            nu2 = 1 - C2

            w_L = sn_Inverse((y_L - 1)/np.sqrt((y_L - 1)**2 + 4*y_L*C2), nu2)
            w_R = sn_Inverse((y_R - 1)/np.sqrt((y_R - 1)**2 + 4*y_R*C2), nu2)

            w_min = min(w_L, w_R)
            w_max = max(w_L, w_R)

            sig = np.sign(y_R - y_L)

            # Calculate z_0 by evaluating Eq. () at left boundary.
            def residual_int(w):
                return w + 2*C2*Sc(w, nu2) + 2*C_abs*(nc(w, nu2) - 1)

            z_star = z_boundary_L - sig*compton_WL*residual_int(w_L)

            # Give field profile as a callable function using bisection method.
            def f(z):
                'Solve residual equation using bisection method.'

                Z = sig*(z - z_star)/compton_WL

                if isinstance(Z, float):

                    a, b = w_min, w_max

                    while abs(b-a) > 1e-14:

                        c = (a + b)/2

                        if residual_int(c) > Z:
                            b = c
                        else:
                            a = c

                    w = (a + b)/2

                else:

                    inv = []
                    for Zi in Z:

                        a, b = w_min, w_max

                        while abs(b-a) > 1e-14:

                            c = (a + b)/2

                            if residual_int(c) > Zi:
                                b = c
                            else:
                                a = c

                        inv.append((a + b)/2)

                    w = np.array(inv)

                # Convert from u to phi.
                field = field_VEV*((2/(1 - C_abs*sd(w, nu2))) - 1)

                return field

    return f


' -------------------------------------------------------------------------- '
' -------------- Parameter constraint equations and residuals -------------- '
' -------------------------------------------------------------------------- '


def parameter_residual(gamma, data):
    'Residual of guess for curve parameter.'

    L_rs, field_VEV, field_boundary_L, field_boundary_R = data

    if field_boundary_L < field_VEV and field_boundary_R < field_VEV:
        ' ---- Scenario : extrema (maximum) ---- '

        k = gamma

        k2 = k**2
        L_mod = L_rs/np.sqrt(k**3)

        x_L = field_boundary_L/(field_VEV*k)
        x_R = field_boundary_R/(field_VEV*k)

        # Calculate x_c.
        Sn_K = Sn(K(k2), k2)
        x_c = sn(Sn_Inverse(Sn_K - L_mod, k2), k2)**2

        # Calculate residual [Eq. (26)].
        if min(x_L, x_R) > x_c:
            # Maximum occurs inside region.
            residual = abs(2*Sn_K -
                           Sn(sn_Inverse(np.sqrt(x_L), k2), k2) -
                           Sn(sn_Inverse(np.sqrt(x_R), k2), k2)) - L_mod
        else:
            # Maximum occurs outside region (is fictitious).
            residual = L_mod - abs(Sn(sn_Inverse(np.sqrt(x_R), k2), k2) -
                                   Sn(sn_Inverse(np.sqrt(x_L), k2), k2))

    elif field_boundary_L > field_VEV and field_boundary_R > field_VEV:
        ' ---- Scenario : extrema (minimum) ---- '

        k = gamma

        g2 = 1/k**2  # use g := 1/k.
        L_mod = L_rs/np.sqrt(k)

        x_L = field_boundary_L/(field_VEV*k)
        x_R = field_boundary_R/(field_VEV*k)

        # Calculate x_c.
        Ns_K = Ns(K(g2), g2)
        x_c = ns(Ns_Inverse(Ns_K - L_mod, g2), g2)**2

        # Calculate residual [Eq. (38)].
        if max(x_L, x_R) < x_c:
            # Minimum occurs inside region.
            residual = L_mod - abs(2*Ns_K -
                                   Ns(ns_Inverse(np.sqrt(x_L), g2), g2) -
                                   Ns(ns_Inverse(np.sqrt(x_R), g2), g2))
        else:
            # Minimum occurs outside region (is fictitious).
            residual = abs(Ns(ns_Inverse(np.sqrt(x_R), g2), g2) -
                           Ns(ns_Inverse(np.sqrt(x_L), g2), g2)) - L_mod

    else:
        ' ---- Scenario : passes VEV ---- '

        C_abs = (1/gamma) - 1
        C2 = C_abs**2

        y_L = field_boundary_L/field_VEV
        y_R = field_boundary_R/field_VEV

        if C_abs >= 1:
            ' ---- Scenario : passes VEV (C^2 >= 1) ---- '

            mu2 = 1 - 1/C2

            u_L = sn_Inverse((y_L - 1)/(y_L + 1), mu2)
            u_R = sn_Inverse((y_R - 1)/(y_R + 1), mu2)

            # Calculate residual [Eq. (51)].
            A = (u_R - u_L) + 2*(Sc(u_R, mu2) - Sc(u_L, mu2))
            B = dc(u_R, mu2) - dc(u_L, mu2)
            residual = abs(A/(2*C_abs) + C_abs*B) - L_rs

        else:
            ' ---- Scenario : passes VEV (C^2 < 1) ---- '

            nu2 = 1 - C2

            w_L = sn_Inverse((y_L - 1)/np.sqrt((y_L - 1)**2 + 4*y_L*C2), nu2)
            w_R = sn_Inverse((y_R - 1)/np.sqrt((y_R - 1)**2 + 4*y_R*C2), nu2)

            # Calculate residual [Eq. ()].
            A = 0.5*(w_R - w_L) + C2*(Sc(w_R, nu2) - Sc(w_L, nu2))
            B = nc(w_R, nu2) - nc(w_L, nu2)
            residual = abs(A + C_abs*B) - L_rs

    return residual


def solve_for_parameter(data):
    'Solves for a sign region given boundary values.'

    L_rs, field_VEV, field_boundary_L, field_boundary_R = data

    # Make initial guess based on scenario.
    if field_boundary_L < field_VEV and field_boundary_R < field_VEV:
        ' ---- Scenario : extrema (maximum) ---- '
        a, b = max(field_boundary_L, field_boundary_R)/field_VEV, 1
        solution_type = "extrema"

    elif field_boundary_L > field_VEV and field_boundary_R > field_VEV:
        ' ---- Scenario : extrema (minimum) ---- '
        a, b = 1, min(field_boundary_L, field_boundary_R)/field_VEV
        solution_type = "extrema"

    else:
        ' ---- Scenario : passes VEV ---- '
        a, b = 0, 1
        solution_type = "VEV"

    # Numerically solve for the curve parameter using bisection method.
    while abs(b-a) > 1e-14:

        c = (a + b)/2

        if parameter_residual(c, data) > 0:
            b = c
        else:
            a = c

    curve_parameter = (a + b)/2

    return solution_type, curve_parameter


def residual_boundary_constraint(boundary_values, *setup):
    'Calculate residual for set of boundary values.'
    field_VEVs, L_RSs, constraint_terms = setup

    # Compute delta coefficents for each region.
    deltas = [0]  # First entry corresponds to exterior region.

    for phi_L, phi_R, field_VEV, L_rs in zip(boundary_values[:-1],
                                             boundary_values[1:],
                                             field_VEVs[1:], L_RSs):

        # Calculate correct curve parameter for given boundary values.
        sol_type, para = solve_for_parameter(data=(L_rs, field_VEV,
                                                   phi_L, phi_R))

        if sol_type == "extrema":
            deltas.append(((1 - para)**2)/para)

        else:
            deltas.append(-0.5*((1 - para)/para)**2)

    deltas.append(0)  # Last entry corresponds to exterior region.
    residual = []

    if constraint_terms:
        # Get residual using gradient constraint equation. [Eq. (48)].
        residual.append(np.dot(constraint_terms[0], boundary_values) -
                        constraint_terms[1])

    for phi_b, VEV_L, VEV_R, delta_L, delta_R in zip(boundary_values,
                                                     field_VEVs[:-1],
                                                     field_VEVs[1:],
                                                     deltas[:-1], deltas[1:]):

        x_L = VEV_L/phi_b
        x_R = VEV_R/phi_b

        A = (1/x_R) - (1/x_L)
        B = (1/x_R) + (1/x_L)
        C = (delta_R/x_R) - (delta_L/x_L)

        residual.append(A*(B-2) - C)

    return np.array(residual)


' -------------------------------------------------------------------------- '
' --------------------------- Generate solutions --------------------------- '
' -------------------------------------------------------------------------- '


def calc_VEV(n, Lambda, M, density, Lambda_NonEVUnits=None, M_NonEVUnits=None,
             density_NonEVUnits=None):
    '''
    Calculate the vacuum expectation value for the chameleon for a given
    density.

    Parameters
    ----------
    n : int
        DESCRIPTION.
    Lambda : TYPE
        DESCRIPTION.
    M : float
        DESCRIPTION.
    density : float
        DESCRIPTION.
    Lambda_NonEVUnits : TYPE, optional
        DESCRIPTION. The default is None.
    M_NonEVUnits : TYPE, optional
        DESCRIPTION. The default is None.
    density_NonEVUnits : TYPE, optional
        DESCRIPTION. The default is None.

    Returns
    -------
    VEV : TYPE
        DESCRIPTION.

    '''

    p = 1/(n+1)
    C = M*Lambda**(n+4)
    VEV = (C/density)**p

    return VEV


def calc_Compton_WL(n, Lambda, M, density, Lambda_NonEVUnits=None,
                    M_NonEVUnits=None, density_NonEVUnits=None,
                    length_NonEVUnits=None):

    # make general. 
    comp_wl = (Lambda**1.25)*((M/density)**0.75)/np.sqrt(2)

    # Change units if needed.
    if length_NonEVUnits:
        _per_m_to_eV = constants.c.value*constants.hbar.value/constants.e.value
        comp_wl /= length_NonEVUnits.to(units.m)/_per_m_to_eV

    return comp_wl


def planar_solution(Lambda, M, densities, boundary_positions,
                    boundary_guess=None, density_NonEVUnits=None,
                    length_NonEVUnits=None, use_boundary_guess=None,
                    use_linear_constraint=False):

    # Convert density to natural units.
    if density_NonEVUnits:
        kg_per_m3_to_eV4 = (constants.hbar.value**3)*(constants.c.value**5)/(
            constants.e.value**4)

        densities_eV = densities *\
            density_NonEVUnits.to(units.kg*units.m**(-3))*kg_per_m3_to_eV4
    else:
        densities_eV = densities

    # Get relavent field quantities in each region.
    field_VEVs = calc_VEV(n=1, Lambda=Lambda, M=M, density=densities_eV)
    compton_WLs = calc_Compton_WL(n=1, Lambda=Lambda, M=M,
                                  density=densities_eV,
                                  length_NonEVUnits=length_NonEVUnits)

    if len(densities_eV) > 2:
        L = np.array([(z_R - z_L) for z_L, z_R in zip(boundary_positions[:-1],
                                                      boundary_positions[1:])])

        L_RSs = L/(2*compton_WLs[1:-1])

        # If no guess is provided, use average of neighbouring VEVs.
        if boundary_guess is None:
            boundary_guess = 2*np.sqrt(M*Lambda**5)/(
                np.sqrt(densities_eV[1:]) + np.sqrt(densities_eV[:-1]))

        # Compute boundary values (or use initial guess).
        if use_boundary_guess is True:
            boundary_values = boundary_guess

        else:
            if use_linear_constraint:
                # Assign vector and constant terms for constraint.
                constraint_terms = ((densities_eV[1:] - densities_eV[:-1])/2,
                                    densities_eV[-1]*field_VEVs[-1] -
                                    densities_eV[0]*field_VEVs[0])
            else:
                constraint_terms = None

            boundary_values = least_squares(
                fun=residual_boundary_constraint, x0=boundary_guess,
                bounds=(min(field_VEVs), max(field_VEVs)),
                args=(field_VEVs, L_RSs, constraint_terms)).x

    else:
        boundary_values = [2*np.sqrt(M*Lambda**5) /
                           (np.sqrt(densities_eV[0])
                            + np.sqrt(densities_eV[1]))]

    # Construct profiles : start with exterior region.
    profiles = [exterior(field_VEVs[0], compton_WLs[0], boundary_positions[0],
                         boundary_values[0])]

    # Construct profiles : all interior layers.
    for z_L, z_R, phi_L, phi_R, field_VEV, compton_WL in zip(
            boundary_positions[:-1], boundary_positions[1:],
            boundary_values[:-1], boundary_values[1:],
            field_VEVs[1:], compton_WLs[1:]):

        L_rs = (z_R - z_L)/(2*compton_WL)

        sol_type, para = solve_for_parameter(data=(L_rs, field_VEV,
                                                   phi_L, phi_R))

        if sol_type == "VEV":
            gamma = (1/para) - 1
        else:
            gamma = para

        profiles.append(
            interior(field_VEV, compton_WL, z_L, z_R, phi_L, phi_R, gamma))

    # Construct profiles : end with exterior region.
    profiles.append(exterior(field_VEVs[-1], compton_WLs[-1],
                             boundary_positions[-1], boundary_values[-1]))

    # Combine profiles into a single function.
    '''
    def f(z):

        field = np.zeros(len(z))

        for i, zi in enumerate(z):

            if zi < boundary_positions[0]:
                # Left exterior region.
                field[i] = profiles[0](zi)
                continue

            elif zi > boundary_positions[-1]:
                # Right exterior region.
                field[i] = profiles[-1](zi)
                continue

            else:
                # Find which interior region.
                for prf, z_L, z_R in zip(profiles[1:-1],
                                         boundary_positions[:-1],
                                         boundary_positions[1:]):

                    if zi > z_L and zi < z_R:
                        field[i] = prf(zi)
                        break

            # Check if point is on boundary.
            for z_b, phi_b in zip(boundary_positions, boundary_values):
                if zi == z_b:
                    field[i] = phi_b
                    break

        return field
    '''
    def f(z):

        field = np.zeros(len(z))

        for i, zi in enumerate(z):

            # Check for right exterior region.
            if zi > boundary_positions[-1]:
                field[i] = profiles[-1](zi)
            else:
                # Otherwise.
                for j, zb in enumerate(boundary_positions):
                    if zi < zb:
                        field[i] = profiles[j](zi)
                        break

        return field

    return f, boundary_values
