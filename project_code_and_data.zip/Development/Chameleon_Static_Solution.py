#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Feb 26 10:08:30 2025

@author: chad-briddon

Reproduce the exact analytic solution for a pair of parellel plates found in
"https://arxiv.org/abs/1606.06867".

*This code ran using SELCIE v2.0.0.

** Note there is a mistake in the paper. There is a missing factor of two
   equations 5 and 6. This means in equations 13 and 14 the L_s should be
   replaned by 2*L_s. Below we use the corrected result.

"""

import numpy as np
import dolfin as d
import matplotlib.pyplot as plt

from scipy.special import ellipeinc
from SELCIE.Mesh import MeshingTools_1D
from SELCIE.Solvers import Chameleon


# Set parameters.
L = 1
plate_thickness = 0.1
Ps, Pv = 1e10, 1

n = 1
compton_wl_s = 0.01
alpha = (n+1)*(compton_wl_s**2)*(Ps**((n+2)/(n+1)))
alpha = 100

alphas = [0.1, 10, 100]


' ---------------------------- Create functions ---------------------------- '


def create_mesh_parellel_plates(L, plate_thickness, show_mesh=True):

    filename = "parellel_plates"

    # Make mesh.
    MT = MeshingTools_1D(display_messages=False)

    plate_L = MT.create_1D_line(-plate_thickness, 0)
    plate_R = MT.create_1D_line(L, L+plate_thickness)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.010, DistMin=0.0,
                        DistMax=0.1)

    MT.create_1D_line(-plate_thickness, L+plate_thickness,
                      embed=plate_L+plate_R)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.05,
                        DistMax=0.1)

    MT.generate_mesh(filename, show_mesh)
    MT.msh_2_xdmf(filename, auto_override=True)

    return filename


def plate(x):
    return Ps


def vacuum(x):
    return Pv


def Sn(u, k):

    E = ellipeinc(u, k**2)
    Sn = (u - E)/k**2

    return Sn


def inverse_Sn(y, k, range_):
    'Since sn is monotoic function, use bisection method to find its inverse.'
    'Find f(x) = sn(x, k) - y = 0.'

    sn_inv = []
    for yi in y:

        a, b = range_
        while b-a > 1e-10:

            c = (b+a)/2

            if Sn(c, k) - yi > 0:
                b = c
            else:
                a = c

        sn_inv.append(c)

    return np.array(sn_inv)


' -------------------------------------------------------------------------- '
' --------------- Plot : differences in numeric and analytic --------------- '
' -------------------------------------------------------------------------- '

if True:

    mesh_name = create_mesh_parellel_plates(L, plate_thickness,
                                            show_mesh=False)

    for alpha in alphas:

        ' -------------------- Compute numeric solution -------------------- '

        s = Chameleon(alpha, n, mesh_name, dimension=1,
                      symmetry="translation symmetry")

        s.solve_static(density_profiles=[plate, vacuum], tol_du=1e-12)

        ' --------------------- Compare field profiles --------------------- '

        # Get analytic profile.
        x = np.linspace(0, 1, 1001)
        k = d.norm(s.field.vector(), 'linf')
        Ls = np.sqrt(2*alpha*(k**3))

        y_Anal = Sn(np.pi/2, k) - abs(1 - 2*x)/(4*Ls)

        theta_Anal = inverse_Sn(y_Anal, k, range_=(0, np.pi/2))

        field_Anal = k*np.sin(theta_Anal)**2

        # Get Numeric profile.
        field_Numc = np.array([s.field(xi, 0) for xi in x])

        theta_Numc = np.arcsin(np.sqrt(field_Numc/k))

        y_Numc = Sn(theta_Numc, k)

        ' ---------------------------- Make plot ---------------------------- '

        plt.rc('axes', labelsize=18)

        fig, axs = plt.subplots(nrows=3, sharex=True, figsize=(6, 12))
        fig.subplots_adjust(wspace=0, hspace=0)
        axs[-1].set_xlabel("x")

        # Compare field profiles.
        axs[0].set_ylabel(r"$\hat{\phi}$")

        axs[0].plot(x, field_Numc, label="Numeric", linestyle="dashed")
        axs[0].plot(x, field_Anal, label="Analytic", linestyle="solid")
        axs[0].legend()

        # Compare the linear part.
        axs[1].set_ylabel("y")

        axs[1].plot(x, y_Numc, label="Numeric", linestyle="dashed")
        axs[1].plot(x, y_Anal, label="Analytic", linestyle="solid")

        # Plot difference and add estimate of error to first order.
        axs[2].set_ylabel(r"$\Delta y = g(z)$")

        axs[2].plot(x, y_Numc - y_Anal, linestyle="solid", label=r"$\Delta y$")

        g1 = ((1 - k**2/2) - np.sqrt(1 - k**2))/(Ls*k**2)
        axs[2].plot(x, g1*abs(x - 0.5), linestyle="dashdot", color="k",
                    label="g'(0.5) |x-0.5|")
        axs[2].legend()

        # fig.savefig("Plots/comparison_k%.6f.png" % k, dpi=300,
        #             bbox_inches='tight')

' --------------------------------------------------------------------------- '
' ------------------------- Plot : Analytic attempt ------------------------- '
' --------------------------------------------------------------------------- '

if True:

    mesh_name = create_mesh_parellel_plates(L, plate_thickness,
                                            show_mesh=False)

    ' -------------------- Compute numeric solution -------------------- '

    s = Chameleon(alpha, n, mesh_name, dimension=1,
                  symmetry="translation symmetry")

    s.solve_static(density_profiles=[plate, vacuum], tol_du=1e-12)

    ' --------------------- Compare field profiles --------------------- '

    # Get analytic profile.
    x = np.linspace(0, 1, 1001)
    k = d.norm(s.field.vector(), 'linf')
    Ls = np.sqrt(2*alpha*(k**3))

    y_Anal = Sn(np.pi/2, k) - abs(1 - 2*x)/(4*Ls)

    theta_Anal = inverse_Sn(y_Anal, k, range_=(0, np.pi/2))

    field_Anal = k*np.sin(theta_Anal)**2

    # Get Numeric profile.
    field_Numc = np.array([s.field(xi, 0) for xi in x])

    theta_Numc = np.arcsin(np.sqrt(field_Numc/k))

    y_Numc = Sn(theta_Numc, k)

    ' ----------------------- Compute correct term ----------------------- '

    X = field_Numc/k

    k2 = k**2
    p1 = (1 - k2*X)/(k*(1 - X))
    p2 = X*(1 - k2*X)/(1 - X)

    I_ = k*X*np.arctan(np.sqrt(p1)) - np.arctan(np.sqrt(p2)) \
        + np.arctan(np.sqrt(X))

    y2 = I_/k2 - np.pi*(2*k - 1)/(4*k2)

    ' ---------------------------- Make plot ---------------------------- '

    plt.rc('axes', labelsize=18)

    fig, ax = plt.subplots()
    ax.set_xlabel("x")

    # Plot difference and add estimate of error to first order.
    ax.set_ylabel(r"$\Delta y = g(z)$")

    ax.plot(x, y_Numc - y_Anal, linestyle="solid", label=r"$\Delta y$")
    # ax.plot(x, y2, linestyle="dashdot", color="k",label="Analtyic")
    ax.legend()

    # fig.savefig("Plots/comparison(2)_k%.6f.png" % k, dpi=300,
    #             bbox_inches='tight')

#####################################

# s.plot_results(field_scale='linear')
# plt.plot(z, phi)
'''
# Plot relative error.
rel_err = np.array([abs((phi_i - s.field(z_i, 0))/s.field(z_i, 0))
                    for z_i, phi_i in zip(z, phi)])

plt.figure()
plt.title("Relative error (numeric vs analytic)")
plt.yscale("log")
plt.ylabel(r"$\Delta$")
plt.xlabel("z")
plt.plot(z, rel_err)

'Note the relative error scales with mesh refinement.'


' ----------------------- Check Laplacian & residual ----------------------- '

s.calc_laplacian()
s.calc_field_residual(density_profiles=[plate, vacuum])
s.plot_results(lapl_scale='log', res_scale='log')
'''

'''
##############################################################################
import scipy.integrate as integrate


def F_int(z, k):
        return integrate.quad(lambda x: np.sqrt(x/((1-x)*(1-(k**2)*x))),
                              s.field(z, 0)/k, 1)[0]

Z = np.linspace(0, 1, 1000)

test = np.array([F_int(zi, k) for zi in Z])

plt.figure()
plt.plot(Z, test)
'''

'''
##############################################################################
# https://functions.wolfram.com/EllipticIntegrals/EllipticF/introductions/IncompleteEllipticIntegrals/ShowAll.html
from scipy.special import ellipeinc as E
from scipy.special import ellipkinc as F

k = d.norm(s.field.vector(), 'linf')
field = np.array([s.field(zi, 0) for zi in z])
theta = np.arcsin(np.sqrt(field/k))

y = E(theta, k**2) - F(theta, k**2)

plt.figure()
plt.plot(z, y)


##############################################################################


plt.figure()
plt.plot(z, E(theta, k**2))


x = field/k

y = np.sqrt(x*(1-x)/(1-x*k**2))

plt.plot(z, y)

plt.plot(z, y-E(theta, k**2))
'''

##############################################################################

'''
z = np.linspace(0, L/2, 1000)
k = d.norm(s.field.vector(), 'linf')
Ls = np.sqrt(2*alpha*(k**3))
D = 1 - 2*z

T = (1 - 0.5*k**2) - np.sqrt(1 - k**2)
g3 = (T*D/Ls)*(-1 + np.sqrt(1-k**2)*(D**2)/(3*Ls**2))

field = np.array([s.field(zi, 0) for zi in z])
theta = np.arcsin(np.sqrt(field/k))

y1 = (Sn(np.pi/2, k) - Sn(theta, k))*k**2

y2 = y1 - (k**2)*D/(4*Ls)

y3 = y2 - g3

plt.figure()
# plt.plot(z, y1, label="1")
plt.plot(z, abs(y2), label="2")
plt.plot(z, abs(y3), label="3")
plt.legend()
'''
