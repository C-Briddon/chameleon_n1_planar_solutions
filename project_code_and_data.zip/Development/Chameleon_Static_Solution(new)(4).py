#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 25 11:16:50 2026

@author: chad-briddon

Check analytic solution for when field profile passes VEV.
Full solution with walls.

For identites see Handbook ... :
    https://personal.math.ubc.ca/~cbm/aands/abramowitz_and_stegun.pdf

*This code ran using SELCIE v2.0.0.

"""

import numpy as np
import matplotlib.pyplot as plt

from SELCIE.Mesh import MeshingTools_1D
from SELCIE.Solvers import Chameleon

# from _prototype_for_general_solver_3 import planar_solution
from chameleon_n1_planar_solutions.solutions import planar_solution


' ------------------------- Functions for numerics ------------------------- '


def create_mesh_parellel_plates(show_mesh=True):

    filename = "parellel_plates"

    # Make mesh.
    MT = MeshingTools_1D(display_messages=False)

    plate_L = MT.create_1D_line(-2, -0.5)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.0,
                        DistMax=0.2)

    plate_R = MT.create_1D_line(0.5, 5)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.0,
                        DistMax=0.2)

    MT.create_1D_line(-0.51, 0.51,
                      embed=plate_L+plate_R)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.05,
                        DistMax=0.2)

    MT.generate_mesh(filename, show_mesh)
    MT.msh_2_xdmf(filename, auto_override=True)

    return filename


def PL(x):
    return 100


def PM(x):
    return 10


def PR(x):
    return 1


densities = np.array([100, 10, 1])


' ------------------------ Compute numeric solution ------------------------ '

alpha = 1

Lambda = 1
M = 1
VEV = 1

mesh_name = create_mesh_parellel_plates(show_mesh=False)

s = Chameleon(alpha=1, n=1, mesh_name=mesh_name, dimension=1,
              symmetry="translation symmetry")

s.solve_static(density_profiles=[PL, PR, PM], tol_du=1e-10)


' --------------------- Compare field profiles --------------------- '

# Get analytic profile.
x = np.linspace(-1, 5, 6001)
field_numc = np.array([s.field(xi, 0) for xi in x])

# Get location of VEV pass.
a, b = -0.5, 0.5

while b-a > 1e-10:

    c = (b+a)/2

    if s.field(c, 0) - 1/np.sqrt(10) > 0:
        b = c
    else:
        a = c

zeta_0 = c


' ---------------------------- Analytic solution ---------------------------- '

f, boundary_values, parameters = planar_solution(
    Lambda, M, densities, boundary_positions=[-0.5, 0.5])

print(boundary_values)


' -------------------------------- Make plot -------------------------------- '

# Get gradient at zeta origin.
s.calc_field_grad_vector()
g = s.field_grad(zeta_0, 0)[0]

field_anal = f(x)

plt.figure()
plt.axhline(1, linestyle="dashed")
plt.axhline(1/np.sqrt(10), linestyle="dashed")
plt.axhline(1/10, linestyle="dashed")

plt.plot([zeta_0], [1/np.sqrt(10)], 'r.')
plt.plot(x, field_numc, label="Numeric", linestyle="solid")
plt.plot(x, field_anal, label="Analytic", linestyle="dashed")
plt.legend()

# plt.figure()
# plt.yscale('log')
# plt.plot(x, abs(field_numc - field_anal))
