#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 16:14:02 2026

@author: chad-briddon

Test general solution in '_prototype_for_general_solver.py'.

*This code ran using SELCIE v2.0.0.

"""

import numpy as np
import matplotlib.pyplot as plt

from SELCIE.Mesh import MeshingTools_1D
from SELCIE.Solvers import Chameleon

from General_solution import Chameleon_Parallel_Plates_Solution

from _prototype_for_general_solver import planar_solution


' -------------------------------------------------------------------------- '
' ------------------------- Functions for numerics ------------------------- '
' -------------------------------------------------------------------------- '


def create_mesh_parellel_plates(show_mesh=True):

    filename = "parellel_plates"

    # Make mesh.
    MT = MeshingTools_1D(display_messages=False)

    plate_L = MT.create_1D_line(-2, -0.5)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.0,
                        DistMax=0.2)

    plate_R = MT.create_1D_line(0.5, 5)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.0,
                        DistMax=0.2)

    MT.create_1D_line(-0.51, 0.51,
                      embed=plate_L+plate_R)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.05,
                        DistMax=0.2)

    MT.generate_mesh(filename, show_mesh)
    MT.msh_2_xdmf(filename, auto_override=True)

    return filename


def make_density_func(p):

    def f(x):
        return p

    return f


' ---------------- Plot field in small wavelength regime ---------------- '

if True:

    # Set parameters.
    P_R = 1e4
    P_L = 1e5
    P_V = 1

    alpha = 1e5
    L = 1

    omega_L = np.sqrt(P_V/P_L)
    omega_R = np.sqrt(P_V/P_R)

    z = np.linspace(-1.6, 1.6, 1000)

    # Solve analytically.
    C = Chameleon_Parallel_Plates_Solution(omega_L, omega_R, alpha, L)
    k = C.get_k(0.00714)
    field_anal = C.field_profile(z, k)

    # Solve numerically.
    mesh_name = create_mesh_parellel_plates(show_mesh=False)

    left = make_density_func(P_L)
    right = make_density_func(P_R)
    vacuum = make_density_func(P_V)

    s = Chameleon(alpha, n=1, mesh_name=mesh_name, dimension=1,
                  symmetry="translation symmetry")

    s.solve_static(density_profiles=[left, right, vacuum], tol_du=1e-12)

    field_numc = np.array([s.field(zi, 0) for zi in z])

    # Plot comparison.
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.set_ylabel(r"$\hat{\phi}$")
    ax.set_xlabel("z")
    ax.set_xlim([-1.6, 1.6])

    ax.axvline(-L/2, linestyle="dashdot", color="k")
    ax.axvline(+L/2, linestyle="dashdot", color="k")

    ax.axhline(C.omega_L, linestyle="dashdot", color="r",
               label=r"$\omega_L$")

    ax.axhline(C.omega_R, linestyle="dashdot", color="c",
               label=r"$\omega_R$")

    ax.plot(z, field_numc, label="Numeric", linestyle="solid")
    ax.plot(z, field_anal, label="Analytic", linestyle="dashed")

    ' ------------------------ check boundary values ------------------------ '

    # Convert Compton wavelength parameters.
    vacuum_VEV = 1
    vacuum_comp = np.sqrt(alpha/2)
    vacuum_rho = 1

    Lambda = ((vacuum_VEV**3)/(2*vacuum_comp**2))**0.2
    M = 2*(vacuum_comp**2)*vacuum_rho/vacuum_VEV

    densities = np.array([P_L/P_V, 1, P_R/P_V])
    boundary_positions = np.array([-0.5, +0.5])

    func = planar_solution(Lambda, M, densities, boundary_positions)
    field_new = func(z)

    plt.plot(z, field_new)

    ' ----------------------------------------------------------------------- '

    ax.legend()
    plt.show()

    # Plot difference.
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.set_ylabel(r"$\Delta \hat{\phi}$")
    ax.set_xlabel("z")
    ax.set_xlim([-1.6, 1.6])

    # plt.plot(z, field_numc-field_anal)
    plt.plot(z, field_numc-field_new)
