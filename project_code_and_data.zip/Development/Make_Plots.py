#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Nov 16 10:40:31 2025

@author: chad-briddon

Make plots for paper.

*This code ran using SELCIE v2.0.0.

"""

import numpy as np
import matplotlib.pyplot as plt

from SELCIE.Mesh import MeshingTools_1D
from SELCIE.Solvers import Chameleon

from General_solution import Chameleon_Parallel_Plates_Solution


' -------------------------------------------------------------------------- '
' ------------------------- Functions for numerics ------------------------- '
' -------------------------------------------------------------------------- '


def create_mesh_parellel_plates(show_mesh=True):

    filename = "parellel_plates"

    # Make mesh.
    MT = MeshingTools_1D(display_messages=False)

    plate_L = MT.create_1D_line(-2, -0.5)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.0,
                        DistMax=0.2)

    plate_R = MT.create_1D_line(0.5, 5)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.0,
                        DistMax=0.2)

    MT.create_1D_line(-0.51, 0.51,
                      embed=plate_L+plate_R)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.05,
                        DistMax=0.2)

    MT.generate_mesh(filename, show_mesh)
    MT.msh_2_xdmf(filename, auto_override=True)

    return filename


def make_density_func(p):

    def f(x):
        return p

    return f


if __name__ == "__main__":

    plt.rc('axes', labelsize=15)
    plt.rc('legend', fontsize=15)

    ' ---------------- Plot field in small wavelength regime ---------------- '

    if False:

        # Set parameters.
        P_R = 1e4
        P_L = 1e5
        P_V = 1

        alpha = 1e5
        L = 1

        omega_L = np.sqrt(P_V/P_L)
        omega_R = np.sqrt(P_V/P_R)

        z = np.linspace(-1.6, 1.6, 1000)

        # Solve analytically.
        C = Chameleon_Parallel_Plates_Solution(omega_L, omega_R, alpha, L)
        k = C.get_k(0.00714)
        field_anal = C.field_profile(z, k)

        # Solve numerically.
        mesh_name = create_mesh_parellel_plates(show_mesh=False)

        left = make_density_func(P_L)
        right = make_density_func(P_R)
        vacuum = make_density_func(P_V)

        s = Chameleon(alpha, n=1, mesh_name=mesh_name, dimension=1,
                      symmetry="translation symmetry")

        s.solve_static(density_profiles=[left, right, vacuum], tol_du=1e-12)

        field_numc = np.array([s.field(zi, 0) for zi in z])

        # Plot comparison.
        fig, ax = plt.subplots(figsize=(8, 6))
        ax.set_ylabel(r"$\hat{\phi}$")
        ax.set_xlabel("z")
        ax.set_xlim([-1.6, 1.6])

        ax.axvline(-L/2, linestyle="dashdot", color="k")
        ax.axvline(+L/2, linestyle="dashdot", color="k")

        ax.axhline(C.omega_L, linestyle="dashdot", color="r",
                   label=r"$\omega_L$")

        ax.axhline(C.omega_R, linestyle="dashdot", color="c",
                   label=r"$\omega_R$")

        ax.plot(z, field_numc, label="Numeric", linestyle="solid")
        ax.plot(z, field_anal, label="Analytic", linestyle="dashed")

        ax.legend()
        plt.show()

        fig.savefig("Plots/Small_WL", dpi=300, bbox_inches='tight')

        # Plot difference.
        fig, ax = plt.subplots(figsize=(8, 6))
        ax.set_ylabel(r"$\Delta \hat{\phi}$")
        ax.set_xlabel("z")
        ax.set_xlim([-1.6, 1.6])

        plt.plot(z, field_numc-field_anal)

        plt.show()

        fig.savefig("Plots/Small_WL_difference", dpi=300, bbox_inches='tight')

    ' ---------------- Plot field in large wavelength regime ---------------- '

    if False:

        # Set parameters.
        P_R = 1e4
        P_L = 1e5
        P_V = 1

        alpha = 2e6
        L = 1

        omega_L = np.sqrt(P_V/P_L)
        omega_R = np.sqrt(P_V/P_R)

        z = np.linspace(-1.6, 1.6, 1000)

        # Solve analytically.
        C = Chameleon_Parallel_Plates_Solution(omega_L, omega_R, alpha, L)
        k = C.get_k(0.00714)
        field_anal = C.field_profile(z, k)

        # Solve numerically.
        mesh_name = create_mesh_parellel_plates(show_mesh=False)

        left = make_density_func(P_L)
        right = make_density_func(P_R)
        vacuum = make_density_func(P_V)

        s = Chameleon(alpha, n=1, mesh_name=mesh_name, dimension=1,
                      symmetry="translation symmetry")

        s.solve_static(density_profiles=[left, right, vacuum], tol_du=1e-12)

        field_numc = np.array([s.field(zi, 0) for zi in z])

        # Plot comparison.
        fig, ax = plt.subplots(figsize=(8, 6))
        ax.set_ylabel(r"$\hat{\phi}$")
        ax.set_xlabel("z")
        ax.set_xlim([-1.6, 1.6])

        ax.axvline(-L/2, linestyle="dashdot", color="k")
        ax.axvline(+L/2, linestyle="dashdot", color="k")

        ax.axhline(C.omega_L, linestyle="dashdot", color="r",
                   label=r"$\omega_L$")

        ax.axhline(C.omega_R, linestyle="dashdot", color="c",
                   label=r"$\omega_R$")

        ax.plot(z, field_numc, label="Numeric", linestyle="solid")
        ax.plot(z, field_anal, label="Analytic", linestyle="dashed")

        ax.legend()
        plt.show()

        fig.savefig("Plots/Large_WL", dpi=300, bbox_inches='tight')

        # Plot difference.
        fig, ax = plt.subplots(figsize=(8, 6))
        ax.set_ylabel(r"$\Delta \hat{\phi}$")
        ax.set_xlabel("z")
        ax.set_xlim([-1.6, 1.6])

        plt.plot(z, field_numc-field_anal)
        plt.show()

        fig.savefig("Plots/Large_WL_difference", dpi=300, bbox_inches='tight')

    ' ------------- Plot field in large/small wavelength regime ------------- '

    if False:

        # Set parameters.
        P_R = 1e4
        P_L = 1e5
        P_V = 1

        L = 1

        lambda_V1 = 200
        lambda_V2 = 500
        lambda_V3 = 900

        alpha_1 = 2*lambda_V1**2
        alpha_2 = 2*lambda_V2**2
        alpha_3 = 2*lambda_V3**2

        omega_L = np.sqrt(P_V/P_L)
        omega_R = np.sqrt(P_V/P_R)

        z = np.linspace(-1.6, 1.6, 1000)

        # Solve analytically.
        C1 = Chameleon_Parallel_Plates_Solution(omega_L, omega_R, alpha_1, L)
        k1 = C1.get_k(0.00714)
        field_anal_1 = C1.field_profile(z, k1)

        print(C1.monotoic_compton_limit())

        C2 = Chameleon_Parallel_Plates_Solution(omega_L, omega_R, alpha_2, L)
        k2 = C2.get_k(0.00714)
        field_anal_2 = C2.field_profile(z, k2)

        C3 = Chameleon_Parallel_Plates_Solution(omega_L, omega_R, alpha_3, L)
        k3 = C3.get_k(0.00714)
        field_anal_3 = C3.field_profile(z, k3)

        # Solve numerically.
        '''
        mesh_name = create_mesh_parellel_plates(show_mesh=False)

        left = make_density_func(P_L)
        right = make_density_func(P_R)
        vacuum = make_density_func(P_V)

        #
        s1 = Chameleon(alpha_1, n=1, mesh_name=mesh_name, dimension=1,
                       symmetry="translation symmetry")

        s1.solve_static(density_profiles=[left, right, vacuum], tol_du=1e-12)

        field_numc_1 = np.array([s1.field(zi, 0) for zi in z])

        #
        s2 = Chameleon(alpha_2, n=1, mesh_name=mesh_name, dimension=1,
                       symmetry="translation symmetry")

        s2.solve_static(density_profiles=[left, right, vacuum], tol_du=1e-12)

        field_numc_2 = np.array([s2.field(zi, 0) for zi in z])

        #
        s3 = Chameleon(alpha_3, n=1, mesh_name=mesh_name, dimension=1,
                       symmetry="translation symmetry")

        s3.solve_static(density_profiles=[left, right, vacuum], tol_du=1e-12)

        field_numc_3 = np.array([s3.field(zi, 0) for zi in z])
        '''
        # Plot comparison.
        fig, ax = plt.subplots(figsize=(8, 6))
        ax.set_ylabel(r"$\phi/\phi_V$")
        ax.set_xlabel("$z/L$")
        ax.set_xlim([-1.6, 1.6])

        # Fill in mirror regions.
        ax.axvspan(-1.6, -0.5, alpha=0.4)
        ax.axvspan(+0.5, +1.6, alpha=0.4)

        # tick_values = np.linspace(-1.6, 1.6, 33)
        # tick_labels = [None for ti in tick_values]

        # ax.set_xticks(ticks=tick_values, label=tick_labels)

        ax.axvline(-L/2, linestyle="dashed", color="k")
        ax.axvline(+L/2, linestyle="dashed", color="k")

        ax.axhline(omega_L, linestyle="dashdot", color="r",
                   label=r"$\omega_L$")

        ax.axhline(omega_R, linestyle="dashdot", color="c",
                   label=r"$\omega_R$")

        ax.plot(z, field_anal_1, label=r"$\lambda_V = %i \ L$" % lambda_V1)
        ax.plot(z, field_anal_2, label=r"$\lambda_V = %i \ L$" % lambda_V2)
        ax.plot(z, field_anal_3, label=r"$\lambda_V = %i \ L$" % lambda_V3)

        # ax.plot(z, field_numc_1, linestyle="dashed", color="k")
        # ax.plot(z, field_numc_2, linestyle="dashed", color="k")
        # ax.plot(z, field_numc_3, linestyle="dashed", color="k")

        ax.legend(loc="upper left")
        plt.show()

        fig.savefig("Plots/solution", dpi=300, bbox_inches='tight')

    ' ----------- Plot relation bewtween Compton wavelength and k ----------- '

    if True:

        # Set parameters.
        lambda_V = 10**np.linspace(-2, 6, 100)
        alpha = 2*lambda_V**2

        P_R_labels = [r"$\rho_R = \rho_V \, 10^{5}$",
                      r"$\rho_R = \rho_V \, 10^{4}$",
                      r"$\rho_R = \rho_V \, 10^{3}$"]

        ranges = [None, None, (0.01, 1)]

        P_R_list = [1e5, 1e4, 1e3]
        P_V = 1
        P_L = 1e5

        # Plot iterativly.
        fig, ax = plt.subplots(figsize=(8, 4.5))
        ax.set_ylabel("$k$")
        ax.set_xlabel(r"$\lambda_V / L$")

        ax.set_xlim([1e-2, 1e6])

        ax.set_yscale("log")
        ax.set_xscale("log")

        Cls = ["C0", "C1", "C2"]  # colour labels.

        for P_R, label, range_i, Cl in zip(P_R_list, P_R_labels, ranges, Cls):

            omega_L = np.sqrt(P_V/P_L)
            omega_R = np.sqrt(P_V/P_R)

            # plt.axhline(omega_R)

            k = []

            for a_i in alpha:

                C = Chameleon_Parallel_Plates_Solution(omega_L, omega_R,
                                                       a_i, L=1)
                # k.append(C.get_k(0.00714))
                k.append(C.get_k2(range_=range_i))

            ax.plot(lambda_V, k, label=label, color=Cl)

            # Add lambda --> infinity limit.
            k_lim = ((1 + omega_L*omega_R) - np.sqrt((1 - omega_L**2)
                                                     * (1 - omega_R**2))
                     )/(omega_L + omega_R)

            ax.axhline(k_lim, linestyle="dashed", color=Cl)

        ax.legend()
        plt.show()

        fig.savefig("Plots/k_values", dpi=300, bbox_inches='tight')

    # Make curve to compare against "https://arxiv.org/abs/2405.14638"
    if False:
        # Set parameters.
        lambda_V = 10**np.linspace(-2, 6, 100)
        alpha = 2*lambda_V**2

        P_R_labels = [r"$\rho_M = \rho_V \cdot 10^{10}$"]

        P_R = 1e10
        P_V = 1
        P_L = 1e10

        # Plot iterativly.
        fig, ax = plt.subplots(figsize=(8, 4.5))
        ax.set_ylabel("k")
        ax.set_xlabel(r"$\lambda_V$")

        # ax.set_xlim([1e-2, 1e6])

        ax.set_yscale("log")
        ax.set_xscale("log")

        omega_L = np.sqrt(P_V/P_L)
        omega_R = np.sqrt(P_V/P_R)

        # plt.axhline(omega_R)

        k = []

        for a_i in alpha:

            C = Chameleon_Parallel_Plates_Solution(omega_L, omega_R,
                                                   a_i, L=1)
            # k.append(C.get_k(0.00714))
            k.append(C.get_k2(range_=None))

        ax.plot(lambda_V, k)

        # Print/show where Compton wavelength is.
        from SELCIE.Misc import alpha_calculator_chameleon, units

        n = 1
        Lam = 1                                          # eV
        M_pl = 2.4e27                                    # eV
        M = M_pl/1e5                                     # eV
        p0 = 5.3e-12                                     # kg/m^3
        L = 3                                            # um

        # beta = 1e5.
        alpha = alpha_calculator_chameleon(n, M, Lam, p0, L,
                                           p0_NonEVUnits=units.kg/units.m**3,
                                           L_NonEVUnits=units.um)

        comp_V = np.sqrt(alpha/2)
        ax.axvline(comp_V)

        # beta = 1.
        M = M_pl/1e23
        alpha = alpha_calculator_chameleon(n, M, Lam, p0, L,
                                           p0_NonEVUnits=units.kg/units.m**3,
                                           L_NonEVUnits=units.um)

        comp_V = np.sqrt(alpha/2)
        ax.axvline(comp_V)

        # Get k at intersect.
        C = Chameleon_Parallel_Plates_Solution(omega_L, omega_R,
                                               alpha, L=1)
        k_x = C.get_k2(range_=None)
        print(k_x)
        ax.plot([comp_V], [k_x], 'r.')

        plt.show()
