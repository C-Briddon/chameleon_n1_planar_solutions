#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 30 10:33:59 2025

@author: chad-briddon

Identities all work.

"""

import numpy as np
import matplotlib.pyplot as plt

from scipy.special import ellipj
from scipy.special import ellipk, ellipkinc, ellipeinc


def K(m):
    return ellipk(m**2)


def F(u, m):
    return ellipkinc(u, m**2)


def E(u, m):
    return ellipeinc(u, m**2)


def inverse_F(y, k, range_=[0, 1]):
    'Since sn is monotoic function, use bisection method to find its inverse.'
    'Find f(x) = F(x, k) - y = 0.'

    inv = []
    for yi in y:

        a, b = range_
        while b-a > 1e-10:

            c = (b+a)/2

            if F(c, k) - yi > 0:
                b = c
            else:
                a = c

        inv.append(c)

    return np.array(inv)


def sn(u, m):
    return ellipj(u, m**2)[0]


def Sn(u, k):

    Y = []

    for u_i in u:
        t = np.linspace(0, u_i, 1000)

        sn2 = sn(t, k)**2
        Y.append(np.trapz(sn2, t))

    return np.array(Y)


def inverse_Sn(y, k, range_=[0, 1]):
    'Since sn is monotoic function, use bisection method to find its inverse.'
    'Find f(x) = Sn(x, k) - y = 0.'

    inv = []
    for yi in y:

        a, b = range_
        while b-a > 1e-10:

            c = (b+a)/2

            if Sn(c, k) - yi > 0:
                b = c
            else:
                a = c

        inv.append(c)

    return np.array(inv)


k = 0.9
u = np.linspace(0, 1, 1000)


' ----------------------- Identity 1 (sn & inverse F) ----------------------- '

plt.figure()
plt.title("Identity 1")
plt.xlabel("u")

plt.plot(u, sn(u, k), label=r"${\rm sn}(u, k)$", linestyle="solid")
plt.plot(u, np.sin(inverse_F(u, k)), label=r"$\sin(F^{-1}(u, k))$",
         linestyle="dashed")

plt.legend()

' -------------------------- Identity 2 (E(inv_F)) -------------------------- '

plt.figure()
plt.title("Identity 2")
plt.xlabel("u")

plt.plot(u, E(inverse_F(u, k), k), label=r"$E(F^{-1}(u, k))$",
         linestyle="solid")
plt.plot(u, (u - (k**2)*Sn(u, k)), label=r"$u - k^2 {\rm Sn(u, k)}$",
         linestyle="dashed")

plt.legend()
