#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Mar  7 11:53:44 2026

@author: chad-briddon

Make plots for paper using '_prototype_for_general_solver.py'.

*This code ran using SELCIE v2.0.0.

"""


import numpy as np
import matplotlib.pyplot as plt

from SELCIE.Mesh import MeshingTools_1D
from SELCIE.Solvers import Chameleon

# from _prototype_for_general_solver import planar_solution
from chameleon_n1_planar_solutions.solutions import planar_solution


plt.rc('axes', labelsize=15)
plt.rc('legend', fontsize=15)


' -------------------------------------------------------------------------- '
' ------------------------- Functions for numerics ------------------------- '
' -------------------------------------------------------------------------- '


def create_mesh_single_plates(show_mesh=True):

    filename = "single_plate"

    # Make mesh.
    MT = MeshingTools_1D(display_messages=False)

    mirror = MT.create_1D_line(-2, 0)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.0,
                        DistMax=0.2)

    MT.create_1D_line(-0.1, 100, embed=mirror)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.0,
                        DistMax=0.2)

    MT.generate_mesh(filename, show_mesh)
    MT.msh_2_xdmf(filename, auto_override=True)

    return filename


def create_mesh_parellel_plates(show_mesh=True):

    filename = "parellel_plates"

    # Make mesh.
    MT = MeshingTools_1D(display_messages=False)

    plate_L = MT.create_1D_line(-2, -0.5)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.0,
                        DistMax=0.2)

    plate_R = MT.create_1D_line(0.5, 5)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.0,
                        DistMax=0.2)

    MT.create_1D_line(-0.51, 0.51,
                      embed=plate_L+plate_R)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.05,
                        DistMax=0.2)

    MT.generate_mesh(filename, show_mesh)
    MT.msh_2_xdmf(filename, auto_override=True)

    return filename


def create_mesh_casimir_plates(show_mesh=True):

    filename = "casimir_plates"

    # Make mesh.
    MT = MeshingTools_1D(display_messages=False)

    wall = MT.create_1D_line(-0.5, 0)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.0,
                        DistMax=0.2)

    vac_L = MT.create_1D_line(-0.01, 1, embed=wall)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.0,
                        DistMax=0.2)

    plate = MT.create_1D_line(0.99, 1.1, embed=vac_L)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.05,
                        DistMax=0.2)

    MT.create_1D_line(1.09, 1000, embed=plate)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.05,
                        DistMax=0.2)

    MT.generate_mesh(filename, show_mesh)
    MT.msh_2_xdmf(filename, auto_override=True)

    return filename


def make_density_func(p):

    def f(x):
        return p

    return f


' --------------------------------------------------------------------------- '
' ---------------------- Two-layer case (single plate) ---------------------- '
' --------------------------------------------------------------------------- '


if False:

    compare = False  # For comparing with the numeric solution.

    # Choose parameters.
    vac_VEV = 1
    vac_rho = 1

    vac_Cwl_1 = 1
    vac_Cwl_2 = 5
    vac_Cwl_3 = 10

    P_L = vac_rho*1e2
    P_V = vac_rho

    # Compute model parameters : Lambda & M.
    Lambda_1 = (0.5*(vac_VEV**3)/(vac_Cwl_1**2))**0.2
    Lambda_2 = (0.5*(vac_VEV**3)/(vac_Cwl_2**2))**0.2
    Lambda_3 = (0.5*(vac_VEV**3)/(vac_Cwl_3**2))**0.2

    M_1 = 2*(vac_Cwl_1**2)*vac_rho/vac_VEV
    M_2 = 2*(vac_Cwl_2**2)*vac_rho/vac_VEV
    M_3 = 2*(vac_Cwl_3**2)*vac_rho/vac_VEV

    # Compute wall VEV's (rescaled by vacuum VEV).
    wall_VEV_L = np.sqrt(P_V/P_L)

    # Compute analytic solution.
    z = np.linspace(-2, 10, 11001)

    func_1, _, _ = planar_solution(Lambda_1, M_1,
                                   densities=np.array([P_L, P_V]),
                                   boundary_positions=np.array([0.0]))

    func_2, _, _ = planar_solution(Lambda_2, M_2,
                                   densities=np.array([P_L, P_V]),
                                   boundary_positions=np.array([0.0]))

    func_3, _, _ = planar_solution(Lambda_3, M_3,
                                   densities=np.array([P_L, P_V]),
                                   boundary_positions=np.array([0.0]))

    field_anal_1 = func_1(z)
    field_anal_2 = func_2(z)
    field_anal_3 = func_3(z)

    # Solve numerically.
    if compare:
        alpha_1 = 2*vac_Cwl_1**2
        alpha_2 = 2*vac_Cwl_2**2
        alpha_3 = 2*vac_Cwl_3**2

        mesh_name = create_mesh_single_plates(show_mesh=False)

        left = make_density_func(P_L)
        vacuum = make_density_func(P_V)

        #
        s1 = Chameleon(alpha_1, n=1, mesh_name=mesh_name, dimension=1,
                       symmetry="translation symmetry")

        s1.solve_static(density_profiles=[left, vacuum], maxiter=20)

        field_numc_1 = np.array([s1.field(zi, 0) for zi in z])

        #
        s2 = Chameleon(alpha_2, n=1, mesh_name=mesh_name, dimension=1,
                       symmetry="translation symmetry")

        s2.solve_static(density_profiles=[left, vacuum], maxiter=20)

        field_numc_2 = np.array([s2.field(zi, 0) for zi in z])

        #
        s3 = Chameleon(alpha_3, n=1, mesh_name=mesh_name, dimension=1,
                       symmetry="translation symmetry")

        s3.solve_static(density_profiles=[left, vacuum], maxiter=20)

        field_numc_3 = np.array([s3.field(zi, 0) for zi in z])

    # Plot comparison.
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.set_ylabel(r"$\phi/\phi^{EV}_R$")
    ax.set_xlabel("$z/L$")
    ax.set_xlim([-2, 10])

    # Fill in mirror regions.
    ax.axvspan(-2, 0, alpha=0.4)

    ax.plot(z, field_anal_1, label=r"$\lambda_R = %i \, L$" % vac_Cwl_1)
    ax.plot(z, field_anal_2, label=r"$\lambda_R = %i \, L$" % vac_Cwl_2)
    ax.plot(z, field_anal_3, label=r"$\lambda_R = %i \, L$" % vac_Cwl_3)

    if compare:
        ax.plot(z, field_numc_1, linestyle="dashed", color="k")
        ax.plot(z, field_numc_2, linestyle="dashed", color="k")
        ax.plot(z, field_numc_3, linestyle="dashed", color="k")

    ax.axhline(wall_VEV_L, linestyle="dashdot", color="r")
    ax.axhline(1.0, linestyle="dashed", color="k")

    ax.legend(bbox_to_anchor=(0.50, 0.05, 0.50, 0.45))
    plt.show()

    if compare is False:
        fig.savefig("Plots(new)/Two-layers", dpi=300, bbox_inches='tight')

    # Check differences between numeric and analytic.
    if compare:
        fig, ax = plt.subplots(figsize=(8, 6))
        ax.set_ylabel(r"$\Delta \hat{\phi}$")
        ax.set_xlabel("z")
        ax.set_xlim([-1.6, 1.6])
        plt.yscale('log')

        plt.plot(z, abs(field_numc_1-field_anal_1), label="1")
        plt.plot(z, abs(field_numc_2-field_anal_2), label="2")
        plt.plot(z, abs(field_numc_3-field_anal_3), label="3")

        plt.legend()
        plt.show()


' -------------------------------------------------------------------------- '
' ------------------- Three-layer case (parallel plates) ------------------- '
' -------------------------------------------------------------------------- '


if False:

    compare = False  # For comparing with the numeric solution.

    # Choose parameters.
    vac_VEV = 1
    vac_rho = 1

    vac_Cwl_1 = 200
    vac_Cwl_2 = 500
    vac_Cwl_3 = 900

    P_R = vac_rho*1e4
    P_L = vac_rho*1e5
    P_V = vac_rho

    # Compute model parameters : Lambda & M.
    Lambda_1 = (0.5*(vac_VEV**3)/(vac_Cwl_1**2))**0.2
    Lambda_2 = (0.5*(vac_VEV**3)/(vac_Cwl_2**2))**0.2
    Lambda_3 = (0.5*(vac_VEV**3)/(vac_Cwl_3**2))**0.2

    M_1 = 2*(vac_Cwl_1**2)*vac_rho/vac_VEV
    M_2 = 2*(vac_Cwl_2**2)*vac_rho/vac_VEV
    M_3 = 2*(vac_Cwl_3**2)*vac_rho/vac_VEV

    # Compute wall VEV's (rescaled by vacuum VEV).
    wall_VEV_L = np.sqrt(P_V/P_L)
    wall_VEV_R = np.sqrt(P_V/P_R)

    # Compute analytic solution.
    z = np.linspace(-1.6, 1.6, 1001)

    func_1, _, _ = planar_solution(Lambda_1, M_1,
                                   densities=np.array([P_L, P_V, P_R]),
                                   boundary_positions=np.array([-0.5, +0.5]))

    func_2, _, _ = planar_solution(Lambda_2, M_2,
                                   densities=np.array([P_L, P_V, P_R]),
                                   boundary_positions=np.array([-0.5, +0.5]))

    func_3, _, _ = planar_solution(Lambda_3, M_3,
                                   densities=np.array([P_L, P_V, P_R]),
                                   boundary_positions=np.array([-0.5, +0.5]),
                                   boundary_guess=np.array([0.005, 0.0125]))

    field_anal_1 = func_1(z)
    field_anal_2 = func_2(z)
    field_anal_3 = func_3(z)

    # Solve numerically.
    if compare:
        alpha_1 = 2*vac_Cwl_1**2
        alpha_2 = 2*vac_Cwl_2**2
        alpha_3 = 2*vac_Cwl_3**2

        mesh_name = create_mesh_parellel_plates(show_mesh=False)

        left = make_density_func(P_L)
        right = make_density_func(P_R)
        vacuum = make_density_func(P_V)

        #
        s1 = Chameleon(alpha_1, n=1, mesh_name=mesh_name, dimension=1,
                       symmetry="translation symmetry")

        s1.solve_static(density_profiles=[left, right, vacuum], tol_du=1e-12)

        field_numc_1 = np.array([s1.field(zi, 0) for zi in z])

        #
        s2 = Chameleon(alpha_2, n=1, mesh_name=mesh_name, dimension=1,
                       symmetry="translation symmetry")

        s2.solve_static(density_profiles=[left, right, vacuum], tol_du=1e-12)

        field_numc_2 = np.array([s2.field(zi, 0) for zi in z])

        #
        s3 = Chameleon(alpha_3, n=1, mesh_name=mesh_name, dimension=1,
                       symmetry="translation symmetry")

        s3.solve_static(density_profiles=[left, right, vacuum], tol_du=1e-12)

        field_numc_3 = np.array([s3.field(zi, 0) for zi in z])

    # Plot comparison.
    # fig, ax = plt.subplots(figsize=(8, 6)) (1)
    fig, ax = plt.subplots(figsize=(8, 5.5))
    ax.set_ylabel(r"$\phi/\phi^{EV}_V$")
    ax.set_xlabel("$z/L$")
    ax.set_xlim([-1.6, 1.6])

    # Fill in mirror regions.
    ax.axvspan(-1.6, -0.5, alpha=0.4)
    ax.axvspan(+0.5, +1.6, alpha=0.4)

    # ax.axvline(-1/2, linestyle="dashed", color="k")
    # ax.axvline(+1/2, linestyle="dashed", color="k")

    ax.plot(z, field_anal_1, label=r"$\lambda_V = %i \, L$" % vac_Cwl_1)
    ax.plot(z, field_anal_2, label=r"$\lambda_V = %i \, L$" % vac_Cwl_2)
    ax.plot(z, field_anal_3, label=r"$\lambda_V = %i \, L$" % vac_Cwl_3)

    if compare:
        ax.plot(z, field_numc_1, linestyle="dashed", color="k")
        ax.plot(z, field_numc_2, linestyle="dashed", color="k")
        ax.plot(z, field_numc_3, linestyle="dashed", color="k")

    ax.axhline(wall_VEV_L, linestyle="dashdot", color="r")
    ax.axhline(wall_VEV_R, linestyle="dashed", color="k")

    ax.legend(loc="upper left")
    plt.show()

    if compare is False:
        fig.savefig("Plots(new)/Three-layers", dpi=300, bbox_inches='tight')

    # Check differences between numeric and analytic.
    if compare:
        fig, ax = plt.subplots(figsize=(8, 6))
        ax.set_ylabel(r"$\Delta \hat{\phi}$")
        ax.set_xlabel("z")
        ax.set_xlim([-1.6, 1.6])
        plt.yscale('log')

        plt.plot(z, abs(field_numc_1-field_anal_1), label="1")
        plt.plot(z, abs(field_numc_2-field_anal_2), label="2")
        plt.plot(z, abs(field_numc_3-field_anal_3), label="3")

        plt.legend()
        plt.show()


' --------------------------------------------------------------------------- '
' ------------------ Four-layer case (Casimir plate setup) ------------------ '
' --------------------------------------------------------------------------- '


# Vary Compton wavelength.
if False:

    compare = False  # For comparing with the numeric solution.

    # Choose parameters.
    vac_VEV = 1
    vac_rho = 1

    vac_Cwl_1 = 1
    vac_Cwl_2 = 2
    vac_Cwl_3 = 5

    P_Wl = vac_rho*1e4
    P_V1 = vac_rho
    P_Pl = vac_rho*100
    P_V2 = vac_rho

    # Compute model parameters : Lambda & M.
    Lambda_1 = (0.5*(vac_VEV**3)/(vac_Cwl_1**2))**0.2
    Lambda_2 = (0.5*(vac_VEV**3)/(vac_Cwl_2**2))**0.2
    Lambda_3 = (0.5*(vac_VEV**3)/(vac_Cwl_3**2))**0.2

    M_1 = 2*(vac_Cwl_1**2)*vac_rho/vac_VEV
    M_2 = 2*(vac_Cwl_2**2)*vac_rho/vac_VEV
    M_3 = 2*(vac_Cwl_3**2)*vac_rho/vac_VEV

    # Compute wall VEV's (rescaled by vacuum VEV).
    wall_VEV_Wl = np.sqrt(vac_VEV/P_Wl)
    wall_VEV_Pl = np.sqrt(vac_VEV/P_Pl)

    # Compute analytic solution.
    z = np.linspace(-0.1, 2, 1001)

    func_1, _, _ = planar_solution(
        Lambda_1, M_1, densities=np.array([P_Wl, P_V1, P_Pl, P_V2]),
        boundary_positions=np.array([0, 1, 1.1]),
        boundary_guess=np.array([0.1, 0.2, 0.2]))

    func_2, _, _ = planar_solution(
        Lambda_2, M_2, densities=np.array([P_Wl, P_V1, P_Pl, P_V2]),
        boundary_positions=np.array([0, 1, 1.1]),
        boundary_guess=np.array([0.1, 0.2, 0.2]))

    func_3, _, _ = planar_solution(
        Lambda_3, M_3, densities=np.array([P_Wl, P_V1, P_Pl, P_V2]),
        boundary_positions=np.array([0, 1, 1.1]),
        boundary_guess=np.array([0.01, 0.25, 0.30]))

    field_anal_1 = func_1(z)
    field_anal_2 = func_2(z)
    field_anal_3 = func_3(z)

    # Solve numerically.
    if compare:
        alpha_1 = 2*vac_Cwl_1**2
        alpha_2 = 2*vac_Cwl_2**2
        alpha_3 = 2*vac_Cwl_3**2

        mesh_name = create_mesh_casimir_plates(show_mesh=False)

        wall = make_density_func(P_Wl)
        vacuum_1 = make_density_func(P_V1)
        plate = make_density_func(P_Pl)
        vacuum_2 = make_density_func(P_V2)

        #
        s1 = Chameleon(alpha_1, n=1, mesh_name=mesh_name, dimension=1,
                       symmetry="translation symmetry")

        s1.solve_static(density_profiles=[wall, vacuum_1, plate, vacuum_2],
                        tol_du=1e-12, maxiter=25)

        field_numc_1 = np.array([s1.field(zi, 0) for zi in z])

        #
        s2 = Chameleon(alpha_2, n=1, mesh_name=mesh_name, dimension=1,
                       symmetry="translation symmetry")

        s2.solve_static(density_profiles=[wall, vacuum_1, plate, vacuum_2],
                        tol_du=1e-12, maxiter=25)

        field_numc_2 = np.array([s2.field(zi, 0) for zi in z])

        #
        s3 = Chameleon(alpha_3, n=1, mesh_name=mesh_name, dimension=1,
                       symmetry="translation symmetry")

        s3.solve_static(density_profiles=[wall, vacuum_1, plate, vacuum_2],
                        tol_du=1e-12, maxiter=25)

        field_numc_3 = np.array([s3.field(zi, 0) for zi in z])

    # Plot comparison.
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.set_ylabel(r"$\phi/\phi^{EV}_V$")
    ax.set_xlabel("$z/L$")
    ax.set_xlim([-0.1, 2])

    # Fill in mirror regions.
    ax.axvspan(-0.1, 0, alpha=0.4)
    ax.axvspan(1, 1.1, alpha=0.4, color="grey")

    ax.plot(z, field_anal_1, label=r"$\lambda_V = %i \ L$" % vac_Cwl_1)
    ax.plot(z, field_anal_2, label=r"$\lambda_V = %i \ L$" % vac_Cwl_2)
    ax.plot(z, field_anal_3, label=r"$\lambda_V = %i \ L$" % vac_Cwl_3)

    if compare:
        ax.plot(z, field_numc_1, linestyle="dashed", color="k")
        ax.plot(z, field_numc_2, linestyle="dashed", color="k")
        ax.plot(z, field_numc_3, linestyle="dashed", color="k")

    ax.axhline(wall_VEV_Wl, linestyle="dashed", color="k")
    ax.axhline(wall_VEV_Pl, linestyle="dashdot", color="r")

    ax.legend(bbox_to_anchor=(0.05, 0.55, 0.5, 0.45))
    plt.show()

    if compare is False:
        fig.savefig("Plots(new)/Four-layers(Compton)", dpi=300,
                    bbox_inches='tight')

    # Check differences between numeric and analytic.
    if compare:
        fig, ax = plt.subplots(figsize=(8, 6))
        ax.set_ylabel(r"$\Delta \hat{\phi}$")
        ax.set_xlabel("z")
        ax.set_xlim([-2, 2])
        plt.yscale('log')

        plt.plot(z, abs(field_numc_1-field_anal_1), label="1")
        plt.plot(z, abs(field_numc_2-field_anal_2), label="2")
        plt.plot(z, abs(field_numc_3-field_anal_3), label="3")

        plt.legend()
        plt.show()


' --------------------------------------------------------------------------- '


# Vary plate density.
if False:

    compare = False  # For comparing with the numeric solution.

    # Choose parameters.
    vac_VEV = 1
    vac_rho = 1
    vac_Cwl = 1

    P_Wl = vac_rho*1e4
    P_V1 = vac_rho
    P_V2 = vac_rho

    P_Pl_1 = vac_rho*10
    P_Pl_2 = vac_rho*100
    P_Pl_3 = vac_rho*300

    # Compute model parameters : Lambda & M.
    Lambda = (0.5*(vac_VEV**3)/(vac_Cwl**2))**0.2
    M = 2*(vac_Cwl**2)*vac_rho/vac_VEV

    # Compute wall VEV's (rescaled by vacuum VEV).
    wall_VEV_Wl = np.sqrt(vac_VEV/P_Wl)
    wall_VEV_Pl_1 = np.sqrt(vac_VEV/P_Pl_1)
    wall_VEV_Pl_2 = np.sqrt(vac_VEV/P_Pl_2)
    wall_VEV_Pl_3 = np.sqrt(vac_VEV/P_Pl_3)

    # Compute analytic solution.
    z = np.linspace(-0.1, 2, 1001)

    func_1, _, _ = planar_solution(
        Lambda, M, densities=np.array([P_Wl, P_V1, P_Pl_1, P_V2]),
        boundary_positions=np.array([0.0, 1.0, 1.1]),
        boundary_guess=np.array([0.01, 0.65, 0.67]))

    func_2, _, _ = planar_solution(
        Lambda, M, densities=np.array([P_Wl, P_V1, P_Pl_2, P_V2]),
        boundary_positions=np.array([0.0, 1.0, 1.1]))

    func_3, _, _ = planar_solution(
        Lambda, M, densities=np.array([P_Wl, P_V1, P_Pl_3, P_V2]),
        boundary_positions=np.array([0.0, 1.0, 1.1]))

    field_anal_1 = func_1(z)
    field_anal_2 = func_2(z)
    field_anal_3 = func_3(z)

    # Solve numerically.
    if compare:
        alpha = 2*vac_Cwl**2

        mesh_name = create_mesh_casimir_plates(show_mesh=False)

        wall = make_density_func(P_Wl)
        vacuum_1 = make_density_func(P_V1)
        vacuum_2 = make_density_func(P_V2)

        plate_1 = make_density_func(P_Pl_1)
        plate_2 = make_density_func(P_Pl_2)
        plate_3 = make_density_func(P_Pl_3)

        #
        s1 = Chameleon(alpha, n=1, mesh_name=mesh_name, dimension=1,
                       symmetry="translation symmetry")

        s1.solve_static(density_profiles=[wall, vacuum_1, plate_1, vacuum_2],
                        tol_du=1e-12, maxiter=25)

        field_numc_1 = np.array([s1.field(zi, 0) for zi in z])

        #
        s2 = Chameleon(alpha, n=1, mesh_name=mesh_name, dimension=1,
                       symmetry="translation symmetry")

        s2.solve_static(density_profiles=[wall, vacuum_1, plate_2, vacuum_2],
                        tol_du=1e-12, maxiter=25)

        field_numc_2 = np.array([s2.field(zi, 0) for zi in z])

        #
        s3 = Chameleon(alpha, n=1, mesh_name=mesh_name, dimension=1,
                       symmetry="translation symmetry")

        s3.solve_static(density_profiles=[wall, vacuum_1, plate_3, vacuum_2],
                        tol_du=1e-12, maxiter=25)

        field_numc_3 = np.array([s3.field(zi, 0) for zi in z])

    # Plot comparison.
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.set_ylabel(r"$\phi/\phi^{EV}_V$")
    ax.set_xlabel(r"$z/\lambda_V$")
    ax.set_xlim([-0.1, 2])

    tick_values = np.linspace(0.0, 0.9, 10)
    ax.set_yticks(ticks=tick_values)

    # Fill in mirror regions.
    ax.axvspan(-0.1, 0, alpha=0.4)
    ax.axvspan(1, 1.1, alpha=0.4, color="grey")

    ax.axhline(wall_VEV_Pl_1, linestyle="dashdot", color="C0")
    ax.axhline(wall_VEV_Pl_2, linestyle="dashdot", color="C1")
    ax.axhline(wall_VEV_Pl_3, linestyle="dashdot", color="C2")

    ax.plot(z, field_anal_1, label=r"$\rho=%i \, \rho_V$" % P_Pl_1, color="C0")
    ax.plot(z, field_anal_2, label=r"$\rho=%i \, \rho_V$" % P_Pl_2, color="C1")
    ax.plot(z, field_anal_3, label=r"$\rho=%i \, \rho_V$" % P_Pl_3, color="C2")

    if compare:
        ax.plot(z, field_numc_1, linestyle="dashed", color="k")
        ax.plot(z, field_numc_2, linestyle="dashed", color="k")
        ax.plot(z, field_numc_3, linestyle="dashed", color="k")

    ax.axhline(wall_VEV_Wl, linestyle="dashed", color="k")

    ax.legend(bbox_to_anchor=(0.05, 0.55, 0.5, 0.45))
    plt.show()

    if compare is False:
        fig.savefig("Plots(new)/Four-layers(plate)", dpi=300,
                    bbox_inches='tight')

    # Check differences between numeric and analytic.
    if compare:
        fig, ax = plt.subplots(figsize=(8, 6))
        ax.set_ylabel(r"$\Delta \hat{\phi}$")
        ax.set_xlabel("z")
        ax.set_xlim([-2, 2])
        plt.yscale('log')

        plt.plot(z, abs(field_numc_1-field_anal_1), label="1")
        plt.plot(z, abs(field_numc_2-field_anal_2), label="2")
        plt.plot(z, abs(field_numc_3-field_anal_3), label="3")

        plt.legend()
        plt.show()
