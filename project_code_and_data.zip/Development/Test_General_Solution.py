#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 11 11:55:52 2025

@author: chad-briddon

Generate the general solution for the field between two plates
(not nessisarily with the same density).

*This code ran using SELCIE v2.0.0.

"""

import numpy as np
import dolfin as d
import matplotlib.pyplot as plt

from scipy.optimize import fsolve
from SELCIE.Mesh import MeshingTools_1D
from SELCIE.Solvers import Chameleon
from scipy.special import ellipj, ellipk, ellipkinc, ellipeinc


' --------------------------- Analytic functions --------------------------- '


def K(m):
    return ellipk(m**2)


def F(u, m):
    return ellipkinc(u, m**2)


def E(u, m):
    return ellipeinc(u, m**2)


def sn(u, m):
    return ellipj(u, m**2)[0]


def Sn(u, k):

    t = np.linspace(0, u, 1000)
    sn2 = sn(t, k)**2

    return np.trapz(sn2, t)


def inverse_Sn(y, k, range_=(0, np.pi)):
    'Since sn is monotoic function, use bisection method to find its inverse.'
    'Find f(x) = Sn(x, k) - y = 0.'

    inv = []
    for yi in y:

        a, b = range_
        while abs(b-a) > 1e-10:

            c = (b+a)/2

            if Sn(c, k) - yi > 0:
                b = c
            else:
                a = c

        inv.append(c)

    return np.array(inv)


def Sn_diff(a, b, k):

    t = np.linspace(a, b, 10000)
    sn2 = sn(t, k)**2

    return np.trapz(sn2, t)


' --------------------------------------------------------------------------- '
' ----------------- Functions specific to chameleon profile ----------------- '
' --------------------------------------------------------------------------- '


class Chameleon_Parallel_Plates_Solution():
    def __init__(self, omega_L, omega_R, alpha, L):

        self.omega_L = omega_L
        self.omega_R = omega_R
        self.alpha = alpha
        self.L = L

        return None

    def x_wall_L(self, k):
        return 1 - ((k - self.omega_L)**2)/((k**2)*(1 - self.omega_L**2))

    def x_wall_R(self, k):
        return 1 - ((k - self.omega_R)**2)/((k**2)*(1 - self.omega_R**2))

    def zeta_L_mag(self, k):

        Lv = np.sqrt(2*self.alpha*(k**3))

        x_wall_L = self.x_wall_L(k)
        theta = np.arcsin(np.sqrt(x_wall_L))

        a = F(theta, k)
        b = K(k)

        return Lv*Sn_diff(a, b, k)

    def zeta_R_mag(self, k):

        Lv = np.sqrt(2*self.alpha*(k**3))

        x_wall_R = self.x_wall_R(k)
        theta = np.arcsin(np.sqrt(x_wall_R))

        a = F(theta, k)
        b = K(k)

        return Lv*Sn_diff(a, b, k)

    def k_residual_small_lambda(self, k):

        k_value = k[0]

        zeta_L_mag = self.zeta_L_mag(k_value)
        zeta_R_mag = self.zeta_R_mag(k_value)

        k_res = self.L - zeta_L_mag - zeta_R_mag

        return np.array(k_res)

    def k_residual_large_lambda(self, k):

        k_value = k[0]

        zeta_L_mag = self.zeta_L_mag(k_value)
        zeta_R_mag = self.zeta_R_mag(k_value)

        if self.omega_L < self.omega_R:
            k_res = self.L - zeta_L_mag + zeta_R_mag

        else:
            k_res = self.L + zeta_L_mag - zeta_R_mag

        return np.array(k_res)

    def monotoic_compton_limit(self):

        x_wall_L = self.x_wall_L(self.omega_R)

        theta = np.arcsin(np.sqrt(x_wall_L))

        a = F(theta, omega_R)
        b = K(omega_R)

        compton_wl = L/(2*(omega_R**1.5)*Sn_diff(a, b, omega_R))

        return compton_wl

    def k_residual(self, k):

        # Check which regime we are in first.
        compton_critical = self.monotoic_compton_limit()

        compton_vacuum = np.sqrt(self.alpha/2)

        if compton_vacuum < compton_critical:
            k_res = self.k_residual_small_lambda(k)
        else:
            k_res = self.k_residual_large_lambda(k)

        return k_res

    def get_k(self, k0):

        k = fsolve(self.k_residual, x0=np.array(k0), xtol=1e-12)[0]

        return k

    def field_profile_vacuum(self, x, k):

        Lv = np.sqrt(2*self.alpha*(k**3))

        zeta_L = self.zeta_L_mag(k)
        zeta_R = self.zeta_R_mag(k)

        zeta = x + 0.5*np.sign(k - self.omega_R)*zeta_R \
            - 0.5*np.sign(k - self.omega_L)*zeta_L

        y_Anal = Sn(K(k), k) - abs(zeta)/Lv

        theta_Anal = inverse_Sn(y_Anal, k)

        field_Anal = k*sn(theta_Anal, k)**2

        return field_Anal

    def field_mirror_L_residual(self, field, z, k):

        compton_mirror_L = np.sqrt(self.alpha/2)*(self.omega_L**1.5)

        field_wall_L = k*self.x_wall_L(k)

        Y1 = np.sqrt(field/self.omega_L) - np.sqrt(field_wall_L/self.omega_L)

        Y2 = np.sqrt((np.sqrt(field) - np.sqrt(self.omega_L))
                     / (np.sqrt(field_wall_L) - np.sqrt(self.omega_L)))

        Y3 = np.sqrt((np.sqrt(field) + np.sqrt(self.omega_L))
                     / (np.sqrt(field_wall_L) + np.sqrt(self.omega_L)))

        res = (Y2/Y3)*np.exp(Y1) - np.exp((0.5*L + z)/(2*compton_mirror_L))

        return np.array(res)

    def field_mirror_R_residual(self, field, z, k):

        compton_mirror_R = np.sqrt(self.alpha/2)*(self.omega_R**1.5)

        field_wall_R = k*self.x_wall_R(k)

        Y1 = np.sqrt(field/self.omega_R) - np.sqrt(field_wall_R/self.omega_R)

        Y2 = np.sqrt((np.sqrt(field) - np.sqrt(self.omega_R))
                     / (np.sqrt(field_wall_R) - np.sqrt(self.omega_R)))

        Y3 = np.sqrt((np.sqrt(field) + np.sqrt(self.omega_R))
                     / (np.sqrt(field_wall_R) + np.sqrt(self.omega_R)))

        res = (Y2/Y3)*np.exp(Y1) - np.exp((0.5*L - z)/(2*compton_mirror_R))

        return np.array(res)

    def field_profile_mirror_L(self, z, k, tol=1e-10):

        range_ = (min(self.omega_L, self.omega_R),
                  max(self.omega_L, self.omega_R, k))

        # Add sign flip to residual.
        if self.omega_L < k:
            sig = +1
        else:
            sig = -1

        inv = []
        for zi in z:

            a, b = range_
            while abs(b-a) > tol:

                c = (b+a)/2

                if sig*self.field_mirror_L_residual(c, zi, k) > 0:
                    b = c
                else:
                    a = c

            inv.append(c)

        field = np.array(inv)

        return field

    def field_profile_mirror_R(self, z, k, tol=1e-10):

        range_ = (min(self.omega_L, self.omega_R),
                  max(self.omega_L, self.omega_R, k))

        # Add sign flip to residual.
        if self.omega_R < k:
            sig = +1
        else:
            sig = -1

        inv = []
        for zi in z:

            a, b = range_
            while abs(b-a) > tol:

                c = (b+a)/2

                if sig*self.field_mirror_R_residual(c, zi, k) > 0:
                    b = c
                else:
                    a = c

            inv.append(c)

        field = np.array(inv)

        return field

    def field_profile(self, z, k):

        field = self.field_profile_vacuum(z, k)

        for i, zi in enumerate(z):

            if zi > 0.5:
                field[i] = self.field_profile_mirror_R([zi], k)[0]

            elif zi < -0.5:
                field[i] = self.field_profile_mirror_L([zi], k)[0]

        return field


' -------------------------------------------------------------------------- '
' ------------------------- Functions for numerics ------------------------- '
' -------------------------------------------------------------------------- '


def create_mesh_parellel_plates(show_mesh=True):

    filename = "parellel_plates"

    # Make mesh.
    MT = MeshingTools_1D(display_messages=False)

    plate_L = MT.create_1D_line(-1.6, -0.5)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.010, DistMin=0.0,
                        DistMax=0.1)

    plate_R = MT.create_1D_line(0.5, 2.6)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.010, DistMin=0.0,
                        DistMax=0.1)

    MT.create_1D_line(-0.51, 0.51,
                      embed=plate_L+plate_R)
    MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.001, DistMin=0.05,
                        DistMax=0.1)

    MT.generate_mesh(filename, show_mesh)
    MT.msh_2_xdmf(filename, auto_override=True)

    return filename


def make_density_func(p):

    def f(x):
        return p

    return f


if __name__ == "__main__":

    ' -------------------- Plot output of each function -------------------- '

    # Set parameters.
    P_R = 1e4
    P_L = 1e5
    P_V = 1

    alpha = 2e5
    L = 1

    omega_L = np.sqrt(P_V/P_L)
    omega_R = np.sqrt(P_V/P_R)

    C = Chameleon_Parallel_Plates_Solution(omega_L, omega_R, alpha, L)

    k_array = np.linspace(0, 1, 100, endpoint=False)

    # Field value at wall.
    x_wall_L = np.array([C.x_wall_L(ki) for ki in k_array])
    x_wall_R = np.array([C.x_wall_R(ki) for ki in k_array])

    plt.figure()
    plt.xlabel("k")
    plt.yscale("log")

    plt.axvline(omega_L, linestyle="dashed", label=r"$\omega_L$")
    plt.axvline(omega_R, linestyle="dashed", label=r"$\omega_R$")

    plt.plot(k_array, x_wall_L, label=r"$x_L$")
    plt.plot(k_array, x_wall_R, label=r"$x_R$")

    plt.legend()

    # Position of walls in zeta-coordinates.
    zeta_L = np.array([C.zeta_L_mag(ki) for ki in k_array])
    zeta_R = np.array([C.zeta_R_mag(ki) for ki in k_array])

    plt.figure()
    plt.xlabel("k")
    plt.yscale("log")

    plt.axhline(L, linestyle="dashed", color="k", label="L")
    plt.axhline(L/2, linestyle="dashed", color="r", label="L/2")

    plt.plot(k_array, zeta_L, label=r"$\zeta_L$")
    plt.plot(k_array, zeta_R, label=r"$\zeta_R$")
    # plt.plot(k_array, zeta_L-zeta_R-L)

    plt.legend()

    # Plot residual of function for k.
    k_res = np.array([C.k_residual(np.array([ki])) for ki in k_array])

    plt.figure()
    plt.ylabel("Res")
    plt.xlabel("k")
    plt.xscale('log')
    plt.plot(k_array, k_res)

    # Get root and add to plot.
    k = C.get_k(0.00714)
    plt.plot([k], [0.0], marker=".", color="r")

    ' --------------------- Plot numeric field profile --------------------- '

    mesh_name = create_mesh_parellel_plates(show_mesh=False)

    left = make_density_func(P_L)
    right = make_density_func(P_R)
    vacuum = make_density_func(P_V)

    s = Chameleon(alpha, n=1, mesh_name=mesh_name, dimension=1,
                  symmetry="translation symmetry")

    s.solve_static(density_profiles=[left, right, vacuum], tol_du=1e-12)

    z = np.linspace(-1.6, 1.6, 1000)

    field_numc = np.array([s.field(zi, 0) for zi in z])

    plt.figure()
    plt.ylabel(r"$\hat{\phi}$")
    plt.xlabel("z")

    plt.plot(z, field_numc, label="Numeric", linestyle="solid")

    ' --------------------- Plot analytic field profile --------------------- '

    zeta_L = C.zeta_L_mag(k)
    zeta_R = C.zeta_R_mag(k)

    z = np.linspace(-1, 1, 1000)
    field_vac = C.field_profile_vacuum(z, k)
    field_anal = C.field_profile(z, k)

    plt.plot(z, field_vac, label="Analytic", linestyle="dashed")
    plt.plot(z, field_anal, label="Analytic", linestyle="dashed")

    plt.axhline(C.omega_L, linestyle="dashdot", color="r",
                label=r"$\hat{\phi}_L$")

    plt.axhline(C.omega_R, linestyle="dashdot", color="k",
                label=r"$\hat{\phi}_R$")

    plt.legend()

    print("Numeric  : k = %f" % d.norm(s.field.vector(), 'linf'))
    print("Analytic : k = %f" % k)

    ' ------------------- Compute vacumm monotopic limit ------------------- '

    compton_wl = C.monotoic_compton_limit()

    print()
    print(2*compton_wl**2)

    plt.figure()

    z1 = np.linspace(0.5, 4.0, 1000)
    z2 = np.linspace(-0.5, -1.6, 1000)

    phi_R = C.field_profile_mirror_R(z1, k)
    phi_L = C.field_profile_mirror_L(z2, k)

    plt.plot(z1, phi_R)
    plt.plot(z2, phi_L)

    ' ---------------- Check solution is correct for large k ---------------- '

    P_R = 1e10
    P_L = 1e10
    P_V = 1

    alpha = 1
    L = 1

    z = np.linspace(-0.6, 0.6, 1000)

    omega_L = np.sqrt(P_V/P_L)
    omega_R = np.sqrt(P_V/P_R)

    C = Chameleon_Parallel_Plates_Solution(omega_L, omega_R, alpha, L)
    k = C.get_k(0.00714)

    field_anal = C.field_profile(z, k)

    # Get numeric also.
    mesh_name = create_mesh_parellel_plates(show_mesh=False)

    left = make_density_func(P_L)
    right = make_density_func(P_R)
    vacuum = make_density_func(P_V)

    s = Chameleon(alpha, n=1, mesh_name=mesh_name, dimension=1,
                  symmetry="translation symmetry")

    s.solve_static(density_profiles=[left, right, vacuum], tol_du=1e-12)

    field_numc = np.array([s.field(zi, 0) for zi in z])

    plt.figure()
    plt.ylabel(r"$\hat{\phi}$")
    plt.xlabel(r"$z$")

    plt.plot(z, field_anal, label="anal")
    plt.plot(z, field_numc, label="numc")

    plt.legend()
