#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Feb 28 18:41:55 2026

@author: chad-briddon

Compare bisection and Newton methods for inverting transindental equations.

Result : Bisection method is slightly faster.

"""

import numpy as np
import matplotlib.pyplot as plt

from timeit import default_timer as dt
from scipy.optimize import newton


def exterior_bisection(field_VEV, compton_WL, z_boundary, field_boundary, z):
    '''
    Generate solution inside exterior regions, see Eq.~(9).

    Parameters
    ----------
    field_VEV : float
        VEV corresponding to region.
    compton_WL : float
        Compton wavelength corresponding to field VEV.
    z_boundary : float
        Location of the boundary.
    field_boundary : float
        Value of field at boundary.

    z : numpy.array
        Position values to be evaluated.

    Returns
    -------
    field : numpy.array
        Field values at positions z.

    '''

    x_b = np.sqrt(field_boundary/field_VEV)  # Rescaled.

    constant = np.exp(2*x_b)*(x_b - 1)/(x_b + 1)

    # Invert the function and iterate over all inputted z-values.
    inv = []
    for zi in z:

        def residual(x):
            return (np.exp(2*x)*(x - 1)/(x + 1)
                    - constant*np.exp(-abs(zi-z_boundary)/compton_WL))

        # Use Bisection method
        a = min(1, x_b)
        b = max(1, x_b)
        c = (b+a)/2

        while abs(b-a) > 1e-14:

            c = (b+a)/2

            if residual(c) > 0:
                b = c
            else:
                a = c

        x = (b+a)/2

        inv.append(x)

    field = field_VEV*np.array(inv)**2

    return field


def exterior_Newton1(field_VEV, compton_WL, z_boundary, field_boundary, z):
    '''
    Generate solution inside exterior regions, see Eq.~(9).

    Parameters
    ----------
    field_VEV : float
        VEV corresponding to region.
    compton_WL : float
        Compton wavelength corresponding to field VEV.
    z_boundary : float
        Location of the boundary.
    field_boundary : float
        Value of field at boundary.

    z : numpy.array
        Position values to be evaluated.

    Returns
    -------
    field : numpy.array
        Field values at positions z.

    '''

    x_b = np.sqrt(field_boundary/field_VEV)  # Rescaled.
    x_0 = (1 + x_b)/2  # Starting point for Newton method.

    constant = np.exp(2*x_b)*(x_b - 1)/(x_b + 1)

    # Invert the function and iterate over all inputted z-values.
    inv = []
    for zi in z:

        def residual(x):
            return (np.exp(2*x)*(x - 1)/(x + 1)
                    - constant*np.exp(-abs(zi-z_boundary)/compton_WL))

        # Use Newton method.
        inv.append(newton(residual, x0=x_0))

    field = field_VEV*np.array(inv)**2

    return field


def fprime(x):
    return 2*np.exp(2*x)*(x**2)/(x+1)**2


def fprime2(x):
    return 4*x*np.exp(2*x)*(x**2 + x + 1)/(x+1)**3


def exterior_Newton2(field_VEV, compton_WL, z_boundary, field_boundary, z):
    '''
    Generate solution inside exterior regions, see Eq.~(9).

    Parameters
    ----------
    field_VEV : float
        VEV corresponding to region.
    compton_WL : float
        Compton wavelength corresponding to field VEV.
    z_boundary : float
        Location of the boundary.
    field_boundary : float
        Value of field at boundary.
    z : numpy.array
        Position values to be evaluated.

    Returns
    -------
    field : numpy.array
        Field values at positions z.

    '''

    x_b = np.sqrt(field_boundary/field_VEV)  # Rescaled.
    x_0 = (1 + x_b)/2  # Starting point for Newton method.

    constant = np.exp(2*x_b)*(x_b - 1)/(x_b + 1)

    # Invert the function and iterate over all inputted z-values.
    inv = []
    for zi in z:

        def residual(x):
            return (np.exp(2*x)*(x - 1)/(x + 1)
                    - constant*np.exp(-abs(zi-z_boundary)/compton_WL))

        # Use Newton method.
        inv.append(newton(residual, x0=x_0, fprime=fprime, fprime2=fprime2))

    field = field_VEV*np.array(inv)**2

    return field


z = np.linspace(0, 10, 1000)

field_VEV = 1
compton_WL = 2
z_boundary = 10
field_boundary = 10

t0 = dt()
field_bi = exterior_bisection(field_VEV, compton_WL, z_boundary,
                              field_boundary, z=z)

t1 = dt()
# field_Newton_1 = exterior_Newton1(field_VEV, compton_WL, z_boundary,
#                                   field_boundary, z=z)
t2 = dt()

field_Newton_2 = exterior_Newton2(field_VEV, compton_WL, z_boundary,
                                  field_boundary, z=z)
t3 = dt()

print(t1-t0)
print(t2-t1)
print(t3-t2)

plt.figure()
plt.plot(z, field_bi, label="Bisection")
# plt.plot(z, field_Newton_1, label="Newton(1)")
plt.plot(z, field_Newton_2, label="Newton(2)")

plt.legend()


# Plot error.
# e1 = abs(field_bi - field_Newton_1)
e2 = abs(field_bi - field_Newton_2)

plt.figure()
plt.yscale('log')
# plt.plot(z, e1, label="1")
plt.plot(z, e2, label="2")

plt.legend()
