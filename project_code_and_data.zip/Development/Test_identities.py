#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Feb 27 23:10:02 2026

@author: chad-briddon

Check identies as substitutes for capitalised elliptic functions.

"""


import numpy as np
import matplotlib.pyplot as plt

from scipy.special import ellipj, ellipk, ellipkinc, ellipeinc
from timeit import default_timer as dt


' --------------------------- Analytic functions --------------------------- '


def K(m):
    return ellipk(m**2)


def F(u, m):
    return ellipkinc(u, m**2)


def E(u, m):
    return ellipeinc(u, m**2)


def sn(u, m):
    return ellipj(u, m**2)[0]


' --------------------------------------------------------------------------- '
' -------------------------------- Test Sn() -------------------------------- '
' --------------------------------------------------------------------------- '


def Sn_v1(u, k):

    t = np.linspace(0, u, 10000)
    sn2 = sn(t, k)**2

    return np.trapz(sn2, t)


def Sn_v2(u, k):

    t = np.linspace(0, u, 10000)
    sn2 = ellipj(t, k**2)[0]**2

    return np.trapz(sn2, t)


def Sn_v3(u, k):
    '''
    Use identity in 'Handbook of Mathematical Functions With Formulas, Graphs,
    and Mathematical Tables', Eq. 16.26.1.'

    '''

    m = k**2

    ph = ellipj(u, m)[3]

    return (u - ellipeinc(ph, m))/m


if False:
    '''
    Complusion : v3 is more accuate. Does not have an issue with array length
                 and is alot faster.'
    '''

    k = 0.1

    u = np.linspace(0, 4*K(k), 10000)

    t0 = dt()

    y1 = Sn_v1(u, k)
    t1 = dt()

    y2 = Sn_v2(u, k)
    t2 = dt()

    y3 = Sn_v3(u, k)
    t3 = dt()

    print("V1 : ", t1 - t0)
    print("V2 : ", t2 - t1)
    print("V3 : ", t3 - t2)

    # Plot function.
    plt.figure()
    plt.ylabel("Sn(u, k)")
    plt.xlabel("u")

    plt.plot(u, y1, label="V1")
    plt.plot(u, y2, label="V2")
    plt.plot(u, y3, label="V3")

    plt.legend()

    # Plot difference.
    e_12 = abs(y1 - y2)
    e_13 = abs(y1 - y3)

    plt.figure()
    plt.ylabel("error")
    plt.xlabel("u")

    plt.plot(u, e_12, label="e_12")
    plt.plot(u, e_13, label="e_V3")

    plt.legend()


' --------------------------------------------------------------------------- '
' -------------------------------- Test Ns() -------------------------------- '
' --------------------------------------------------------------------------- '

# Def for Ns see book Eq. 16.25.2.


def Ns_mod_v1(u, k):

    t = np.linspace(1, u, 10000)
    ns2 = 1/sn(t, k)**2
    y = ns2 - 1/t**2

    return np.trapz(y, t)


def Ns_mod_v2(u, k):

    t = np.linspace(1, u, 10000)
    ns2 = 1/ellipj(t, k**2)[0]**2
    y = ns2 - 1/t**2

    return np.trapz(y, t)


def Ns_v3(u, k):
    '''
    Use identity in 'Handbook of Mathematical Functions With Formulas, Graphs,
    and Mathematical Tables', Eq. 16.26.10.'

    '''

    m = k**2

    sn, cn, dn, ph = ellipj(u, m)

    return u - ellipeinc(ph, m) - cn*dn/sn


if False:
    '''
    Complusion : v3 is more accuate. Does not have an issue with array length
                 and is alot faster.'
    '''

    k = 0.1

    u = np.linspace(1, K(k), 10000, endpoint=False)

    t0 = dt()

    y1 = Ns_mod_v1(u, k)
    t1 = dt()

    y2 = Ns_mod_v2(u, k)
    t2 = dt()

    y3 = Ns_v3(u, k) - Ns_v3(1, k) - 1 + 1/u
    t3 = dt()

    print("V1 : ", t1 - t0)
    print("V2 : ", t2 - t1)
    print("V3 : ", t3 - t2)

    # Plot function.
    plt.figure()
    plt.ylabel("Ns(u, k)")
    plt.xlabel("u")

    plt.plot(u, y1, label="V1")
    plt.plot(u, y2, label="V2")
    plt.plot(u, y3, label="V3")

    plt.legend()

    # Plot difference.
    e_12 = abs(y1 - y2)
    e_13 = abs(y1 - y3)

    plt.figure()
    plt.ylabel("error")
    plt.xlabel("u")

    plt.plot(u, e_12, label="e_12")
    plt.plot(u, e_13, label="e_V3")

    plt.legend()


' --------------------------------------------------------------------------- '
' -------------------------------- Test Sc() -------------------------------- '
' --------------------------------------------------------------------------- '


def Sc_v1(u, k):

    t = np.linspace(0, u, 10000)
    sn, cn = ellipj(t, k**2)[0:2]

    return np.trapz((sn/cn)**2, t)


def Sc_v2(u, k):
    '''
    Use identity in 'Handbook of Mathematical Functions With Formulas, Graphs,
    and Mathematical Tables', Eq. 16.26.9.'

    '''

    m = k**2

    sn, cn, dn, ph = ellipj(u, m)

    return ((sn*dn/cn) - ellipeinc(ph, m))/(1 - m)


if False:
    '''
    Complusion : v2 is more accuate. Does not have an issue with array length
                 and is alot faster.'
    '''

    k = 0.1

    u = np.linspace(0, K(k)-0.1, 10000, endpoint=False)

    t0 = dt()

    y1 = Sc_v1(u, k)
    t1 = dt()

    y2 = Sc_v2(u, k)
    t2 = dt()

    print("V1 : ", t1 - t0)
    print("V2 : ", t2 - t1)

    # Plot function.
    plt.figure()
    plt.ylabel("Sc(u, k)")
    plt.xlabel("u")

    plt.plot(u, y1, label="V1")
    plt.plot(u, y2, label="V2")

    plt.legend()

    # Plot difference.
    e_12 = abs(y1 - y2)

    plt.figure()
    plt.ylabel("error")
    plt.xlabel("u")

    plt.plot(u, e_12, label="e_12")

    plt.legend()
