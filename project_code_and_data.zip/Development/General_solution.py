#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 11 11:55:52 2025

@author: chad-briddon

Functions/class that returns the analytic solution for the chameleon field
(n=1) between two parallel plates (not nessisarily with the same density).

"""

import numpy as np

from scipy.optimize import fsolve
from scipy.special import ellipj, ellipk, ellipkinc, ellipeinc


' --------------------------- Analytic functions --------------------------- '


def K(m):
    return ellipk(m**2)


def F(u, m):
    return ellipkinc(u, m**2)


def E(u, m):
    return ellipeinc(u, m**2)


def sn(u, m):
    return ellipj(u, m**2)[0]


def Sn(u, k):

    t = np.linspace(0, u, 1000)
    sn2 = sn(t, k)**2

    return np.trapz(sn2, t)


def inverse_Sn(y, k, range_=(0, np.pi)):
    'Since sn is monotoic function, use bisection method to find its inverse.'
    'Find f(x) = Sn(x, k) - y = 0.'

    inv = []
    for yi in y:

        a, b = range_
        while abs(b-a) > 1e-10:

            c = (b+a)/2

            if Sn(c, k) - yi > 0:
                b = c
            else:
                a = c

        inv.append(c)

    return np.array(inv)


def Sn_diff(a, b, k):

    t = np.linspace(a, b, 10000)
    sn2 = sn(t, k)**2

    return np.trapz(sn2, t)


' --------------------------------------------------------------------------- '
' ----------------- Functions specific to chameleon profile ----------------- '
' --------------------------------------------------------------------------- '


class Chameleon_Parallel_Plates_Solution():
    def __init__(self, omega_L, omega_R, alpha, L):

        self.omega_L = omega_L
        self.omega_R = omega_R
        self.alpha = alpha
        self.L = L

        return None

    def x_wall_L(self, k):
        return 1 - ((k - self.omega_L)**2)/((k**2)*(1 - self.omega_L**2))

    def x_wall_R(self, k):
        return 1 - ((k - self.omega_R)**2)/((k**2)*(1 - self.omega_R**2))

    def zeta_L_mag(self, k):

        Lv = np.sqrt(2*self.alpha*(k**3))

        x_wall_L = self.x_wall_L(k)
        theta = np.arcsin(np.sqrt(x_wall_L))

        a = F(theta, k)
        b = K(k)

        return Lv*Sn_diff(a, b, k)

    def zeta_R_mag(self, k):

        Lv = np.sqrt(2*self.alpha*(k**3))

        x_wall_R = self.x_wall_R(k)
        theta = np.arcsin(np.sqrt(x_wall_R))

        a = F(theta, k)
        b = K(k)

        return Lv*Sn_diff(a, b, k)

    def k_residual_small_lambda(self, k):

        k_value = k[0]

        zeta_L_mag = self.zeta_L_mag(k_value)
        zeta_R_mag = self.zeta_R_mag(k_value)

        k_res = self.L - zeta_L_mag - zeta_R_mag

        return np.array(k_res)

    def k_residual_large_lambda(self, k):

        k_value = k[0]

        zeta_L_mag = self.zeta_L_mag(k_value)
        zeta_R_mag = self.zeta_R_mag(k_value)

        if self.omega_L < self.omega_R:
            k_res = self.L - zeta_L_mag + zeta_R_mag

        else:
            k_res = self.L + zeta_L_mag - zeta_R_mag

        return np.array(k_res)

    def monotoic_compton_limit(self):

        x_wall_L = self.x_wall_L(self.omega_R)

        theta = np.arcsin(np.sqrt(x_wall_L))

        a = F(theta, self.omega_R)
        b = K(self.omega_R)

        compton_wl = self.L/(2*(self.omega_R**1.5)*Sn_diff(a, b, self.omega_R))

        return compton_wl

    def k_residual(self, k):

        # Check which regime we are in first.
        compton_critical = self.monotoic_compton_limit()

        compton_vacuum = np.sqrt(self.alpha/2)

        if compton_vacuum < compton_critical:
            k_res = self.k_residual_small_lambda(k)
        else:
            k_res = self.k_residual_large_lambda(k)

        return k_res

    def get_k(self, k0):

        k = fsolve(self.k_residual, x0=np.array(k0), xtol=1e-12)[0]

        return k

    def get_k2(self, range_=None, tol=1e-10):

        if range_ is None:

            if self.k_residual(k=[1]) > 0:
                sig = +1
                a = min(self.omega_L, self.omega_R)
                b = 1
            else:
                sig = -1
                a = 1
                b = min(self.omega_L, self.omega_R)
        else:
            sig = +1
            a, b = range_

        # Converge to solution.
        while abs(b-a) > tol:

            c = (b+a)/2

            if sig*self.k_residual([c]) < 0:
                b = c
            else:
                a = c

        k = c

        return k

    def field_profile_vacuum(self, x, k):

        Lv = np.sqrt(2*self.alpha*(k**3))

        zeta_L = self.zeta_L_mag(k)
        zeta_R = self.zeta_R_mag(k)

        zeta = x + 0.5*np.sign(k - self.omega_R)*zeta_R \
            - 0.5*np.sign(k - self.omega_L)*zeta_L

        y_Anal = Sn(K(k), k) - abs(zeta)/Lv

        theta_Anal = inverse_Sn(y_Anal, k)

        field_Anal = k*sn(theta_Anal, k)**2

        return field_Anal

    def field_mirror_L_residual(self, field, z, k):

        compton_mirror_L = np.sqrt(self.alpha/2)*(self.omega_L**1.5)

        field_wall_L = k*self.x_wall_L(k)

        Y1 = np.sqrt(field/self.omega_L) - np.sqrt(field_wall_L/self.omega_L)

        Y2 = np.sqrt((np.sqrt(field) - np.sqrt(self.omega_L))
                     / (np.sqrt(field_wall_L) - np.sqrt(self.omega_L)))

        Y3 = np.sqrt((np.sqrt(field) + np.sqrt(self.omega_L))
                     / (np.sqrt(field_wall_L) + np.sqrt(self.omega_L)))

        res = (Y2/Y3)*np.exp(Y1) - np.exp((0.5*self.L + z)
                                          / (2*compton_mirror_L))

        return np.array(res)

    def field_mirror_R_residual(self, field, z, k):

        compton_mirror_R = np.sqrt(self.alpha/2)*(self.omega_R**1.5)

        field_wall_R = k*self.x_wall_R(k)

        Y1 = np.sqrt(field/self.omega_R) - np.sqrt(field_wall_R/self.omega_R)

        Y2 = np.sqrt((np.sqrt(field) - np.sqrt(self.omega_R))
                     / (np.sqrt(field_wall_R) - np.sqrt(self.omega_R)))

        Y3 = np.sqrt((np.sqrt(field) + np.sqrt(self.omega_R))
                     / (np.sqrt(field_wall_R) + np.sqrt(self.omega_R)))

        res = (Y2/Y3)*np.exp(Y1) - np.exp((0.5*self.L - z)
                                          / (2*compton_mirror_R))

        return np.array(res)

    def field_profile_mirror_L(self, z, k, tol=1e-10):

        range_ = (min(self.omega_L, self.omega_R),
                  max(self.omega_L, self.omega_R, k))

        # Add sign flip to residual.
        if self.omega_L < k:
            sig = +1
        else:
            sig = -1

        inv = []
        for zi in z:

            a, b = range_
            while abs(b-a) > tol:

                c = (b+a)/2

                if sig*self.field_mirror_L_residual(c, zi, k) > 0:
                    b = c
                else:
                    a = c

            inv.append(c)

        field = np.array(inv)

        return field

    def field_profile_mirror_R(self, z, k, tol=1e-10):

        range_ = (min(self.omega_L, self.omega_R),
                  max(self.omega_L, self.omega_R, k))

        # Add sign flip to residual.
        if self.omega_R < k:
            sig = +1
        else:
            sig = -1

        inv = []
        for zi in z:

            a, b = range_
            while abs(b-a) > tol:

                c = (b+a)/2

                if sig*self.field_mirror_R_residual(c, zi, k) > 0:
                    b = c
                else:
                    a = c

            inv.append(c)

        field = np.array(inv)

        return field

    def field_profile(self, z, k):

        field = self.field_profile_vacuum(z, k)

        for i, zi in enumerate(z):

            if zi > 0.5:
                field[i] = self.field_profile_mirror_R([zi], k)[0]

            elif zi < -0.5:
                field[i] = self.field_profile_mirror_L([zi], k)[0]

        return field
