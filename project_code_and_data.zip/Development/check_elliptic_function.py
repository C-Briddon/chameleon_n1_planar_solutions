#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May  7 18:17:05 2026

@author: chad-briddon

"""

import numpy as np
import matplotlib.pyplot as plt

from scipy.special import ellipj
from scipy.special import ellipk as K
# from scipy.special import ellipkinc as F
from scipy.special import ellipeinc as E


def Sn(u, m):
    '''
    Use identity in 'Handbook of Mathematical Functions With Formulas, Graphs,
    and Mathematical Tables', Eq. 16.26.1.'

    '''

    ph = ellipj(u, m)[3]

    return (u - E(ph, m))/m


def Ns(u, m):
    '''
    Use identity in 'Handbook of Mathematical Functions With Formulas, Graphs,
    and Mathematical Tables', Eq. 16.26.10.'

    '''

    sn, cn, dn, ph = ellipj(u, m)

    return u - E(ph, m) - cn*dn/sn


def Sn_Inverse(y, m):
    '''
    Inverse of function Sn(u, m). Obtained using bisection method.

    '''

    if isinstance(y, float):

        a, b = 0, K(m)+1e-14

        while abs(b-a) > 1e-14:

            c = (a + b)/2

            if Sn(c, m) > y:
                b = c
            else:
                a = c

        inverse = (a + b)/2

    else:

        inv = []
        for yi in y:

            a, b = 0, 2*K(m)+1e-14

            while abs(b-a) > 1e-14:

                c = (a + b)/2

                if Sn(c, m) > yi:
                    b = c
                else:
                    a = c

            inv.append((a + b)/2)

        inverse = np.array(inv)

    return inverse


def Ns_Inverse(y, m):
    '''
    Inverse of function Ns(u, m). Obtained using bisection method.

    '''

    if isinstance(y, float):

        a, b = 0, K(m)+1e-14

        while abs(b-a) > 1e-14:

            c = (a + b)/2

            if Ns(c, m) > y:
                b = c
            else:
                a = c

        inverse = (a + b)/2

    else:

        inv = []
        for yi in y:

            a, b = 0, K(m)+1e-14

            while abs(b-a) > 1e-14:

                c = (a + b)/2

                if Ns(c, m) > yi:
                    b = c
                else:
                    a = c

            inv.append((a + b)/2)

        inverse = np.array(inv)

    return inverse


m = 0.5

X = np.linspace(0, 2, 1000)
Y = Sn_Inverse(X, m)

plt.plot(X, Y)
