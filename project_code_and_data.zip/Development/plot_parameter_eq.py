#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Mar  3 14:06:25 2026

@author: chad-briddon

Plot 'parameter_residual()' to check they are monotonic functions.

"""

import numpy as np
import matplotlib.pyplot as plt

from _prototype_for_general_solver import parameter_residual


'Extrema (maximum)'
if False:
    L_i = 1
    compton_WL = 1

    L_rs = L_i/(2*compton_WL)

    field_VEV = 1
    field_L = 0.5
    field_R = 0.1

    data = L_rs, field_VEV, field_L, field_R

    k = np.linspace(1e-6, 0.99, 10001)

    res = np.array([parameter_residual(ki, data) for ki in k])

    plt.figure()
    plt.ylabel("res")
    plt.xlabel("k")

    plt.axhline(0, linestyle="--")

    plt.plot(k, res)


'Extrema (minimum)'
if False:
    L_i = 1
    compton_WL = 1

    L_rs = L_i/(2*compton_WL)

    field_VEV = 1
    field_L = 1.1
    field_R = 1.2

    data = L_rs, field_VEV, field_L, field_R

    k = np.linspace(1 + 1e-6, 10, 10001)

    res = np.array([parameter_residual(ki, data) for ki in k])

    plt.figure()
    plt.ylabel("res")
    plt.xlabel("k")

    plt.axhline(0, linestyle="--")

    plt.plot(k, res)


'VEV'
if True:
    L_i = 1.0
    compton_WL = 22

    L_rs = L_i/(2*compton_WL)

    field_VEV = 1
    field_L = 0.9
    field_R = 1.1

    data = L_rs, field_VEV, field_L, field_R

    ep = np.linspace(1e-10, 1, 10001)

    res = np.array([parameter_residual(epi, data) for epi in ep])

    plt.figure()
    plt.ylabel("res")
    plt.xlabel("C")

    plt.axhline(0, linestyle="--")

    plt.plot(ep, res)
