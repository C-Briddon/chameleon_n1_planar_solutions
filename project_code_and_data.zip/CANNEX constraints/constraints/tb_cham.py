### torsion balance 1209.0211 ###

import numpy as np

from constants import *


# read some data points off the chart
data = [[1e-2, pow(10, -1.5)],
        [pow(10, -1.5), pow(10, -2)],
        [1e-1, pow(10, -2.25)],
        [1,    pow(10, -1.75)],
        [1e1,  pow(10, -0.25)],
        [1e2,  pow(10, 1.75)],
        [1e3,  pow(10, 3.75)]]

betas, gammas = zip(*data)

# convert to our units
Ms = [Mpl / b for b in betas]
Ls = [2.4e-3 * pow(g, 0.2) for g in gammas]

Ms.reverse()
Ls.reverse()

Ms = np.log10(Ms)
Ls = np.log10(Ls)

# interpolate/extrapolate the curve
# first make it nice and smooth in the curved region
from scipy.interpolate import interp1d
f = interp1d(Ms, Ls, kind = 'quadratic')
Ms = np.linspace(Ms[0], Ms[-1], 100)
Ls = f( Ms )

# now make it nice and linear (i.e. power law on log scale)
# away from the curved bit
f = interp1d(Ms, Ls, kind = 'linear', fill_value='extrapolate')

def bound(Ms):
    Ls = f( np.log10(Ms) )

    Ls = np.power(10, Ls)

    return Ls
