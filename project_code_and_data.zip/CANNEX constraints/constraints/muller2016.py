import math

### fundamental constants ###
c    = 2.998e10 # cm / s
hbar = 1.97e-5  # cm eV
Mpl  = 2.4e27   # eV


### conversions ###
gtoeV     = 1 / (1.78e-33)        # 1 g        = x eV
gcm3toeV4 = pow(hbar, 3) * gtoeV  # 1 g / cm^3 = x eV^4
cms2toeV  = hbar / (c * c)        # 1 cm/s^2   = x eV

# Cs-133 nucleus
r_test   = 4.8 * 1e-13  # fm to cm
m_test   = 133  * 1.66e-24   # amu to grams
rho_test = m_test / (4 * math.pi * pow(r_test, 3) / 3)

r_src    = 2.54/2  # cm
rho_src  = 2.7  # g / cm^3
m_src    = 4 * math.pi * rho_src * pow(r_src, 3) / 3.

r_vac    = 6.1   # cm
rho_vac  = 1e-16 # g / cm^3

d_sep    = 0.88  # cm
r_sep    = d_sep + r_src

a_meas   = 50 * 1e-7 # nm / s^2 to cm / s^2

### convert everything to eV ###
r_test   /= hbar
m_test   *= gtoeV
rho_test *= gcm3toeV4

r_src    /= hbar
m_src    *= gtoeV
rho_src  *= gcm3toeV4

r_vac    /= hbar
rho_vac  *= gcm3toeV4

d_sep    /= hbar
r_sep    /= hbar

a_meas   *= cms2toeV

a_newt    = m_src / (8 * math.pi * pow(Mpl, 2) * pow(r_src + d_sep, 2))
