# Fundamental constants
Mpl     =   2.4e27  # eV
hbar    =   2e-5    # cm eV
c       =   3e10    # cm s^-1

# electron mass
m_e     =   0.511e6;

# muon
m_mu    =   105.7e6

# proton mass and radius
m_p     =   938e6
r_p     =   0.877e-13 / hbar

# neutron mass
m_n     =   939.57e6
r_n     =   0.8e-13 / hbar

# Bohr radius
a_0      =   5.29e-9 / hbar

# multiply a quantity in grams by this number to get it in eV
g_to_eV =   1e9 / (1.783e-24)

# multiply by this to convert g / cm^3 to eV^4
gcm3_to_eV4 = g_to_eV * pow(hbar, 3)

# Earth's gravitational field
gN = 9.8 * 1e2 * hbar / c**2
