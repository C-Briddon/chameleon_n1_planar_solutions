Files '_make_plot(CANNEX)(3.1)', '_make_plot(CANNEX)(3.2)', '_make_plot(CANNEX)(4.1)', '_make_plot(CANNEX)(4.3)', and '_make_plot(CANNEX)(5)' were written solely by Chad Briddon.

Files '_make_plot(CANNEX)(1.1)', '_make_plot(CANNEX)(1.2)', and '_make_plot(CANNEX)(2)' were partially written by Chad Briddon but reused code provided by Ben Elder.

All other files were produced solely by Ben Elder.
