#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jun  1 22:01:31 2026

@author: chad-briddon

Make constraint plot using Ben Elder's code.

*This version plots curves for different vacuum gap sizes.*

"""

# Plot the bounds on chameleon parameter space
import numpy as np
import matplotlib.pyplot as plt
import tb_cham
import AI_cham
import csv

from os import getcwd
from constants import Mpl
from SELCIE.Misc import alpha_calculator_chameleon, units, constants  # v2.0.0


plt.rc('axes', labelsize=15)
plt.rc('legend', fontsize=15)


exps = np.linspace(9, 30, 10000)

Ms = np.power(10, exps)

fig, ax = plt.subplots(figsize=(8, 6))
plt.rcParams["font.size"] = 12

colors = plt.rcParams['axes.prop_cycle'].by_key()['color']
colors = ["#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2",
          "#D55E00", "#CC79A7"]

'### torsion balance ###'
Ls = tb_cham.bound(Ms)

ci = -1
plt.fill_between(Ms/Mpl, Ls, 1e3, alpha=0.5, color=colors[ci])
# plt.text(3e0, 1e-2, "Torsion balance", ha = 'center', rotation = 'vertical')


'### atom interferometry ###'
Ls = AI_cham.bound(Ms)

ci = 2
plt.fill_between(Ms/Mpl, Ls, 1e3, alpha=0.5, color=colors[ci])
# plt.text(1e-8, 6e-5, "Atom\ninterferometry", ha = 'center')


'### Yin et al levitated force sensor ###'

Ms_yin = []
Ls_yin = []
with open("levitated_yin.csv") as csvfile:
    reader = csv.reader(csvfile, delimiter=",")
    for row in reader:
        Ms_yin.append(float(row[0]))
        Ls_yin.append(float(row[1]) - 3)

Ms_yin = np.asarray(Ms_yin)
Ls_yin = np.asarray(Ls_yin)


Ls_top = np.interp(Ms_yin, [Ms_yin[0], Ms_yin[-1]], [Ls_yin[0], Ls_yin[-1]])

ci = -2
plt.fill_between(np.power(10, Ms_yin), np.power(10, Ls_yin),
                 np.power(10, Ls_top), alpha=0.5, color="white")
plt.fill_between(np.power(10, Ms_yin), np.power(10, Ls_yin),
                 np.power(10, Ls_top), alpha=0.5, color=colors[ci])
# plt.text(3e-2, 8e-4, "LFS", ha = 'center')


'### DE line ###'
Ls = [2.4e-3]*len(Ms)

plt.plot(Ms/Mpl, Ls, color='red', linestyle="dashed")
# plt.text(1e-12, 2.9e-3, r"$\Lambda = \Lambda_\mathrm{DE}$", ha = 'center')


'### plot details ###'

ax.set_xscale("log")
ax.set_yscale("log")

# put ticks on the inside
ax.tick_params(which='both', direction="in")

plt.yticks([1e-3, 1e-2, 1e-1])

plt.xlabel(r"$M / M_{ \rm pl}$")
plt.ylabel(r"$\Lambda / {\rm eV}$")

plt.xlim(1e-6, 1e0)
plt.ylim(1e-4, 1e0)


' --------------------------------------------------------------------------- '
' --------------------------------------------------------------------------- '
'### Add CANNEX pressure sensitivity curves to plot ###'

path = getcwd()[:-len("constraints")]
log_beta = list(np.round(np.linspace(-1.00, 6.0, 141), 4))[10:]


Lambda_DE = 2.4e-3          # eV
Al = 2.7                    # g/cm^3
vac = 5.30e-15              # g/cm^3
Pt = 21.45                  # g/cm^3
W = 19.3                    # g/cm^3
Si = 2.33                   # g/cm^3
Cu = 8.96                   # g/cm^3
SiO2 = 2.65                 # g/cm^3


sensor_plate = [Pt, W, Pt, W, Si, W, Pt, vac, Al]


def calc_rescaled_pressure(boundary_values):
    boundary_values_sensor = np.array(boundary_values[5:-1])

    layer_density = [0] + [sp for sp in sensor_plate[:-2]] + [0]

    p_diff = np.array([(p1 - p0) for p0, p1 in zip(layer_density[:-1],
                                                   layer_density[1:])])

    return abs(np.dot(boundary_values_sensor, p_diff))


# Density.
kg_per_m3_2_eV4 = (constants.hbar.value**3)*(constants.c.value**5)/(
    constants.e.value**4)

density_NonEVUnits = units.g/units.cm**3
density = density_NonEVUnits.to(units.kg*units.m**(-3))*kg_per_m3_2_eV4


# Length.
_per_m_2_eV = constants.c.value*constants.hbar.value/constants.e.value

length_NonEVUnits = units.um
length = length_NonEVUnits.to(units.m)/_per_m_2_eV

# Pressure.
eV4_to_Pa = (constants.c.value*constants.hbar.value)**3/constants.e.value**4
Pa_to_pN_per_cm2 = 1e8

eV4_to_pN_per_cm2 = eV4_to_Pa*Pa_to_pN_per_cm2


' --------------------- Plot for different vacuum gaps --------------------- '

folders = ["Data/field/Boundary Data(_3.000um)(4)",
           "Data/field/Boundary Data(_20.439um)(4)"]
target_pressures = np.array([1.0090243035439571e1, 2.548365253796506e-2])
target_pressures *= 2  # change confidence to 95% CL.


for folder, target_pressure in zip(folders, target_pressures):

    data_path = path + folder

    pressure = []

    for lb in log_beta:

        name = data_path + "/LogB%.3f" % lb

        beta = 10**lb
        M = Mpl/beta                                # eV
        VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

        # C = VEV*density/M
        C = density/M

        with open(name, "r") as txt_file:
            bv = np.array(eval(txt_file.read()))

        pressure.append(C*calc_rescaled_pressure(boundary_values=bv))

    # Rescale pressure from natural units to pN/cm^2.
    pressure = eV4_to_pN_per_cm2*np.array(pressure)

    # Add constraint lines from pressure.
    n = 1
    U = (length**0.8)*(density**0.6)  # a constant.

    eq_curve = []

    for lb, p1 in zip(log_beta, pressure):

        beta = 10**lb
        M1 = Mpl/beta                           # eV

        # Get alpha and field scale.
        alpha = alpha_calculator_chameleon(
            n, M1, Lambda_DE, p0=1.0, L=1.0,
            p0_NonEVUnits=units.g/units.cm**3, L_NonEVUnits=units.um)

        M2 = M1*np.sqrt(p1/target_pressure)
        Lambda2 = U*(alpha**0.4)/(M2**0.6)

        eq_curve.append((M2, Lambda2))

    # Plot equal pressure curve.
    X = np.array([para[0]/Mpl for para in eq_curve])
    Y = np.array([para[1] for para in eq_curve])

    ax.plot(X, Y, color="black", linestyle="solid")


# Add text.
plt.text(1e-5, 5e-2, r"$d = 3 \mu \rm{m}$", ha='center',
         color="black", fontsize=15)

plt.text(1e-4, 10e-3, r"$d = 20.4 \mu \rm{m}$", ha='center',
         color="black", fontsize=15)


' --------------------------------------------------------------------------- '
# Add line showing when Compton wavelength in sheild is 10% its width.

Comp_SheildL_ratio = 0.1
SheildL = 3000  # um
Comp_um = Comp_SheildL_ratio*SheildL

Comp_eV = Comp_um*length
density_AL_eV = Al*density

constant = 4*(Comp_eV**4)*(density_AL_eV**3)/(Mpl**3)

beta = (constant/(Lambda_DE**5))**(-1/3)
print(np.log10(beta))


C = 0.2*np.log10(constant)

log_M = np.linspace(-8, 2, 1001)
Log_Lam = C - 0.6*log_M

M = 10**log_M
Lam = 10**Log_Lam


# plt.plot(1/beta, Lambda_DE, 'r.')
plt.plot(M, Lam, color="black", linestyle="dashed")


' --------------------------------------------------------------------------- '
fig.savefig(path + "Images/CANNEX_Constraint_plot(2).png",
            dpi=300, bbox_inches='tight')
plt.show()
