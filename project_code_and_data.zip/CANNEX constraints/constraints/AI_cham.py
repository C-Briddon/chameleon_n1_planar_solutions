# Takes in an array of M values, returns a matching array
# of \Lambda values corresponding to the constraint from AI
# Input and output are both in eV
# This uses the Mueller 2016 experiment

import math
import numpy as np
import matplotlib.pyplot as plt
from scipy import optimize
from scipy.interpolate import interp1d #, spline

from cham_helpers import *
from constants import *

def accel(n, M, L):
    phi = phi_env(n, M, L, rho_vac, r_vac)

    lamb_test = lamb_sf(M, phi, rho_test, r_test)
    lamb_src  = lamb_sf(M, phi, rho_src , r_src )

    return 2 * a_newt * pow(Mpl/M, 2) * lamb_test * lamb_src


def find_curve(Ms):
    Ls = [1e3]*len(Ms)

    # the vertical line constraint when the source is unscreened
    M_cutoff = math.sqrt( m_src / (4 * math.pi * a_meas * pow(r_sep, 2)) )

    L_last = 2.4e-3
    for i in range(0, len(Ms)):
        M = Ms[i]

        # check if we have entered the regime where the source is
        # unscreened, as the line becomes vertical and there is
        # no constraint for larger M
        # (the force is too small)
        if M >= M_cutoff:
            break

        L = optimize.newton( lambda L: accel(n, M, L) - a_meas, L_last)

        L_last = L
        Ls[i] = L
    return Ls

#fig, ax = plt.subplots()

n = 1

from muller2016 import *
def bound(Ms):

    Ls = find_curve(Ms)

    return Ls
