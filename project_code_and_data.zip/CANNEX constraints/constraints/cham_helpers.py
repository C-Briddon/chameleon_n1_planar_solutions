# calculate chameleon vev and screening factors

# minimum of the effective potential
def phi_eq(n, M, L, rho):
    return pow( n * M * pow(L, 4+n) / rho, 1./(n+1))

# mass = R^-1
def phi_bg(n, L, R):
    xi = 0.55   # spherical chamber, n = 1
    return xi * pow(n * (n + 1) * pow(L, 4+n) * R * R, 1./(n+2))

def phi_env(n, M, L, rho, R):
    return min( phi_eq(n, M, L, rho), phi_bg(n, L, R) )

def mass_env(n, M, L, rho, R):
    phi = phi_env(n, M, L, rho, R)
    m = n * (n + 1) * pow( L, 4+n )
    m /= pow( phi, n + 2 )
    return m

# screening factor for a spherical object
# phi is the local field value
def lamb_sf(M, phi, rho, R):
    return min( 3 * M * phi / (rho * R * R), 1)
