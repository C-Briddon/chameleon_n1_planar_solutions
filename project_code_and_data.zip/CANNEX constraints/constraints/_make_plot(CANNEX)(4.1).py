#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun 24 20:53:40 2026

@author: chad-briddon

Make coloured contour plot showing how the pressure varies with vacuum
gap size.

V4.1 : Plot gap size between 3 - 20.4 um.

"""

import numpy as np
import matplotlib.pyplot as plt

from os import getcwd
from matplotlib import ticker
from SELCIE.Misc import alpha_calculator_chameleon, units, constants  # v2.0.0


plt.rc('axes', labelsize=15)
plt.rc('legend', fontsize=15)


make_fig_1 = True  # Figure of all contours.
make_fig_2 = False  # Figure for specific contour to check smoothness.


# Control options for constraint plot.
version = 1

fig_3_make_log = False
fig_3_add_lines = True
fig_3_add_more_colour = True
fig_3_add_text = False
fig_3_add_extra_regon = True


' --------------------------------------------------------------------------- '

if make_fig_1:
    # Plot constraint curves for each gap size.
    fig1, ax1 = plt.subplots(figsize=(8, 6))
    plt.rcParams["font.size"] = 12

    ax1.set_ylabel(r"$\Lambda / {\rm eV}$")
    ax1.set_xlabel(r"$M / M_{\rm pl}$")

    ax1.set_yscale('log')
    ax1.set_xscale('log')

    # ax1.set_ylim([5e-3, 2e-1])
    # ax1.set_xlim([1e-6, 1e0])


' --------------------------------------------------------------------------- '
' --------------------------------------------------------------------------- '
'### Add CANNEX pressure sensitivity curves to plot ###'

path = getcwd()[:-len("constraints")]
log_beta = list(np.round(np.linspace(-1.00, 6.0, 141), 4))[10:]


Mpl = 2.4e27                # eV
Lambda_DE = 2.4e-3          # eV
Al = 2.7                    # g/cm^3
vac = 5.30e-15              # g/cm^3
Pt = 21.45                  # g/cm^3
W = 19.3                    # g/cm^3
Si = 2.33                   # g/cm^3
Cu = 8.96                   # g/cm^3
SiO2 = 2.65                 # g/cm^3


sensor_plate = [Pt, W, Pt, W, Si, W, Pt, vac, Al]


def calc_rescaled_pressure(boundary_values):
    boundary_values_sensor = np.array(boundary_values[5:-1])

    layer_density = [0] + [sp for sp in sensor_plate[:-2]] + [0]

    p_diff = np.array([(p1 - p0) for p0, p1 in zip(layer_density[:-1],
                                                   layer_density[1:])])

    return abs(np.dot(boundary_values_sensor, p_diff))


# Density.
kg_per_m3_2_eV4 = (constants.hbar.value**3)*(constants.c.value**5)/(
    constants.e.value**4)

density_NonEVUnits = units.g/units.cm**3
density = density_NonEVUnits.to(units.kg*units.m**(-3))*kg_per_m3_2_eV4


# Length.
_per_m_2_eV = constants.c.value*constants.hbar.value/constants.e.value

length_NonEVUnits = units.um
length = length_NonEVUnits.to(units.m)/_per_m_2_eV

# Pressure.
eV4_to_Pa = (constants.c.value*constants.hbar.value)**3/constants.e.value**4
Pa_to_pN_per_cm2 = 1e8

eV4_to_pN_per_cm2 = eV4_to_Pa*Pa_to_pN_per_cm2

' -------------------------------------------------------------------------- '
' --------------------- Plot for different vacuum gaps --------------------- '
' -------------------------------------------------------------------------- '

CANNEX_data0 = [(3.0000000000000000, 10.09024303543957100),
                (3.2393254869831290, 7.239265226328643000),
                (3.4977432035394953, 5.209746816906757000),
                (3.7767762353825017, 3.762123975244741500),
                (4.0780691726355770, 2.726937132507061500),
                (4.4033978028662080, 1.984441567560577600),
                (4.7546795773833400, 1.450062943850155800),
                (5.1339849124853420, 1.064043298534854200),
                (5.5435493922668740, 0.784126522542000400),
                (5.9857869449066390, 0.580416627413294250),
                (6.4633040700956520, 0.431703095079227900),
                (6.9789152014608790, 0.322856224000782670),
                (7.5356592945287405, 0.243029522294287660),
                (8.1368177379960860, 0.184404164598048070),
                (8.7859336938757110, 0.141312259088962540),
                (9.4868329805051400, 0.109620633779362030),
                (10.243646621500805, 0.086306098001573950),
                (11.060835193558726, 0.069152083210239560),
                (11.943215116604916, 0.056530489575896050),
                (12.895987041246831, 0.047243421645446780),
                (13.924766500838338, 0.040409825053424410),
                (15.035617008818167, 0.035381711990196174),
                (16.235085796393910, 0.031682156319832695),
                (17.530242401205530, 0.028960087581117610),
                (18.928720334405797, 0.026957237257455670),
                (20.438762071738836, 0.025483652537965060),
                (22.069267633789240, 0.024399480963449340),
                (23.829847041728447, 0.023601812867855470),
                (25.730876957726823, 0.023014949847032000),
                (27.783561843863803, 0.022583211440469780)]


'''
Note in paper "https://arxiv.org/pdf/2405.14638", Hauke uses 2*sigma as the
constraint. Above values are for 1*sigma, so must modify to get consistent
constraint.
'''
CANNEX_data = [(cd[0], 2*cd[1]) for cd in CANNEX_data0]


folders = ["Data/field/Boundary Data(_%.3fum)(4)" % c[0] for c in CANNEX_data]
target_pressures = [cd[1] for cd in CANNEX_data]
eq_curves = []


for folder, target_pressure in zip(folders, target_pressures):

    data_path = path + folder
    pressure = []

    for lb in log_beta:
        name = data_path + "/LogB%.3f" % lb

        beta = 10**lb
        M = Mpl/beta                                  # eV
        C = density/M

        with open(name, "r") as txt_file:
            bv = np.array(eval(txt_file.read()))

        pressure.append(C*calc_rescaled_pressure(boundary_values=bv))

    # Rescale pressure from natural units to pN/cm^2.
    pressure = eV4_to_pN_per_cm2*np.array(pressure)

    # Add constraint lines from pressure.
    n = 1
    U = (length**0.8)*(density**0.6)  # a constant.

    eq_curves.append([])

    for lb, p1 in zip(log_beta, pressure):

        beta = 10**lb
        M1 = Mpl/beta                           # eV

        # Get alpha and field scale.
        alpha = alpha_calculator_chameleon(
            n, M1, Lambda_DE, p0=1.0, L=1.0,
            p0_NonEVUnits=units.g/units.cm**3, L_NonEVUnits=units.um)

        M2 = M1*np.sqrt(p1/target_pressure)
        Lambda2 = U*(alpha**0.4)/(M2**0.6)

        eq_curves[-1].append((M2, Lambda2))

    if make_fig_1:
        # Plot equal pressure curve.
        X = np.array([para[0]/Mpl for para in eq_curves[-1]])
        Y = np.array([para[1] for para in eq_curves[-1]])
        ax1.plot(X, Y, color="black", linestyle="solid")


' ----------------------- Modify curves after 20.4um ----------------------- '

# Contours above 20.4um - found intersections in '_check_overlap.py'.
cross_index = [([25, 26], 57), ([25, 27], 51), ([25, 28], 47), ([25, 29], 44)]


if fig_3_add_extra_regon:
    fixed_curve = eq_curves[25]  # Curve corresponding to 20.4um.
    new_curves = []

    for i, eq_curve in enumerate(eq_curves):

        if i < 26:
            new_curves.append(eq_curve)
        else:
            gap_size = CANNEX_data[i][0]
            ix = cross_index[i-26][1]

            new_curves.append(eq_curve[:ix] + fixed_curve[ix:])

    eq_curves = new_curves

' --------------------------------------------------------------------------- '
' --- Add line showing when Compton wavelength in sheild is 10% its width --- '
' --------------------------------------------------------------------------- '

if make_fig_1:
    Comp_SheildL_ratio = 0.1
    SheildL = 3000  # um
    Comp_um = Comp_SheildL_ratio*SheildL

    Comp_eV = Comp_um*length
    density_AL_eV = Al*density

    constant = 4*(Comp_eV**4)*(density_AL_eV**3)/(Mpl**3)

    beta = (constant/(Lambda_DE**5))**(-1/3)
    # print(np.log10(beta))

    C = 0.2*np.log10(constant)

    log_M = np.linspace(-8, 2, 1001)
    Log_Lam = C - 0.6*log_M

    M = 10**log_M
    Lam = 10**Log_Lam

    # plt.plot(1/beta, Lambda_DE, 'r.')
    plt.plot(M, Lam, color="black", linestyle="dashed")
    plt.show()


' --------------------------------------------------------------------------- '
' ------------------ Check each contour curve looks smooth ------------------ '
' --------------------------------------------------------------------------- '

if make_fig_2:
    # Plot for single slice (constant Compton wavelength).
    fig2, ax2 = plt.subplots(figsize=(8, 6))
    plt.rcParams["font.size"] = 12

    ax2.set_ylabel(r"$\Lambda / {\rm eV}$")
    ax2.set_xlabel(r"$M / M_{\rm pl}$")

    # ax2.set_yscale('log')
    # ax2.set_xscale('log')

    # ax2.set_ylim([1e-3, 3e-1])
    # ax2.set_xlim([-2.5, -2.0])

    i = 27

    X = np.array([np.log10(para[0]/Mpl) for para in eq_curves[i]])
    Y = np.array([np.log10(para[1]) for para in eq_curves[i]])
    # ax2.plot(X[80:], Y[80:], color="black", linestyle="solid")
    ax2.plot(X, Y, color="black", linestyle="solid")


' -------------------------------------------------------------------------- '
' ----------------------- Make coloured contour plot ----------------------- '
' -------------------------------------------------------------------------- '

Lx = len(eq_curves[0])

if fig_3_add_extra_regon:
    Ly = len(eq_curves)
else:
    Ly = len(eq_curves[:26])

X1 = np.ndarray(shape=(Ly, Lx))
Y1 = np.ndarray(shape=(Ly, Lx))
Z1 = np.ndarray(shape=(Ly, Lx))


if fig_3_add_extra_regon:
    for i, eq_curve in enumerate(eq_curves):
        gap_size = CANNEX_data[i][0]

        for j, pos in enumerate(eq_curve):
            if fig_3_make_log:
                X1[i, j] = np.log10(pos[0]/Mpl)
                Y1[i, j] = np.log10(pos[1])
            else:
                X1[i, j] = pos[0]/Mpl
                Y1[i, j] = pos[1]

            Z1[i, j] = gap_size

else:
    for i, eq_curve in enumerate(eq_curves[:26]):
        gap_size = CANNEX_data[i][0]

        for j, pos in enumerate(eq_curve):
            if fig_3_make_log:
                X1[i, j] = np.log10(pos[0]/Mpl)
                Y1[i, j] = np.log10(pos[1])
            else:
                X1[i, j] = pos[0]/Mpl
                Y1[i, j] = pos[1]

            Z1[i, j] = gap_size


fig3, ax3 = plt.subplots(figsize=(8, 6))
plt.rcParams["font.size"] = 12


' --------------------------------------------------------------------------- '


if fig_3_make_log:
    ax3.set_ylabel(r"${\rm log_{10}} \left(\Lambda / {\rm eV} \right)$")
    ax3.set_xlabel(r"${\rm log_{10}} \left(M / M_{\rm pl} \right)$")

    if version == 1:
        ax3.set_ylim([-2.25, -0.75])
        ax3.set_xlim([-6.7, -1])
    elif version == 2:
        ax3.set_ylim([-2.25, -0.75])
        ax3.set_xlim([-15, -1])

else:
    ax3.set_ylabel(r"$\Lambda / {\rm eV}$")
    ax3.set_xlabel(r"$M / M_{\rm pl}$")

    if version == 1:
        ax3.set_ylim([7.0e-3, 2.0e-1])
        ax3.set_xlim([2e-7, 1e-1])
    elif version == 2:
        ax3.set_ylim([5.6e-3, 1.8e-1])
        ax3.set_xlim([1e-15, 1e-1])

    ax3.set_yscale('log')
    ax3.set_xscale('log')


if fig_3_add_extra_regon:
    ticks = [3, 6, 9, 12, 15, 18, 21, 24, 27]
else:
    ticks = [3, 5, 7, 9, 11, 13, 15, 17, 19]


clev = np.arange(Z1.min(), Z1.max(), 0.001)
# img = ax3.contourf(X1, Y1, Z1, clev, cmap=plt.cm.coolwarm)
img = ax3.contourf(X1, Y1, Z1, clev, cmap=plt.cm.coolwarm,
                   locator=ticker.LogLocator())
cbar = fig3.colorbar(img, format='%i', ticks=ticks)
cbar.set_label(r'Gap size ($\mu m$)')


' --------------------- Add lines for choosen distances --------------------- '

if fig_3_add_lines:
    Is = [25]
else:
    Is = []


for i in Is:
    # Plot equal pressure curve.
    gap_size = CANNEX_data[i][0]
    # print(gap_size)

    if fig_3_make_log:
        X = np.array([np.log10(para[0]/Mpl) for para in eq_curves[i]])
        Y = np.array([np.log10(para[1]) for para in eq_curves[i]])
    else:
        X = np.array([para[0]/Mpl for para in eq_curves[i]])
        Y = np.array([para[1] for para in eq_curves[i]])

    ax3.plot(X, Y, color="black", linestyle="dashed", linewidth=0.8)


' --- Add line showing when Compton wavelength in sheild is 10% its width --- '

Comp_SheildL_ratio = 0.1
SheildL = 3000  # um
Comp_um = Comp_SheildL_ratio*SheildL

Comp_eV = Comp_um*length
density_AL_eV = Al*density

constant = 4*(Comp_eV**4)*(density_AL_eV**3)/(Mpl**3)

beta = (constant/(Lambda_DE**5))**(-1/3)
# print(np.log10(beta))

C = 0.2*np.log10(constant)

log_M = np.linspace(-3, 2, 501)
log_Lam = C - 0.6*log_M

M = 10**log_M
Lam = 10**log_Lam

if fig_3_make_log:
    ax3.plot(log_M, log_Lam, color="black", linestyle="solid")
else:
    ax3.plot(M, Lam, color="black", linestyle="solid")


' --------------- Colour region constrained at all gap sizes --------------- '

if fig_3_add_more_colour:
    # Make points defining a closed region to be filled.

    Xc, Yc = [],  []

    if fig_3_make_log:
        ymax = ax3.get_ylim()[1]
        xmin = ax3.get_xlim()[0]

        Xc += [xmin, log_M[0]]
        Yc += [ymax, log_Lam[0]]

        Xc += [np.log10(para[0]/Mpl) for para in eq_curves[0]]
        Yc += [np.log10(para[1]) for para in eq_curves[0]]

    else:
        ymax = ax3.get_ylim()[1]
        xmin = ax3.get_xlim()[0]

        Xc += [xmin, M[0]]
        Yc += [ymax, Lam[0]]

        Xc += [para[0]/Mpl for para in eq_curves[0]]
        Yc += [para[1] for para in eq_curves[0]]

    ax3.fill(Xc, Yc, color='darkblue')


' -------------------------------- Add text -------------------------------- '

if fig_3_add_text:
    if fig_3_make_log:
        plt.text(-6, -2.19, r"$d = 3.0 \mu \rm{m}$", ha='center',
                 color="black", fontsize=13)

        plt.text(-6, -2.19, r"$d = 20.4 \mu \rm{m}$", ha='center',
                 color="black", fontsize=13)

    else:
        plt.text(1e-6, 2.5e-2, r"$d = 3.0 \mu \rm{m}$", ha='center',
                 color="black", fontsize=13)

        plt.text(1e-6, 6.3e-3, r"$d = 20.4 \mu \rm{m}$", ha='center',
                 color="black", fontsize=13)


' ------------------------------- Save figure ------------------------------- '

fig3.savefig(path + "Images/CANNEX_Constraint_plot(4.1.%i).png" % version,
             dpi=300, bbox_inches='tight')
