#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Jun 13 22:24:25 2026

@author: chad-briddon

Make plot showing ranges of parameter space constrained by CANNEX at different
gap sizes.

"""

import numpy as np
import matplotlib.pyplot as plt


from os import getcwd
from SELCIE.Misc import alpha_calculator_chameleon, units, constants  # v2.0.0


plt.rc('axes', labelsize=15)
plt.rc('legend', fontsize=15)


fig, ax = plt.subplots(figsize=(8, 6))
plt.rcParams["font.size"] = 12

ax.set_ylabel(r"$\Lambda / {\rm eV}$")
ax.set_xlabel(r"$M / M_{\rm pl}$")

ax.set_yscale('log')
ax.set_xscale('log')

ax.set_ylim([5e-3, 2e-1])
ax.set_xlim([1e-6, 1e0])

Mpl = 2.4e27  # eV


' --------------------------------------------------------------------------- '
' --------------------------------------------------------------------------- '
'### Add CANNEX pressure sensitivity curves to plot ###'

path = getcwd()[:-len("constraints")]
log_beta = list(np.round(np.linspace(-1.00, 6.0, 141), 4))[10:]


Lambda_DE = 2.4e-3          # eV
Al = 2.7                    # g/cm^3
vac = 5.30e-15              # g/cm^3
Pt = 21.45                  # g/cm^3
W = 19.3                    # g/cm^3
Si = 2.33                   # g/cm^3
Cu = 8.96                   # g/cm^3
SiO2 = 2.65                 # g/cm^3


sensor_plate = [Pt, W, Pt, W, Si, W, Pt, vac, Al]


def calc_rescaled_pressure(boundary_values):
    boundary_values_sensor = np.array(boundary_values[5:-1])

    layer_density = [0] + [sp for sp in sensor_plate[:-2]] + [0]

    p_diff = np.array([(p1 - p0) for p0, p1 in zip(layer_density[:-1],
                                                   layer_density[1:])])

    return abs(np.dot(boundary_values_sensor, p_diff))


# Density.
kg_per_m3_2_eV4 = (constants.hbar.value**3)*(constants.c.value**5)/(
    constants.e.value**4)

density_NonEVUnits = units.g/units.cm**3
density = density_NonEVUnits.to(units.kg*units.m**(-3))*kg_per_m3_2_eV4


# Length.
_per_m_2_eV = constants.c.value*constants.hbar.value/constants.e.value

length_NonEVUnits = units.um
length = length_NonEVUnits.to(units.m)/_per_m_2_eV

# Pressure.
eV4_to_Pa = (constants.c.value*constants.hbar.value)**3/constants.e.value**4
Pa_to_pN_per_cm2 = 1e8

eV4_to_pN_per_cm2 = eV4_to_Pa*Pa_to_pN_per_cm2


' --------------------- Plot for different vacuum gaps --------------------- '

folders = ["Data/field/Boundary Data(_3.000um)(4)",
           "Data/field/Boundary Data(_10.244um)(4)",
           "Data/field/Boundary Data(_20.439um)(4)"]
target_pressures = np.array([1.0090243035439571e1, 8.630609800157395e-2,
                             2.548365253796506e-2])
target_pressures *= 2  # change confidence to 95% CL.


for folder, target_pressure in zip(folders, target_pressures):

    data_path = path + folder

    pressure = []

    for lb in log_beta:

        name = data_path + "/LogB%.3f" % lb

        beta = 10**lb
        M = Mpl/beta                                # eV
        VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

        # C = VEV*density/M
        C = density/M

        with open(name, "r") as txt_file:
            bv = np.array(eval(txt_file.read()))

        pressure.append(C*calc_rescaled_pressure(boundary_values=bv))

    # Rescale pressure from natural units to pN/cm^2.
    pressure = eV4_to_pN_per_cm2*np.array(pressure)

    # Add constraint lines from pressure.
    n = 1
    U = (length**0.8)*(density**0.6)  # a constant.

    eq_curve = []

    for lb, p1 in zip(log_beta, pressure):

        beta = 10**lb
        M1 = Mpl/beta                           # eV

        # Get alpha and field scale.
        alpha = alpha_calculator_chameleon(
            n, M1, Lambda_DE, p0=1.0, L=1.0,
            p0_NonEVUnits=units.g/units.cm**3, L_NonEVUnits=units.um)

        M2 = M1*np.sqrt(p1/target_pressure)
        Lambda2 = U*(alpha**0.4)/(M2**0.6)

        eq_curve.append((M2, Lambda2))

    # Plot equal pressure curve.
    X = np.array([para[0]/Mpl for para in eq_curve])
    Y = np.array([para[1] for para in eq_curve])

    ax.plot(X, Y, color="black", linestyle="solid")


# Add text.

plt.text(0.3e-5, 3.8e-2, r"$d = 3 \mu \rm{m}$", ha='center',
         color="black", fontsize=15)

plt.text(1e-5, 1.2e-2, r"$d = 10.2 \mu \rm{m}$", ha='center',
         color="black", fontsize=15)

plt.text(1e-3, 7.5e-3, r"$d = 20.4 \mu \rm{m}$", ha='center',
         color="black", fontsize=15)


' --------------------------------------------------------------------------- '
# Add line showing when Compton wavelength in sheild is 10% its width.

Comp_SheildL_ratio = 0.1
SheildL = 3000  # um
Comp_um = Comp_SheildL_ratio*SheildL

Comp_eV = Comp_um*length
density_AL_eV = Al*density

constant = 4*(Comp_eV**4)*(density_AL_eV**3)/(Mpl**3)

beta = (constant/(Lambda_DE**5))**(-1/3)
print(np.log10(beta))


C = 0.2*np.log10(constant)

log_M = np.linspace(-8, 2, 1001)
Log_Lam = C - 0.6*log_M

M = 10**log_M
Lam = 10**Log_Lam


# plt.plot(1/beta, Lambda_DE, 'r.')
plt.plot(M, Lam, color="black", linestyle="dashed")


' --------------------------------------------------------------------------- '
fig.savefig(path + "Images/CANNEX_Constraint_plot(3.1).png",
            dpi=300, bbox_inches='tight')
plt.show()
