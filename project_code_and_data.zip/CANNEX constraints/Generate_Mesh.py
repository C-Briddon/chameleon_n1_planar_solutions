#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 26 19:04:15 2026

@author: chad-briddon

Generate mesh of the CANNEX experiment.


Layer specifications.
---------------------

sensor(movable), from top to bottom:

    Material, thickness

    Al, 3mm
    vacuum, 5mm
    Pt, 20nm
    W, 5nm
    Si, 100um
    W, 5nm
    Pt, 20 nm
    W, 300 nm
    Pt, 70 nm

vacuum gap 10-50 um (or up to 6 mm but then with more error)

lower plate, from top to bottom:

    Material, thickness

    Pt 70 nm
    W, 300nm
    SiO2 6 mm
    Cu, 2 mm

then follows a complex mixture of materials with gaps but that may
neither be 1d nor easy to model, so for your calculation, you may just
assume 5 mm Al and then vacuum.


Note will map left -> right as bottom -> top. x=x is at interface of lower
plate and vacuum.

*This code ran using SELCIE v2.0.0.

"""

import sys
import numpy as np
from SELCIE.Mesh import MeshingTools_1D


' --------------------- Set Parameters (in units of um) --------------------- '

# gap_vacuum = 50                    # Can vary (10-50 or up to 6000).
# filename = "CANNEX(50um)"


# Lower plate (top-to-bottom).
LP_Pt = 0.07
LP_W = 0.30
LP_SiO2 = 6000
PL_Cu = 2000

PL_Al = 5000

# Righter entries are further from gap (start set at zero).
lower_plate_boundary_pos = [-0.07, -0.37, -6000.37, -8000.37, -13000.37]


# Sensor plate (top-to-bottom).
SP_Al = 3e3
SP_vacuum = 5e3
SP_Pt = 0.02
SP_W = 5e-3
SP_Si = 100
SP_W = 5e-3
SP_Pt = 0.02
SP_W = 0.3
SP_Pt = 0.07

# Righter entries are further from gap.
sensor_plate_layer_thickness = [0.07, 0.3, 0.02, 5e-3, 100, 5e-3, 0.02,
                                5e3, 3e3]

# sensor_plate_layer_thickness = [0.07, 0.3, 0.02, 5e-3, 1, 5e-3, 0.02,
#                                 5e3, 3e3]

sensor_plate_boundary_pos = np.round(
    [sum(sensor_plate_layer_thickness[:i+1])
     for i in range(len(sensor_plate_layer_thickness))], 5)


' ----------------------------- Construct Mesh ----------------------------- '


if True:
    # filename += "(Extended)"
    sensor_plate_boundary_pos[-1] += 2000


def make_mesh(filename, gap):
    MT = MeshingTools_1D(display_messages=True)

    # Lower plate (fixed).
    L_id = []

    for x in lower_plate_boundary_pos:
        L_id += MT.create_1D_line(x_start=0, x_end=x, embed=L_id)

        MT.create_subdomain(CellSizeMin=1e-4, CellSizeMax=1, DistMax=1000)

    # Vacuum gap.
    Gap = MT.create_1D_line(x_start=lower_plate_boundary_pos[0],
                            x_end=gap, embed=L_id)

    MT.create_subdomain(CellSizeMin=1e-4, CellSizeMax=1, DistMax=1000)

    # Sensor plate (oscilates).
    S_id = []

    for x in sensor_plate_boundary_pos:
        y = gap + x

        S_id += MT.create_1D_line(x_start=1, x_end=y, embed=Gap+S_id)

        MT.create_subdomain(CellSizeMin=1e-4, CellSizeMax=1,
                            DistMin=0.3, DistMax=1000)

    MT.generate_mesh(filename, show_mesh=False)
    MT.msh_2_xdmf(filename, auto_override=True)

    return None


if __name__ == "__main__":
    CANNEX_data = [(3.0000000000000000, 10.09024303543957100),
                   (3.2393254869831290, 7.239265226328643000),
                   (3.4977432035394953, 5.209746816906757000),
                   (3.7767762353825017, 3.762123975244741500),
                   (4.0780691726355770, 2.726937132507061500),
                   (4.4033978028662080, 1.984441567560577600),
                   (4.7546795773833400, 1.450062943850155800),
                   (5.1339849124853420, 1.064043298534854200),
                   (5.5435493922668740, 0.784126522542000400),
                   (5.9857869449066390, 0.580416627413294250),
                   (6.4633040700956520, 0.431703095079227900),
                   (6.9789152014608790, 0.322856224000782670),
                   (7.5356592945287405, 0.243029522294287660),
                   (8.1368177379960860, 0.184404164598048070),
                   (8.7859336938757110, 0.141312259088962540),
                   (9.4868329805051400, 0.109620633779362030),
                   (10.243646621500805, 0.086306098001573950),
                   (11.060835193558726, 0.069152083210239560),
                   (11.943215116604916, 0.056530489575896050),
                   (12.895987041246831, 0.047243421645446780),
                   (13.924766500838338, 0.040409825053424410),
                   (15.035617008818167, 0.035381711990196174),
                   (16.235085796393910, 0.031682156319832695),
                   (17.530242401205530, 0.028960087581117610),
                   (18.928720334405797, 0.026957237257455670),
                   (20.438762071738836, 0.025483652537965060),
                   (22.069267633789240, 0.024399480963449340),
                   (23.829847041728447, 0.023601812867855470),
                   (25.730876957726823, 0.023014949847032000),
                   (27.783561843863803, 0.022583211440469780)]

    # CANNEX_data = [(30, 0.022583211440469780), (35, 0.022583211440469780),
    #                (40, 0.022583211440469780), (45, 0.022583211440469780)]
    '''
    for gap_size, _ in CANNEX_data:

        meshname = "CANNEX(%.3fum)" % gap_size

        if exists("Saved Meshes/" + meshname):
            continue

        print("Start : d = %.3f" % gap_size)

        make_mesh(meshname, gap_size)
    '''
    # i = 4

    args = sys.argv  # Allows for entering values on command line.
    i = int(args[1])  # First argument is always file location.

    gap_size = CANNEX_data[i][0]
    meshname = "CANNEX(%.3fum)" % gap_size
    # meshname = "CANNEX(%.3fum)(Si1um)" % gap_size
    make_mesh(meshname, gap_size)
