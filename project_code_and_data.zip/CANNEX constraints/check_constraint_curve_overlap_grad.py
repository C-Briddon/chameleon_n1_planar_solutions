#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Sep 15 16:26:33 2026

@author: chad-briddon

Check when contours for gradient constraint overlap.

In the gradient case no overlap was found. That said it appears if we looked
at larger seperations then there would be.

*Crosses at index : 27-28  =>  minimum is at i = 27

"""

from _initalise import np, plt, n, Lambda_DE, M_pl
from _initalise import Al, vac, Pt, W, Si, density, length
from _initalise import eV4_to_pN_per_cm2, density_scale, length_scale
from _initalise import length_unit, density_unit

from SELCIE.Misc import alpha_calculator_chameleon  # v2.0.0


plt.rc('axes', labelsize=15)
plt.rc('legend', fontsize=15)

dis = 0.1


' --------------------------------------------------------------------------- '


log_beta = list(np.round(np.linspace(-1.00, 6.0, 141), 4))

i = 27
# Note converted second column to pN/cm^2 and third to pN/cm^2/um.
CANNEX_data0 = [
    (3.0000000000000000, 10.090243035439571000, 14.603095459424381),
    (3.2393254869831290,  7.239265226328643000,  9.616859314745363),
    (3.4977432035394953,  5.209746816906757000,  6.349530521313371),
    (3.7767762353825017,  3.762123975244741500,  4.2019586220269085),
    (4.0780691726355770,  2.726937132507061500,  2.7869309141499744),
    (4.4033978028662080,  1.984441567560577600,  1.8537823604368068),
    (4.7546795773833400,  1.450062943850155800,  1.2390100958957337),
    (5.1339849124853420,  1.064043298534854200,  0.8310695867563316),
    (5.5435493922668740,  0.784126522542000400,  0.5593909954110098),
    (5.9857869449066390,  0.580416627413294250,  0.3778709727083459),
    (6.4633040700956520,  0.431703095079227900,  0.25626667114744717),
    (6.9789152014608790,  0.322856224000782670,  0.17421719563186385),
    (7.5356592945287405,  0.243029522294287660,  0.11868869083852226),
    (8.1368177379960860,  0.184404164598048070,  0.08105980073851838),
    (8.7859336938757110,  0.141312259088962540,  0.05550583770155003),
    (9.4868329805051400,  0.109620633779362030,  0.038101006347565733),
    (10.243646621500805,  0.086306098001573950,  0.026241357648188666),
    (11.060835193558726,  0.069152083210239560,  0.018173194139536157),
    (11.943215116604916,  0.056530489575896050,  0.012673582724586214),
    (12.895987041246831,  0.047243421645446780,  0.008922231009587215),
    (13.924766500838338,  0.040409825053424410,  0.006364210902611688),
    (15.035617008818167,  0.035381711990196174,  0.004624206234762901),
    (16.235085796393910,  0.031682156319832695,  0.0034367708044077834),
    (17.530242401205530,  0.028960087581117610,  0.002626631165599906),
    (18.928720334405797,  0.026957237257455670,  0.0020744135766666874),
    (20.438762071738836,  0.025483652537965060,  0.0016982308441742522),
    (22.069267633789240,  0.024399480963449340,  0.001441350587685605),
    (23.829847041728447,  0.023601812867855470,  0.00126593269871583),
    (25.730876957726823,  0.023014949847032000,  0.0011462887868655936),
    (27.783561843863803,  0.022583211440469780,  0.0010645558592928105)]
# [i:i+2]

CANNEX_data1 = [CANNEX_data0[27], CANNEX_data0[30]]

'''
Note in paper "https://arxiv.org/pdf/2405.14638", Hauke uses 2*sigma as the
constraint. Above values are for 1*sigma, so must modify to get consistent
constraint.
'''
CANNEX_data = [(cd[0], 2*cd[1], 2*cd[2]) for cd in CANNEX_data1]


sensor_plate = [Pt, W, Pt, W, Si, W, Pt, vac, Al]


' --------------------------------------------------------------------------- '
' --------------- Solve for the field and either save or plot --------------- '
' --------------------------------------------------------------------------- '

# Position of boundaries in um.
boundary_pos_lower_plate = [-13000.37, -8000.37, -6000.37, -0.37, -0.07]
sensor_plate_layer_thickness = [0.07, 0.3, 0.02, 5e-3, 100, 5e-3, 0.02,
                                5e3, 3e3]

sensor_plate_boundary_pos = np.round(
    [sum(sensor_plate_layer_thickness[:i+1])
     for i in range(len(sensor_plate_layer_thickness))], 5)


' --------------------------------------------------------------------------- '
' --------------------- Use saved data to generate plot --------------------- '
' --------------------------------------------------------------------------- '

fig, ax = plt.subplots(figsize=(8, 6))
ax.set_ylabel(r"$Log \left( \frac{\Lambda}{eV} \right)$")
ax.set_xlabel(r"$Log \left( \frac{M}{M_{PL}} \right)$")

# ax.set_ylim([-4, 1])
# ax.set_xlim([-18, 1])

data = []


for gap_size, target_pressure, target_pressure_grad in CANNEX_data:

    pressure_dis = []

    for displacement in [-dis, dis]:

        path = "Data/gradient/Boundary Data(_%.3fum)(%.3fum)(1)" % (
            gap_size, displacement)
        meshname = "CANNEX(%.3fum)(%.3fum)" % (gap_size, displacement)

        # Position of boundaries in um.
        boundary_pos_gap = [0, gap_size]
        boundary_pos_sensor_plate0 = list(sensor_plate_boundary_pos + gap_size)
        boundary_pos_sensor_plate = list(sensor_plate_boundary_pos + gap_size
                                         + displacement)

        boundary_pos0 = np.array(boundary_pos_lower_plate[1:]
                                 + boundary_pos_gap
                                 + boundary_pos_sensor_plate0[:-1])

        boundary_pos = np.array(boundary_pos_lower_plate[1:]
                                + boundary_pos_gap
                                + boundary_pos_sensor_plate[:-1])

        # Make function to compute pressure.
        def calc_rescaled_pressure(boundary_values):
            boundary_values_sensor = np.array(boundary_values[5:-1])

            layer_density = [0] + [sp for sp in sensor_plate[:-2]] + [0]

            p_diff = np.array([(p1 - p0) for p0, p1 in zip(layer_density[:-1],
                                                           layer_density[1:])])

            return abs(np.dot(boundary_values_sensor, p_diff))

        # Make plot for fixed Lambda value.
        pressure = []

        for lb in log_beta:

            name = path + "/LogB%.3f" % lb

            beta = 10**lb
            M = M_pl/beta                                # eV
            VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

            C = VEV*density/M

            with open(name, "r") as txt_file:
                bv = np.array(eval(txt_file.read()))

            pressure.append(C*calc_rescaled_pressure(boundary_values=bv))

        pressure_dis.append(eV4_to_pN_per_cm2*np.array(pressure))

    # Calculate pressure gradient.
    pressure_grad = (pressure_dis[1] - pressure_dis[0])/(2*dis)

    ' ------------------------------------------------------------------ '
    ' -------------- Make constraint plots using pressure -------------- '
    ' ------------------------------------------------------------------ '

    U = (length**0.8)*(density**0.6)  # a constant.

    eq_curve_grad = []
    for lb, _, p1_grad in zip(log_beta, pressure, pressure_grad):

        beta = 10**lb
        M1 = M_pl/beta                           # eV

        # Get alpha and field scale.
        alpha = alpha_calculator_chameleon(
            n, M1, Lambda_DE, p0=density_scale, L=length_scale,
            p0_NonEVUnits=density_unit, L_NonEVUnits=length_unit)

        M2_grad = M1*np.sqrt(abs(p1_grad)/target_pressure_grad)

        Lambda2_grad = U*(alpha**0.4)/(M2_grad**0.6)

        eq_curve_grad.append((M2_grad, Lambda2_grad))

    # Plot equal pressure curve.
    X = np.array([np.log10(para[0]/M_pl) for para in eq_curve_grad])
    Y = np.array([np.log10(para[1]) for para in eq_curve_grad])

    ax.plot(X, Y, linestyle="solid", label=r"$\delta = %s$" % str(gap_size))
    data.append(Y)

ax.legend()
plt.show()

# Plot difference.
if True:
    D = data[0] - data[1]

    fig2, ax2 = plt.subplots(figsize=(8, 6))
    ax2.axhline(y=0.0, color='r', linestyle='--')
    ax2.plot(X, D)

    # Find beta value corresponding to cross over.
    for i, xi in enumerate(X):
        if i < 30:
            continue

        if D[i] < 0:
            print("Cross over at :", i)
            plt.plot([xi], [0], "r.")
            break

    plt.show()
