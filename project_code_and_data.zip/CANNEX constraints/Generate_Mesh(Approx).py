#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 19 16:33:06 2026

@author: chad-briddon

Generate mesh of the Casimir experiment / an approximation of CANNEX.

*This code ran using SELCIE v2.0.0.

"""

from SELCIE.Mesh import MeshingTools_1D


Extended = True


gap_size = 50
filename = "CANNEX(Approx)(Extended)"


gap_size = 20.438762071738836
filename = "CANNEX(Approx)(20.439um)"

' --------------------- Set Parameters (in units of um) --------------------- '


# Lower plate (top-to-bottom).
lower_plate_boundary_pos = [-13000.37, 0]


# Sensor plate (top-to-bottom).

sensor_plate_boundary_pos = [gap_size, gap_size+100.42, gap_size+5100.42,
                             gap_size+8100.42]


' ----------------------------- Construct Mesh ----------------------------- '


# if Extended:
#     filename += "(Extended)"


L_id = []
MT = MeshingTools_1D(display_messages=True)

# Wall
L_id += MT.create_1D_line(x_start=-13000.37, x_end=0, embed=L_id)
MT.create_subdomain(CellSizeMin=1e-4, CellSizeMax=1, DistMax=1000)

# Vacuum
L_id += MT.create_1D_line(x_start=-1, x_end=gap_size, embed=L_id)
MT.create_subdomain(CellSizeMin=1e-4, CellSizeMax=1, DistMax=1000)

# Sensor
L_id += MT.create_1D_line(x_start=1, x_end=gap_size+100.42, embed=L_id)
MT.create_subdomain(CellSizeMin=1e-4, CellSizeMax=1, DistMin=0.3, DistMax=1000)

# Vacuum
L_id += MT.create_1D_line(x_start=1, x_end=gap_size+5100.42, embed=L_id)
MT.create_subdomain(CellSizeMin=1e-4, CellSizeMax=1, DistMax=1000)


# Shield
if Extended:
    L_id += MT.create_1D_line(x_start=1, x_end=8150.42+2000, embed=L_id)
else:
    L_id += MT.create_1D_line(x_start=1, x_end=8150.42, embed=L_id)

MT.create_subdomain(CellSizeMin=1e-4, CellSizeMax=1, DistMax=1000)


MT.generate_mesh(filename, show_mesh=True)
MT.msh_2_xdmf(filename, auto_override=True)
