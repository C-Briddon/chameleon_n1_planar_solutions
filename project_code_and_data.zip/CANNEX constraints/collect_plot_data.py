#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep 30 13:39:00 2026

@author: chad-briddon

This function collects the results obtained using different initial conditions
into a single directory that is to be used for making plots. Directories will
be labelled as '(5)'.

*Made redundent thanks to improvements to solution finder code.

"""

import shutil

from _initalise import np, plt, mkdir, exists
from _initalise import Lambda_DE, M_pl, Pt, W, Si, density, eV4_to_pN_per_cm2


plt.rc('axes', labelsize=15)
plt.rc('legend', fontsize=15)


' --------------------------------------------------------------------------- '

log_beta0 = list(np.round(np.linspace(-1.0, 6.0, 141), 4))

log_beta_list = [
    ("(2)", list(np.round(np.linspace(-1.0, 6.0, 141), 4)[:90])),
    ("(2)", list(np.round(np.linspace(-1.0, 6.0, 141), 4)[91:116])),
    ("(4)", [4.80, 4.85, 4.90, 4.95, 5.00]),
    ("(2)", list(np.round(np.linspace(-1.0, 6.0, 141), 4)[130:]))]


i = 25
CANNEX_data0 = [
    (3.0000000000000000, 10.090243035439571000, 14.603095459424381),
    (3.2393254869831290,  7.239265226328643000,  9.616859314745363),
    (3.4977432035394953,  5.209746816906757000,  6.349530521313371),
    (3.7767762353825017,  3.762123975244741500,  4.2019586220269085),
    (4.0780691726355770,  2.726937132507061500,  2.7869309141499744),
    (4.4033978028662080,  1.984441567560577600,  1.8537823604368068),
    (4.7546795773833400,  1.450062943850155800,  1.2390100958957337),
    (5.1339849124853420,  1.064043298534854200,  0.8310695867563316),
    (5.5435493922668740,  0.784126522542000400,  0.5593909954110098),
    (5.9857869449066390,  0.580416627413294250,  0.3778709727083459),
    (6.4633040700956520,  0.431703095079227900,  0.25626667114744717),
    (6.9789152014608790,  0.322856224000782670,  0.17421719563186385),
    (7.5356592945287405,  0.243029522294287660,  0.11868869083852226),
    (8.1368177379960860,  0.184404164598048070,  0.08105980073851838),
    (8.7859336938757110,  0.141312259088962540,  0.05550583770155003),
    (9.4868329805051400,  0.109620633779362030,  0.038101006347565733),
    (10.243646621500805,  0.086306098001573950,  0.026241357648188666),
    (11.060835193558726,  0.069152083210239560,  0.018173194139536157),
    (11.943215116604916,  0.056530489575896050,  0.012673582724586214),
    (12.895987041246831,  0.047243421645446780,  0.008922231009587215),
    (13.924766500838338,  0.040409825053424410,  0.006364210902611688),
    (15.035617008818167,  0.035381711990196174,  0.004624206234762901),
    (16.235085796393910,  0.031682156319832695,  0.0034367708044077834),
    (17.530242401205530,  0.028960087581117610,  0.002626631165599906),
    (18.928720334405797,  0.026957237257455670,  0.0020744135766666874),
    (20.438762071738836,  0.025483652537965060,  0.0016982308441742522),
    (22.069267633789240,  0.024399480963449340,  0.001441350587685605),
    (23.829847041728447,  0.023601812867855470,  0.00126593269871583),
    (25.730876957726823,  0.023014949847032000,  0.0011462887868655936),
    (27.783561843863803,  0.022583211440469780,  0.0010645558592928105)]
# [i:i+1]


'''
Note in paper "https://arxiv.org/pdf/2405.14638", Hauke uses 2*sigma as the
constraint. Above values are for 1*sigma, so must modify to get consistent
constraint.
'''
CANNEX_data = [(cd[0], 2*cd[1]) for cd in CANNEX_data0]

sensor_plate = [Pt, W, Pt, W, Si, W, Pt]


' --------------------------------------------------------------------------- '
' --------------- Solve for the field and either save or plot --------------- '
' --------------------------------------------------------------------------- '

for gap_size, target_pressure in CANNEX_data:

    path = "Data/field/Boundary Data(_%.3fum)" % gap_size

    # path = "Data/gradient/Boundary Data(_%.3fum)(-0.100um)" % gap_size
    # path = "Data/gradient/Boundary Data(_%.3fum)(0.100um)" % gap_size

    path = "Data/field/Boundary Data(_%.3fum)(NoVac)" % gap_size
    # path = "Data/field/Boundary Data(_%.3fum)(PartialVac)" % gap_size

    path0 = path + "(1)"
    path_new = path + "(5)"

    if exists(path_new):
        pass
    else:
        mkdir(path_new)

    ' ---------------------------------------------------------------------- '
    ' ------------ Use save boundary values to compute pressure ------------ '
    ' ---------------------------------------------------------------------- '

    def calc_rescaled_pressure(boundary_values):
        boundary_values_sensor = np.array(boundary_values[5:-1])

        layer_density = [0] + [sp for sp in sensor_plate] + [0]

        p_diff = np.array([(p1 - p0) for p0, p1 in zip(layer_density[:-1],
                                                       layer_density[1:])])

        return abs(np.dot(boundary_values_sensor, p_diff))

    # Make plot for fixed Lambda value.
    pressure0 = []
    pressure = []
    log_beta = []

    for index, log_beta1 in log_beta_list:

        for lb in log_beta1:

            name = path + index + "/LogB%.3f" % lb
            name_new = path_new + "/LogB%.3f" % lb

            beta = 10**lb
            M = M_pl/beta                                  # eV

            C = density/M

            with open(name, "r") as txt_file:
                bv = np.array(eval(txt_file.read()))

            if True:
                # Copy boundary folder to new directory.
                shutil.copyfile(name, name_new)

            pressure.append(C*calc_rescaled_pressure(boundary_values=bv))
            log_beta.append(lb)

    # Get SELCIE result for comparison.
    for lb in log_beta0:

        name0 = path0 + "/LogB%.3f" % lb

        beta = 10**lb
        M = M_pl/beta                                      # eV
        VEV = np.sqrt((M*Lambda_DE**5)/density)            # eV

        C = VEV*density/M

        with open(name0, "r") as txt_file:
            bv0 = np.array(eval(txt_file.read()))

        pressure0.append(C*calc_rescaled_pressure(boundary_values=bv0))

    # Rescale pressure from natural units to pN/cm^2.
    pressure0 = eV4_to_pN_per_cm2*np.array(pressure0)
    pressure = eV4_to_pN_per_cm2*np.array(pressure)

    # Plot pressure against beta (Lambda is fixed).
    fig3, ax3 = plt.subplots(figsize=(8, 6))
    fig3.suptitle("d = %f" % gap_size)
    ax3.set_ylabel(r"$|p_z| / \left( pN/cm^{-2} \right)$")
    ax3.set_xlabel(r"$Log(\beta)$")

    ax3.plot(log_beta0, pressure0, label="Numeric", linestyle="solid")
    ax3.plot(log_beta, pressure, label="Analytic", linestyle="dashed")

    fig3.legend()
    plt.show()
