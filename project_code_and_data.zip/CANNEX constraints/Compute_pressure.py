#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Apr 17 02:47:57 2026

@author: chad-briddon

Use analytic solution to compute pressure on sensor plate in the CANNEX
experiment.

Boundary value data saved to :
    Using SELCIE                                - (1)
    Analytic using above for initial guess      - (2)
    Analytic using default initial guess        - (3)
    Analytic using last solution as new guess   - (4)

"""

from _initalise import np, plt, mkdir, exists
from _initalise import n, Lambda_DE, M_pl
from _initalise import Al, vac, Pt, W, Si, Cu, SiO2
from _initalise import density, length, density_unit, length_unit
from _initalise import eV4_to_pN_per_cm2, density_scale, length_scale
from _initalise import kg_per_m3_2_eV4, units

from SELCIE.Misc import alpha_calculator_chameleon  # v2.0.0
from chameleon_n1_planar_solutions.solutions import planar_solution

from timeit import default_timer


plt.rc('axes', labelsize=15)
plt.rc('legend', fontsize=15)


NoVac_Options = None

if NoVac_Options is None:
    pass

elif NoVac_Options == 1:
    vac *= 5e11

elif NoVac_Options == 3:
    vac *= 1e9


' --------------------------------------------------------------------------- '

log_beta0 = list(np.round(np.linspace(-1.0, 6.0, 141), 4))
log_beta1 = list(np.round(np.linspace(-1.0, 6.0, 141), 4))


i = 25
CANNEX_data0 = [(3.0000000000000000, 10.09024303543957100),
                (3.2393254869831290, 7.239265226328643000),
                (3.4977432035394953, 5.209746816906757000),
                (3.7767762353825017, 3.762123975244741500),
                (4.0780691726355770, 2.726937132507061500),
                (4.4033978028662080, 1.984441567560577600),
                (4.7546795773833400, 1.450062943850155800),
                (5.1339849124853420, 1.064043298534854200),
                (5.5435493922668740, 0.784126522542000400),
                (5.9857869449066390, 0.580416627413294250),
                (6.4633040700956520, 0.431703095079227900),
                (6.9789152014608790, 0.322856224000782670),
                (7.5356592945287405, 0.243029522294287660),
                (8.1368177379960860, 0.184404164598048070),
                (8.7859336938757110, 0.141312259088962540),
                (9.4868329805051400, 0.109620633779362030),
                (10.243646621500805, 0.086306098001573950),
                (11.060835193558726, 0.069152083210239560),
                (11.943215116604916, 0.056530489575896050),
                (12.895987041246831, 0.047243421645446780),
                (13.924766500838338, 0.040409825053424410),
                (15.035617008818167, 0.035381711990196174),
                (16.235085796393910, 0.031682156319832695),
                (17.530242401205530, 0.028960087581117610),
                (18.928720334405797, 0.026957237257455670),
                (20.438762071738836, 0.025483652537965060),
                (22.069267633789240, 0.024399480963449340),
                (23.829847041728447, 0.023601812867855470),
                (25.730876957726823, 0.023014949847032000),
                (27.783561843863803, 0.022583211440469780)]  # [i:i+1]


'''
Note in paper "https://arxiv.org/pdf/2405.14638", Hauke uses 2*sigma as the
constraint. Above values are for 1*sigma, so must modify to get consistent
constraint.
'''
CANNEX_data = [(cd[0], 2*cd[1]) for cd in CANNEX_data0]


' ---------------------- Define densities of materials ---------------------- '

# Assign correct density to each layer ('left --> right' == 'bottom --> top').
lower_plate = [Al, Cu, SiO2, W, Pt]
gap = [vac]
sensor_plate = [Pt, W, Pt, W, Si, W, Pt, vac, Al]

density_profile = np.array(lower_plate + gap + sensor_plate)


# Convert densites to natural units.
density_profile *= density_unit.to(units.kg*units.m**(-3))*kg_per_m3_2_eV4


' --------------------------------------------------------------------------- '
' --------------- Solve for the field and either save or plot --------------- '
' --------------------------------------------------------------------------- '

for gap_size, target_pressure in CANNEX_data:

    path0 = "Data/field/Boundary Data(_%.3fum)(1)" % gap_size
    path = "Data/field/Boundary Data(_%.3fum)(4)" % gap_size

    if NoVac_Options is None:
        pass

    elif NoVac_Options == 1:
        path0 = "Data/field/Boundary Data(_%.3fum)(NoVac)(1)" % gap_size
        path = "Data/field/Boundary Data(_%.3fum)(NoVac)(4)" % gap_size

    elif NoVac_Options == 3:
        path0 = "Data/field/Boundary Data(_%.3fum)(PartialVac)(1)" % gap_size
        path = "Data/field/Boundary Data(_%.3fum)(PartialVac)(4)" % gap_size

    if exists(path):
        pass
    else:
        mkdir(path)

    ' ---------------------- Assign boundary locations ---------------------- '

    boundary_pos_lower_plate = [-13000.37, -8000.37, -6000.37, -0.37, -0.07]
    boundary_pos_gap = [0, gap_size]
    boundary_pos_sensor_plate = [gap_size+0.07, gap_size+0.37, gap_size+0.39,
                                 gap_size+0.395, gap_size+100.395,
                                 gap_size+100.4, gap_size+100.42,
                                 gap_size+5100.42, gap_size+8100.42]

    boundary_pos = np.array(boundary_pos_lower_plate[1:] + boundary_pos_gap
                            + boundary_pos_sensor_plate[:-1])

    ' ----------------------- Solve for field profile ----------------------- '

    # For (4). Rescale guess by sqrt(M_new/M_old).
    boundary_guess_hold = None

    # Choose initial guess.
    boundary_guess = []
    boundary_guess = None

    if False:
        # Load a specific initial guess.
        with open("Data/field/Boundary Data(_%.3fum)(2)/LogB1.500"
                  % gap_size, "r") as txt_file:
            boundary_guess = np.array(eval(txt_file.read()))

    # Iterate over parameters.
    for lb in reversed(log_beta1):

        name0 = path0 + "/LogB%.3f" % lb
        name = path + "/LogB%.3f" % lb

        beta = 10**lb
        M = M_pl/beta                                # eV
        VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

        # Skip if needed.
        if len(log_beta1) > 1 and exists(name) is True:
            with open(name, "r") as txt_file:
                boundary_guess = np.array(eval(txt_file.read()))
                boundary_guess_hold = boundary_guess/np.sqrt(M)
            continue

        print(name)

        # Load solution from saved SELCIE data.
        if path[-2] == "2":
            with open(name0, "r") as txt_file:
                boundary_guess = np.array(eval(txt_file.read()))*VEV

        elif path[-2] == "3":
            boundary_guess = None

        elif path[-2] == "4":
            if boundary_guess_hold is None:
                pass
            else:
                boundary_guess = boundary_guess_hold*np.sqrt(M)

        # Solve for field profile.
        t0 = default_timer()
        func, boundary_values, _ = planar_solution(
            Lambda_DE, M, densities=density_profile,
            boundary_positions=boundary_pos, boundary_guess=boundary_guess,
            density_NonEVUnits=None, length_NonEVUnits=length_unit,
            use_boundary_guess=False)

        t1 = default_timer()
        print("Time is :", t1-t0)

        print(boundary_guess)
        print(boundary_values)
        print()

        boundary_guess = boundary_values
        boundary_guess_hold = boundary_guess/np.sqrt(M)

        if len(log_beta1) > 1:
            ' -------------- Record field values at boundaries -------------- '
            with open(name, "w") as tf:
                tf.write(str(list(boundary_values)))

        else:
            print("BV :", boundary_values)

            ' ----------------- Make plot of field profile ----------------- '
            # Plot full field.
            X_min = -13000.37
            X_max = 8150.42

            X_full = np.linspace(X_min, X_max, 2115080)

            field_full = func(X_full)

            fig1, ax1 = plt.subplots(figsize=(8, 6))
            ax1.set_ylabel(r"$\phi / eV$")
            ax1.set_xlabel(r"$z/\mu m$")
            ax1.set_xlim([X_min, X_max])

            ax1.axvspan(X_min, 0, alpha=0.4)  # Fill lower plate.
            ax1.axvspan(50, 150.42, alpha=0.4, color='lightcoral')  # sensor.
            ax1.axvspan(5150.42, X_max, alpha=0.4,
                        color='lightcoral')  # sheild.

            ax1.plot(X_full, field_full)

            plt.show()

            if len(log_beta1) == 1:
                fig1.savefig("Images/field(3)_LogB%.3f(full)(1).png" % lb,
                             dpi=300, bbox_inches='tight')

            # Plot field zoomed in onto a specific section.
            X2_min, X2_max = -20, 70
            X2_min, X2_max = -20, 180

            X_zoom = np.linspace(X2_min, X2_max, 9001)

            field_zoom = func(X_zoom)

            fig2, ax2 = plt.subplots(figsize=(8, 6))
            ax2.set_ylabel(r"$\phi / eV$")
            ax2.set_xlabel(r"$z/\mu m$")
            ax2.set_xlim([X2_min, X2_max])

            ax2.axvspan(X2_min, 0, alpha=0.4)  # Fill lower plate.
            ax2.axvspan(50, min(X2_max, 150.42), alpha=0.4,
                        color='lightcoral')  # Fill sensor plate.

            plt.plot(X_zoom, field_zoom)

            plt.show()

    # continue
    ' ---------------------------------------------------------------------- '
    ' ------------ Use save boundary values to compute pressure ------------ '
    ' ---------------------------------------------------------------------- '

    def calc_rescaled_pressure(boundary_values):
        boundary_values_sensor = np.array(boundary_values[5:-1])

        layer_density = [0] + [sp for sp in sensor_plate[:-2]] + [0]

        p_diff = np.array([(p1 - p0) for p0, p1 in zip(layer_density[:-1],
                                                       layer_density[1:])])

        return abs(np.dot(boundary_values_sensor, p_diff))

    # Make plot for fixed Lambda value.
    pressure0 = []
    pressure = []

    for lb in log_beta1:

        name = path + "/LogB%.3f" % lb

        beta = 10**lb
        M = M_pl/beta                                # eV
        VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

        C = density/M

        with open(name, "r") as txt_file:
            bv = np.array(eval(txt_file.read()))

        pressure.append(C*calc_rescaled_pressure(boundary_values=bv))

    for lb in log_beta0:

        name0 = path0 + "/LogB%.3f" % lb

        beta = 10**lb
        M = M_pl/beta                                # eV
        VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

        C = VEV*density/M

        with open(name0, "r") as txt_file:
            bv0 = np.array(eval(txt_file.read()))

        pressure0.append(C*calc_rescaled_pressure(boundary_values=bv0))

    # Rescale pressure from natural units to pN/cm^2.
    pressure0 = eV4_to_pN_per_cm2*np.array(pressure0)
    pressure = eV4_to_pN_per_cm2*np.array(pressure)

    # Plot pressure against beta (Lambda is fixed).
    ''''''
    fig3, ax3 = plt.subplots(figsize=(8, 6))
    fig3.suptitle("d = %f" % gap_size)
    ax3.set_ylabel(r"$|p_z| / \left( pN/cm^{-2} \right)$")
    ax3.set_xlabel(r"$Log(\beta)$")

    ax3.plot(log_beta0, pressure0, label="Numeric", linestyle="solid")
    ax3.plot(log_beta1, pressure, label="Analytic", linestyle="dashed")

    fig3.legend()

    ' ---------------------------------------------------------------------- '
    ' ---------------- Make constraint plots using pressure ---------------- '
    ' ---------------------------------------------------------------------- '
    # continue
    U = (length**0.8)*(density**0.6)  # a constant.

    fig4, ax4 = plt.subplots(figsize=(8, 6))
    ax4.set_ylabel(r"$Log \left( \frac{\Lambda}{eV} \right)$")
    ax4.set_xlabel(r"$Log \left( \frac{M}{M_{PL}} \right)$")

    # ax4.set_ylim([-4, 1])
    # ax4.set_xlim([-18, 1])

    # ax4.axhline(y=np.log10(Lambda_DE))

    # target_pressure = [1, 1e-1, 1e-2, 1e-3, 1e-4]
    # target_pressure = [1e-3, 1e-4, 1e-5]
    eq_curves = []

    # for p2 in target_pressure:
    for p2 in [target_pressure]:
        eq_curves.append([])

        for lb, p1 in zip(log_beta1, pressure):
            # for lb, p1 in zip(log_beta0, pressure0):

            beta = 10**lb
            M1 = M_pl/beta                           # eV

            # Get alpha and field scale.
            alpha = alpha_calculator_chameleon(
                n, M1, Lambda_DE, p0=density_scale, L=length_scale,
                p0_NonEVUnits=density_unit, L_NonEVUnits=length_unit)

            M2 = M1*np.sqrt(p1/p2)
            Lambda2 = U*(alpha**0.4)/(M2**0.6)

            # if np.log10(M2/M_pl) < -17.1:
            #     break

            eq_curves[-1].append((M2, Lambda2))

    # Plot equal pressure curve.
    for eq_curve in eq_curves:
        X = np.array([np.log10(para[0]/M_pl) for para in eq_curve])
        Y = np.array([np.log10(para[1]) for para in eq_curve])

        ax4.plot(X, Y, color="blue", linestyle="solid", marker=".")
        print(min(X))

    ' ---------------------------------------------------------------------- '
    ' ------------------ Add pressure small Compton limit ------------------ '
    ' ---------------------------------------------------------------------- '
    '''
    # In the limit of Compton wavelength to zero, the boundary values all tend
    # to the root mean average. The pressure is then :
    #   p = sqrt(Lam^5/M)*(sqrt(rho_1) - sqrt(rho_N))

    # Irrelavent since both outer layers have the same density, so P -- > 0.

    # If made of different materials this would be non-zero.

    P_1 = sensor_plate[0]
    P_N = sensor_plate[-4]  # Ignored layer for non-zero result. Should be [-3]
    P_factor = abs(np.sqrt(P_1) - np.sqrt(P_N))

    # Get pressure for fixed Lambda.
    P_Lam = []

    for lb in log_beta1:

        beta = 10**lb
        M = M_pl/beta                                # eV

        P_Lam.append(np.sqrt((Lambda_DE**5)/M)*P_factor)
    plt.figure()
    plt.plot(log_beta1, P_Lam, color="green", linestyle="dashdot")

    # Add equal pressure curves.
    P_ref = np.sqrt((Lambda_DE**5)/M_pl)*P_factor
    P_target = 1e-4

    r = (P_target/P_ref)**0.4
    log_beta2 = np.linspace(-18, 60, 1901)
    beta2 = 10**log_beta2

    Lambda2 = Lambda_DE*r/(beta2**0.2)

    plt.figure()
    plt.plot(np.log10(beta2), np.log10(Lambda2), color="green",
             linestyle="dashed")
    '''
