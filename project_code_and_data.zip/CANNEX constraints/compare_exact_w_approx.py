#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jun  1 15:48:44 2026

@author: chad-briddon

Make plots showing the pressure as a function for M, for approximate setups
and exact.

"""

from _initalise import np, plt
from _initalise import Lambda_DE, M_pl
from _initalise import Al, vac, Pt, W, Si
from _initalise import density, length
from _initalise import eV4_to_pN_per_cm2


plt.rc('axes', labelsize=15)
plt.rc('legend', fontsize=15)


path0 = "Data/field/Boundary Data(Apx)(_20.439um)(4)"
path = "Data/field/Boundary Data(_20.439um)(4)"


log_beta0 = list(np.round(np.linspace(-1.0, 6.0, 141), 4))
log_beta1 = list(np.round(np.linspace(-1.0, 6.0, 141), 4))


' -------------------------------------------------------------------------- '
' -------------- Use save boundary values to compute pressure -------------- '
' -------------------------------------------------------------------------- '

sensor_plate = [Pt, W, Pt, W, Si, W, Pt, vac, Al]

sensor_layer_thickness = np.array([0.07, 0.3, 0.02, 5e-3, 100, 5e-3, 0.02])
sensor_layer_density = np.array([Pt, W, Pt, W, Si, W, Pt])

p_sensor = np.dot(sensor_layer_thickness,
                  sensor_layer_density)/np.sum(sensor_layer_thickness)


def calc_rescaled_pressure(boundary_values):
    boundary_values_sensor = np.array(boundary_values[5:-1])

    layer_density = [0] + [sp for sp in sensor_plate[:-2]] + [0]

    p_diff = np.array([(p1 - p0) for p0, p1 in zip(layer_density[:-1],
                                                   layer_density[1:])])

    return abs(np.dot(boundary_values_sensor, p_diff))


def calc_rescaled_pressure_apx(boundary_values):
    return abs(p_sensor*(boundary_values[1] - boundary_values[2]))


# Make plot for fixed Lambda value.

pressure0 = []
pressure = []

for lb in log_beta1:

    name = path + "/LogB%.3f" % lb

    beta = 10**lb
    M = M_pl/beta                                # eV
    VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

    C = density/M
    # C = VEV*density/M

    with open(name, "r") as txt_file:
        bv = np.array(eval(txt_file.read()))

    pressure.append(C*calc_rescaled_pressure(boundary_values=bv))

for lb in log_beta0:

    name0 = path0 + "/LogB%.3f" % lb

    beta = 10**lb
    M = M_pl/beta                                # eV
    VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

    C = density/M
    # C = VEV*density/M

    with open(name0, "r") as txt_file:
        bv0 = np.array(eval(txt_file.read()))

    pressure0.append(C*calc_rescaled_pressure_apx(boundary_values=bv0))


# Rescale pressure from natural units to pN/cm^2.
pressure0 = eV4_to_pN_per_cm2*np.array(pressure0)
pressure = eV4_to_pN_per_cm2*np.array(pressure)


# Plot pressure against beta (Lambda is fixed).
fig, ax = plt.subplots(figsize=(8, 4.5))
plt.rcParams["font.size"] = 12

ax.set_ylabel(r"$|p_z| / \left( \rm{fN/cm^{2}} \right)$")
# ax.set_xlabel(r"$Log(\beta)$")
ax.set_xlabel(r"$M / M_{\rm pl}$")

ax.set_xscale('log')

ax.set_xlim([1e-6, 1e1])

beta0 = 10**np.array(log_beta0)
beta1 = 10**np.array(log_beta1)

pressure0 *= 1000  # change from pico to femto.
pressure *= 1000   # change form pico to femto.

ax.plot(1/beta1, pressure, label="$15$-layer", linestyle="solid", color="C1")
ax.plot(1/beta0, pressure0, label="$\ \ 5$-layer", linestyle="dashed",
        color="C0")


# Add line showing when Compton wavelength in sheild is 10% its width.
Comp_SheildL_ratio = 0.1
SheildL = 3000  # um
Comp_um = Comp_SheildL_ratio*SheildL

Comp_eV = Comp_um*length
density_AL_eV = Al*density

constant = 4*(Comp_eV**4)*(density_AL_eV**3)/(M_pl**3)

beta = (constant/(Lambda_DE**5))**(-1/3)
print(np.log10(beta))

ax.axvline(1/beta, color="black", linestyle="solid")


ax.legend()
fig.savefig("Images/Compare_pressure(fixed_Lam)(20.4um).png",
            dpi=300, bbox_inches='tight')


' --------- Plot relative magnitude of deviation between solutions --------- '

# rel_err = abs(pressure0[41:] - pressure[23:])/pressure[23:]  # (50um)
# beta = 10**np.round(np.linspace(0.15, 6.0, 118), 6)


# (20.4um)
i0, i1 = 46, 90

# Check we are using consistent x-axis.
print("Max x-axis diff is :", max(abs(
    np.array(log_beta0[i0:i1]) - np.array(log_beta1[i0:i1]))))


rel_err = abs(pressure0[i0:i1] - pressure[i0:i1])/pressure[i0:i1]
beta = 10**np.round(np.linspace(6.0, -1.0, 141), 6)[i0:i1]


plt.figure()
plt.ylabel("rel error (%)")
plt.xlabel(r"$M / M_{\rm pl}$")

plt.xscale('log')

plt.plot(1/beta, rel_err*100)
