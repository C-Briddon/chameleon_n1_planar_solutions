#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 19 15:47:35 2026

@author: chad-briddon

Use SELCIE to compute the boundary values, and therefore the pressure on sensor
plate in a generic Casimir type experiment, with a plate of uniform density.

For densities will use average densities of CANNEX plate and wall.

*This code ran using SELCIE v2.0.0.

"""

from _initalise import np, plt, mkdir, exists, n, Lambda_DE, M_pl
from _initalise import Al, vac, Pt, W, Si, Cu, SiO2, density, length
from _initalise import eV4_to_pN_per_cm2, density_scale, length_scale
from _initalise import length_unit, density_unit

from SELCIE.Solvers import Chameleon
from SELCIE.Misc import alpha_calculator_chameleon


# Beta. Single value gives plot, and multiple saves boundary values.
log_beta = list(np.round(np.linspace(-1.0, 6.0, 141), 4))


' --------------------------------------------------------------------------- '
' ------------------------------- Choose mesh ------------------------------- '
' --------------------------------------------------------------------------- '

gap_size = 50                                    # um
meshname = "CANNEX(Approx)(Extended)"
path = "Data/field/Boundary Data(Apx)(1)"


gap_size = 20.438762071738836                    # um
meshname = "CANNEX(Approx)(20.439um)"
path = "Data/field/Boundary Data(Apx)(_20.439um)(1)"


if exists(path):
    pass
else:
    mkdir(path)


' -------------------------------------------------------------------------- '
' -------------------- Physical dimensionful parameters -------------------- '
' -------------------------------------------------------------------------- '

# Calculate average densities for the wall and plate.
wall_layer_thickness = np.array([5000, 2000, 6000, 0.3, 0.07])
wall_layer_density = np.array([Al, Cu, SiO2, W, Pt])

p_wall = np.dot(wall_layer_thickness,
                wall_layer_density)/np.sum(wall_layer_thickness)


sensor_layer_thickness = np.array([0.07, 0.3, 0.02, 5e-3, 100, 5e-3, 0.02])
sensor_layer_density = np.array([Pt, W, Pt, W, Si, W, Pt])

p_sensor = np.dot(sensor_layer_thickness,
                  sensor_layer_density)/np.sum(sensor_layer_thickness)


# Position of boundaries in um.
boundary_pos_lower_plate = [-13000.37, 0]
boundary_pos_sensor_plate = [gap_size, gap_size+100.42,
                             gap_size+5100.42, gap_size+8100.42]
boundary_pos_sensor_plate[-1] += 2000  # Extend simulation.

boundary_pos = np.array(boundary_pos_lower_plate[1:] +
                        boundary_pos_sensor_plate[:-1])


' --------------------------------------------------------------------------- '
' ----------------------------- Setup functions ----------------------------- '
' --------------------------------------------------------------------------- '


def wall(x):
    return p_wall


def vacuum(x):
    return vac


def sensor(x):
    return p_sensor


def shield(x):
    return Al


density_profile = [wall, vacuum, sensor, vacuum, shield]


' --------------------------------------------------------------------------- '
' --------------- Solve for the field and either save or plot --------------- '
' --------------------------------------------------------------------------- '

for lb in log_beta:

    name = path + "/LogB%.3f" % lb

    # Skip if needed.
    if len(log_beta) > 1 and exists(name) is True:
        continue

    print(name)

    beta = 10**lb
    M = M_pl/beta                                # eV
    VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

    # Get alpha and field scale.
    alpha = alpha_calculator_chameleon(n, M, Lambda_DE, p0=density_scale,
                                       L=length_scale,
                                       p0_NonEVUnits=density_unit,
                                       L_NonEVUnits=length_unit)

    s = Chameleon(alpha, n, mesh_name=meshname, dimension=1,
                  symmetry="translation symmetry")

    s.solve_static(density_profiles=density_profile, maxiter=100, tol_du=1e-8)

    if len(log_beta) > 1:
        ' ---------------- Record field values at boundaries ---------------- '
        with open(name, "w") as tf:
            tf.write(str([s.field(xi, 0) for xi in boundary_pos]))
    else:
        print("BV :", [VEV*s.field(xi, 0) for xi in boundary_pos])

    ' ------------------- Make plot of field profile ------------------- '

    s.field.vector()[:] *= VEV  # Puts in units of eV.

    # Plot full field.
    X_min = -13000.37
    X_max = 8100.42

    # X_full = np.linspace(X_min, X_max, 2115080)
    X_max += 2000
    X_full = np.linspace(X_min, X_max, 2315080)

    field_full = np.array([s.field(xi, 0) for xi in X_full])

    fig1, ax1 = plt.subplots(figsize=(8, 6))
    ax1.set_ylabel(r"$\phi / eV$")
    ax1.set_xlabel(r"$z/\mu m$")
    ax1.set_xlim([X_min, X_max])

    ax1.axvspan(X_min, 0, alpha=0.4)  # lower plate.
    ax1.axvspan(gap_size, 100.42, alpha=0.4, color='lightcoral')  # sensor.
    ax1.axvspan(5100.42, X_max, alpha=0.4, color='lightcoral')  # shield.

    ax1.plot(X_full, field_full)

    plt.show()

    if len(log_beta) == 1:
        fig1.savefig("Images/field_LogB%.3f(full)(Apx)(1).png" % lb,
                     dpi=300, bbox_inches='tight')

    # Plot field zoomed in onto a specific section.
    X2_min, X2_max = -20, 70
    X2_min, X2_max = -20, 180

    X_zoom = np.linspace(X2_min, X2_max, 9001)

    field_zoom = np.array([s.field(xi, 0) for xi in X_zoom])

    fig2, ax2 = plt.subplots(figsize=(8, 6))
    ax2.set_ylabel(r"$\phi / eV$")
    ax2.set_xlabel(r"$z/\mu m$")
    ax2.set_xlim([X2_min, X2_max])

    ax2.axvspan(X2_min, 0, alpha=0.4)  # Fill lower plate.
    ax2.axvspan(gap_size, min(X2_max, 100.42+gap_size), alpha=0.4,
                color='lightcoral')  # Fill sensor plate.

    plt.plot(X_zoom, field_zoom)

    plt.show()

    # Make sure boundary conditions are correct
    VEV_Al = VEV/np.sqrt(Al)
    print("Boundary values : %f and %f" % (field_full[1]/VEV_Al,
                                           field_full[-1]/VEV_Al))

    if len(log_beta) == 1:
        fig2.savefig("Images/field_LogB%.3f(sensor)(Apx)(1).png" % lb,
                     dpi=300, bbox_inches='tight')


' -------------------------------------------------------------------------- '
' -------------- Use save boundary values to compute pressure -------------- '
' -------------------------------------------------------------------------- '


def calc_rescaled_pressure(boundary_values):
    return abs(p_sensor*(boundary_values[1] - boundary_values[2]))


# Make plot for fixed Lambda value.

pressure = []

for lb in log_beta:

    name = path + "/LogB%.3f" % lb

    beta = 10**lb
    M = M_pl/beta                                # eV
    VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

    C = VEV*density/M

    with open(name, "r") as txt_file:
        bv = np.array(eval(txt_file.read()))

    pressure.append(C*calc_rescaled_pressure(boundary_values=bv))


# Rescale pressure from natural units to pN/cm^2.


pressure = eV4_to_pN_per_cm2*np.array(pressure)


# Plot pressure against beta (Lambda is fixed).
fig3, ax3 = plt.subplots(figsize=(8, 6))
ax3.set_ylabel(r"$|p_z| / \left( pN/cm^{-2} \right)$")
ax3.set_xlabel(r"$Log(\beta)$")


ax3.plot(log_beta, pressure, label="exact")

fig3.legend()


' -------------------------------------------------------------------------- '
' ------------------ Make constraint plots using pressure ------------------ '
' -------------------------------------------------------------------------- '

U = (length**0.8)*(density**0.6)  # a constant.


fig4, ax4 = plt.subplots(figsize=(8, 6))
ax4.set_ylabel(r"$Log \left( \frac{\Lambda}{eV} \right)$")
ax4.set_xlabel(r"$Log \left( \frac{M}{M_{PL}} \right)$")

ax4.set_ylim([-4, 1])
ax4.set_xlim([-18, 1])

ax4.axhline(y=np.log10(Lambda_DE))


# target_pressure = [1, 1e-1, 1e-2, 1e-3, 1e-4]
target_pressure = [1e-3, 1e-4, 1e-5]
eq_curves = []


for p2 in target_pressure:
    eq_curves.append([])

    for lb, p1 in zip(log_beta, pressure):

        beta = 10**lb
        M1 = M_pl/beta                           # eV

        # Get alpha and field scale.
        alpha = alpha_calculator_chameleon(n, M1, Lambda_DE, p0=density_scale,
                                           L=length_scale,
                                           p0_NonEVUnits=density_unit,
                                           L_NonEVUnits=length_unit)

        M2 = M1*np.sqrt(p1/p2)
        Lambda2 = U*(alpha**0.4)/(M2**0.6)

        eq_curves[-1].append((M2, Lambda2))


# Plot equal pressure curve.
for eq_curve in eq_curves:
    X = np.array([np.log10(para[0]/M_pl) for para in eq_curve])
    Y = np.array([np.log10(para[1]) for para in eq_curve])

    ax4.plot(X, Y, color="blue", linestyle="solid")
