#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun  9 11:35:19 2026

@author: chad-briddon

Use SELCIE to compute the boundary values, and therefore the pressure on sensor
plate in the CANNEX experiment. Can use then plug the boundary values into
analytic equations to confirm them.

Here we vary the gap size so as to find the optimum for the constraint plot.

*This code ran using SELCIE v2.0.0.

"""

from _initalise import np, plt, exists
from _initalise import n, Lambda_DE, M_pl
from _initalise import Al, vac, Pt, W, Si, Cu, SiO2
from _initalise import density, length, density_scale, length_scale
from _initalise import eV4_to_pN_per_cm2, length_unit, density_unit

from Generate_Mesh import make_mesh
from SELCIE.Solvers import Chameleon
from SELCIE.Misc import alpha_calculator_chameleon


beta = 1e6
M = M_pl/beta                                # eV
VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV
C = VEV*density/M

alpha = alpha_calculator_chameleon(n, M, Lambda_DE, p0=density_scale,
                                   L=length_scale,
                                   p0_NonEVUnits=density_unit,
                                   L_NonEVUnits=length_unit)


data = np.array(
    [3e-6, 1.0090243035439571e-7, 0.1460309545942438,
     3.2393254869831290e-6, 7.239265226328643e-8, 0.09616859314745363,
     3.4977432035394953e-6, 5.209746816906757e-8, 0.06349530521313371,
     3.7767762353825017e-6, 3.7621239752447415e-8, 0.042019586220269085,
     4.078069172635577e-6, 2.7269371325070615e-8, 0.027869309141499744,
     4.403397802866208e-6, 1.9844415675605776e-8, 0.018537823604368068,
     4.75467957738334e-6, 1.4500629438501558e-8, 0.012390100958957337,
     5.133984912485342e-6, 1.0640432985348542e-8, 0.008310695867563316,
     5.543549392266874e-6, 7.841265225420004e-9, 0.005593909954110098,
     5.985786944906639e-6, 5.8041662741329425e-9, 0.003778709727083459,
     6.463304070095652e-6, 4.317030950792279e-9, 0.0025626667114744717,
     6.978915201460879e-6, 3.2285622400078267e-9, 0.0017421719563186385,
     7.5356592945287405e-6, 2.4302952229428766e-9, 0.0011868869083852226,
     8.136817737996086e-6, 1.8440416459804807e-9, 0.0008105980073851838,
     8.785933693875711e-6, 1.4131225908896254e-9, 0.0005550583770155003,
     9.48683298050514e-6, 1.0962063377936203e-9, 0.00038101006347565733,
     0.000010243646621500805, 8.630609800157395e-10, 0.00026241357648188666,
     0.000011060835193558726, 6.915208321023956e-10, 0.00018173194139536157,
     0.000011943215116604916, 5.653048957589605e-10, 0.00012673582724586214,
     0.000012895987041246831, 4.724342164544678e-10, 0.00008922231009587215,
     0.000013924766500838338, 4.040982505342441e-10, 0.00006364210902611688,
     0.000015035617008818167, 3.5381711990196174e-10, 0.00004624206234762901,
     0.00001623508579639391, 3.1682156319832695e-10, 0.000034367708044077834,
     0.00001753024240120553, 2.896008758111761e-10, 0.00002626631165599906,
     0.000018928720334405797, 2.695723725745567e-10, 0.000020744135766666874,
     0.000020438762071738836, 2.548365253796506e-10, 0.000016982308441742522,
     0.00002206926763378924, 2.439948096344934e-10, 0.00001441350587685605,
     0.000023829847041728447, 2.360181286785547e-10, 0.0000126593269871583,
     0.000025730876957726823, 2.3014949847032e-10, 0.000011462887868655936,
     0.000027783561843863803, 2.258321144046978e-10, 0.000010645558592928105])


'''
Note in paper "https://arxiv.org/pdf/2405.14638", Hauke uses 2*sigma as the
constraint. Above values are for 1*sigma, so must modify to get consistent
constraint.
'''

for i, di in enumerate(data):
    if i % 3 == 0:
        continue
    else:
        data[i] *= 2


# Rene's table.
gap_sizes = data[::3]*1e6                        # um
pressure_snc = data[1::3]*1e8                    # pN/cm^2


U = (length**0.8)*(density**0.6)  # a constant.


fig4, ax4 = plt.subplots(figsize=(8, 6))
ax4.set_ylabel(r"$Log \left( \frac{\Lambda}{eV} \right)$")
ax4.set_xlabel(r"$Log \left( \frac{M}{M_{PL}} \right)$")

ax4.set_ylim([-4, 1])
ax4.set_xlim([-18, 1])

ax4.axhline(y=np.log10(Lambda_DE))


' --------------------------------------------------------------------------- '
' ----------------------------- Setup functions ----------------------------- '
' --------------------------------------------------------------------------- '


def f_Al(x):
    return Al


def f_vacuum(x):
    return vac


def f_Pt(x):
    return Pt


def f_W(x):
    return W


def f_Si(x):
    return Si


def f_Cu(x):
    return Cu


def f_SiO2(x):
    return SiO2


lower_plate = [f_Pt, f_W, f_SiO2, f_Cu, f_Al]
gap = [f_vacuum]
sensor_plate = [f_Pt, f_W, f_Pt, f_W, f_Si, f_W, f_Pt, f_vacuum, f_Al]

density_profile = lower_plate + gap + sensor_plate


boundary_pos_lower_plate = [-13000.37, -8000.37, -6000.37, -0.37, -0.07]


' --------------------------------------------------------------------------- '
' ------------------------------ Run iteration ------------------------------ '
' --------------------------------------------------------------------------- '

path = "Data/field/Boundary Data(VaryGap)"
Y = []

for gap_size, target_pressure in zip(gap_sizes, pressure_snc):

    meshname = "CANNEX(%.3fum)" % gap_size

    boundary_pos_gap = [0, gap_size]

    boundary_pos_sensor_plate = [gap_size+0.07, gap_size+0.37, gap_size+0.39,
                                 gap_size+0.395, gap_size+100.395,
                                 gap_size+100.4, gap_size+100.42,
                                 gap_size+5100.42, gap_size+8100.42]

    boundary_pos = np.array(boundary_pos_lower_plate[1:] + boundary_pos_gap
                            + boundary_pos_sensor_plate[:-1])

    ' ------------- Solve for the field and either save or plot ------------- '

    name = path + "/%.3fum" % gap_size

    # Skip if needed.
    if exists(name) is False:
        print(name)
        make_mesh(meshname, gap_size)

        s = Chameleon(alpha, n, mesh_name=meshname, dimension=1,
                      symmetry="translation symmetry")

        s.solve_static(density_profiles=density_profile, tol_du=1e-8)

        # Record field values at boundaries.
        bv = [s.field(xi, 0) for xi in boundary_pos]
        with open(name, "w") as tf:
            tf.write(str(bv))

    else:
        # Retreive saved data.
        with open(name, "r") as txt_file:
            bv = np.array(eval(txt_file.read()))

    ' ------------ Use save boundary values to compute pressure ------------ '

    def calc_rescaled_pressure(boundary_values):
        boundary_values_sensor = np.array(boundary_values[5:-1])

        layer_density = [0] + [sp(0) for sp in sensor_plate[:-2]] + [0]

        p_diff = np.array([(p1 - p0) for p0, p1 in zip(layer_density[:-1],
                                                       layer_density[1:])])

        return abs(np.dot(boundary_values_sensor, p_diff))

    pressure = C*calc_rescaled_pressure(boundary_values=bv)

    # Rescale pressure from natural units to pN/cm^2.
    pressure = eV4_to_pN_per_cm2*np.array(pressure)

    ' ---------------- Make constraint plots using pressure ---------------- '

    M2 = M*np.sqrt(pressure/target_pressure)
    Lambda2 = U*(alpha**0.4)/(M2**0.6)

    ax4.plot(np.log10(M2/M_pl), np.log10(Lambda2), 'r.')

    Y.append(np.log10(Lambda2))

plt.show()


plt.figure()
plt.ylabel(r"$Log \left( \frac{\Lambda}{eV} \right)$")
plt.xlabel(r"$gap size$")

plt.plot(gap_sizes, Y)

y_min = min(Y)
gap_optimal = gap_sizes[Y == y_min]

plt.plot(gap_optimal, y_min, 'r.')

plt.show()

print("Optimal gap size is (um) :", gap_optimal)
# 20.438762071738836 um
# 2.548365253796506e-2 pN/cm^2
