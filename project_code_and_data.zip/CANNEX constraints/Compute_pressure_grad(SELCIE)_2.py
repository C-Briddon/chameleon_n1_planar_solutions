#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 29 15:40:33 2026

@author: chad-briddon

Use SELCIE to compute the boundary values, and therefore the pressure on sensor
plate in the CANNEX experiment. Can use then plug the boundary values into
analytic equations to confirm them.

Use analytic values as initial guesses and compute the pressure gradient.

This version tries different methods to calculate the pressure gradient as an
attempt to reduce numerical error.

*This code ran using SELCIE v2.0.0.

"""

from _initalise import np, plt, mkdir, exists
from _initalise import n, Lambda_DE, M_pl
from _initalise import density_Al, density_vac, density_Pt, density_W
from _initalise import density_Si, density_Cu, density_SiO2, density, length
from _initalise import eV4_to_pN_per_cm2, density_scale, length_scale
from _initalise import length_unit, density_unit

from SELCIE.Solvers import Chameleon
from SELCIE.Misc import alpha_calculator_chameleon


plt.rc('axes', labelsize=15)
plt.rc('legend', fontsize=15)

dis = 0.01

folder = "gradient(6)"
index = 1


' --------------------------------------------------------------------------- '


log_beta = list(np.round(np.linspace(-1.00, 6.0, 141), 4))


# Note converted second column to pN/cm^2 and third to pN/cm^2/um.
CANNEX_data0 = [
    (3.0000000000000000, 10.090243035439571000, 14.603095459424381),
    (3.2393254869831290,  7.239265226328643000,  9.616859314745363),
    (3.4977432035394953,  5.209746816906757000,  6.349530521313371),
    (3.7767762353825017,  3.762123975244741500,  4.2019586220269085),
    (4.0780691726355770,  2.726937132507061500,  2.7869309141499744),
    (4.4033978028662080,  1.984441567560577600,  1.8537823604368068),
    (4.7546795773833400,  1.450062943850155800,  1.2390100958957337),
    (5.1339849124853420,  1.064043298534854200,  0.8310695867563316),
    (5.5435493922668740,  0.784126522542000400,  0.5593909954110098),
    (5.9857869449066390,  0.580416627413294250,  0.3778709727083459),
    (6.4633040700956520,  0.431703095079227900,  0.25626667114744717),
    (6.9789152014608790,  0.322856224000782670,  0.17421719563186385),
    (7.5356592945287405,  0.243029522294287660,  0.11868869083852226),
    (8.1368177379960860,  0.184404164598048070,  0.08105980073851838),
    (8.7859336938757110,  0.141312259088962540,  0.05550583770155003),
    (9.4868329805051400,  0.109620633779362030,  0.038101006347565733),
    (10.243646621500805,  0.086306098001573950,  0.026241357648188666),
    (11.060835193558726,  0.069152083210239560,  0.018173194139536157),
    (11.943215116604916,  0.056530489575896050,  0.012673582724586214),
    (12.895987041246831,  0.047243421645446780,  0.008922231009587215),
    (13.924766500838338,  0.040409825053424410,  0.006364210902611688),
    (15.035617008818167,  0.035381711990196174,  0.004624206234762901),
    (16.235085796393910,  0.031682156319832695,  0.0034367708044077834),
    (17.530242401205530,  0.028960087581117610,  0.002626631165599906),
    (18.928720334405797,  0.026957237257455670,  0.0020744135766666874),
    (20.438762071738836,  0.025483652537965060,  0.0016982308441742522),
    (22.069267633789240,  0.024399480963449340,  0.001441350587685605),
    (23.829847041728447,  0.023601812867855470,  0.00126593269871583),
    (25.730876957726823,  0.023014949847032000,  0.0011462887868655936),
    (27.783561843863803,  0.022583211440469780,  0.0010645558592928105)][:1]


'''
Note in paper "https://arxiv.org/pdf/2405.14638", Hauke uses 2*sigma as the
constraint. Above values are for 1*sigma, so must modify to get consistent
constraint.
'''
CANNEX_data = [(cd[0], 2*cd[1], 2*cd[2]) for cd in CANNEX_data0]


' --------------------------------------------------------------------------- '
' ----------- Make function to directly measure pressure gradient ----------- '
' --------------------------------------------------------------------------- '


def calc_rescaled_pressure_gradient_V0(name, plate_profile, gap_size,
                                       displacement):

    # Define effective density and difference vector.
    Pv = [0] + plate_profile + [0]
    p_diff = np.array([(p1 - p0) for p0, p1 in zip(Pv[:-1], Pv[1:])])

    # Load boundary values.
    with open("Data/" + folder + "/Boundary Data(_%.3fum)(-%.3fum)(%i)/%s"
              % (gap_size, displacement, index, name), "r") as txt_file:
        bv_neg = np.array(eval(txt_file.read())[5:13])
        P_neg = np.dot(p_diff, bv_neg)

    with open("Data/" + folder + "/Boundary Data(_%.3fum)(%.3fum)(%i)/%s"
              % (gap_size, displacement, index, name), "r") as txt_file:
        bv_pos = np.array(eval(txt_file.read())[5:13])
        P_pos = np.dot(p_diff, bv_pos)

    # Take derivative of field.
    DP = (P_pos - P_neg)/(2*displacement)

    return abs(DP)


def calc_rescaled_pressure_gradient_V1(name, plate_profile, gap_size,
                                       displacement):

    # Load boundary values.
    with open("Data/" + folder + "/Boundary Data(_%.3fum)(-%.3fum)(%i)/%s"
              % (gap_size, displacement, index, name), "r") as txt_file:
        bv_neg = np.array(eval(txt_file.read())[5:13])

    with open("Data/" + folder + "/Boundary Data(_%.3fum)(%.3fum)(%i)/%s"
              % (gap_size, displacement, index, name), "r") as txt_file:
        bv_pos = np.array(eval(txt_file.read())[5:13])

    # Take derivative of field.
    D_bv = (bv_pos - bv_neg)/(2*displacement)

    # Define effective density and difference vector.
    Pv = [0] + plate_profile + [0]
    p_diff = np.array([(p1 - p0) for p0, p1 in zip(Pv[:-1], Pv[1:])])

    return abs(np.dot(D_bv, p_diff))


def calc_rescaled_pressure_gradient_V2(name, gap_size, displacement):
    'Book 15 - Pg 12'

    P_vac = density_vac/density_scale

    # Load boundary values.
    with open("Data/" + folder + "/Boundary Data(_%.3fum)(-%.3fum)(%i)/%s"
              % (gap_size, displacement, index, name), "r") as txt_file:
        data = eval(txt_file.read())

        bv_neg = np.array(data[5:13])
        Df_neg = bv_neg[0] - bv_neg[-1]

        field_max_L_neg = data[14][0]
        field_max_R_neg = data[14][1]
        Z_neg = (1/field_max_R_neg) - (1/field_max_L_neg)

    with open("Data/" + folder + "/Boundary Data(_%.3fum)(%.3fum)(%i)/%s"
              % (gap_size, displacement, index, name), "r") as txt_file:
        data = eval(txt_file.read())

        bv_pos = np.array(data[5:13])
        Df_pos = bv_pos[0] - bv_pos[-1]

        field_max_L_pos = data[14][0]
        field_max_R_pos = data[14][1]
        Z_pos = (1/field_max_R_pos) - (1/field_max_L_pos)

    # Take derivative.
    Df = (Df_pos - Df_neg)/(2*displacement)
    DZ = (Z_pos - Z_neg)/(2*displacement)

    return P_vac*Df + DZ


def calc_rescaled_pressure_gradient_V3(name, gap_size, displacement, alpha):
    'Book 15 - Pg 10'

    # Load boundary values.
    with open("Data/" + folder + "/Boundary Data(_%.3fum)(-%.3fum)(%i)/%s"
              % (gap_size, displacement, index, name), "r") as txt_file:
        data = eval(txt_file.read())

        field_L_neg, field_R_neg = data[5], data[12]
        grad_L_neg, grad_R_neg = data[14][2], data[14][3]

        P_L_neg = 0.5*alpha*grad_L_neg**2 - (1/field_L_neg)
        P_R_neg = 0.5*alpha*grad_R_neg**2 - (1/field_R_neg)

        P_neg = P_L_neg - P_R_neg

    with open("Data/" + folder + "/Boundary Data(_%.3fum)(%.3fum)(2)/%s"
              % (gap_size, displacement, name), "r") as txt_file:
        data = eval(txt_file.read())

        field_L_pos, field_R_pos = data[5], data[12]
        grad_L_pos, grad_R_pos = data[14][2], data[14][3]

        P_L_pos = 0.5*grad_L_pos**2 - (1/field_L_pos)
        P_R_pos = 0.5*grad_R_pos**2 - (1/field_R_pos)

        P_pos = P_L_pos - P_R_pos

    return (P_pos - P_neg)/(2*displacement)


def calc_rescaled_pressure_gradient_V4(name, gap_size, displacement):
    'Book 15 - Pg 12. Akward since need undisplaced values also.'

    P_vac = density_vac/density_scale

    # Load boundary values.
    with open("Data/" + folder + "/Boundary Data(_%.3fum)(0.000um)(1)/%s"
              % (gap_size, name), "r") as txt_file:
        data = eval(txt_file.read())
        field_max_L = data[14][0]
        field_max_R = data[14][1]

    with open("Data/" + folder + "/Boundary Data(_%.3fum)(-%.3fum)(1)/%s"
              % (gap_size, displacement, name), "r") as txt_file:
        data = eval(txt_file.read())

        bv_neg = np.array(data[5:13])
        D_neg = bv_neg[0] - bv_neg[-1]

        field_max_L_neg = data[14][0]
        field_max_R_neg = data[14][1]

    with open("Data/" + folder + "/Boundary Data(_%.3fum)(%.3fum)(1)/%s"
              % (gap_size, displacement, name), "r") as txt_file:
        data = eval(txt_file.read())

        bv_pos = np.array(data[5:13])
        D_pos = bv_pos[0] - bv_pos[-1]

        field_max_L_pos = data[14][0]
        field_max_R_pos = data[14][1]

    # Take derivative.
    dD = (D_pos - D_neg)/(2*displacement)
    df_L0 = (field_max_L_pos - field_max_L_neg)/(2*displacement)
    df_R0 = (field_max_R_pos - field_max_R_neg)/(2*displacement)

    return P_vac*dD + (df_L0/field_max_L**2) - (df_R0/field_max_R**2)


' -------------------------------------------------------------------------- '
' ------- Make function to check if boundary constraint is satisfied ------- '
' -------------------------------------------------------------------------- '


def check_boundary_constraint(name, plate_profile, gap_size, displacement):
    'Book 14 - Pg 37'

    # Define effective density and difference vector.
    Pv = [0] + plate_profile + [0]
    p_diff = np.array([(p1 - p0) for p0, p1 in zip(Pv[:-1], Pv[1:])])
    p_diff[0] *= 2
    p_diff[-1] *= 2

    # Load boundary values.
    with open("Data/" + folder + "/Boundary Data(_%.3fum)(-%.3fum)(%i)/%s"
              % (gap_size, displacement, index, name), "r") as txt_file:
        bv_neg = np.array(eval(txt_file.read())[:14])
        Res_neg = np.dot(p_diff, bv_neg)

    with open("Data/" + folder + "/Boundary Data(_%.3fum)(%.3fum)(%i)/%s"
              % (gap_size, displacement, index, name), "r") as txt_file:
        bv_pos = np.array(eval(txt_file.read())[:14])
        Res_pos = np.dot(p_diff, bv_pos)

    return np.array([Res_neg, Res_pos])


' -------------------------------------------------------------------------- '
' -------------------- Physical dimensionful parameters -------------------- '
' -------------------------------------------------------------------------- '

# Rescale densities.

rescaled_density_Al = density_Al / density_scale
rescaled_density_vac = density_vac / density_scale
rescaled_density_Pt = density_Pt / density_scale
rescaled_density_W = density_W / density_scale
rescaled_density_Si = density_Si / density_scale
rescaled_density_Cu = density_Cu / density_scale
rescaled_density_SiO2 = density_SiO2 / density_scale


' --------------------------------------------------------------------------- '
' ----------------------------- Setup functions ----------------------------- '
' --------------------------------------------------------------------------- '


def Al(x):
    return rescaled_density_Al


def vacuum(x):
    return rescaled_density_vac


def Pt(x):
    return rescaled_density_Pt


def W(x):
    return rescaled_density_W


def Si(x):
    return rescaled_density_Si


def Cu(x):
    return rescaled_density_Cu


def SiO2(x):
    return rescaled_density_SiO2


lower_plate = [Pt, W, SiO2, Cu, Al]
gap = [vacuum]
sensor_plate = [Pt, W, Pt, W, Si, W, Pt, vacuum, Al]

density_profile = lower_plate + gap + sensor_plate

sensor_plate_values = [f(0) for f in sensor_plate[:-2]]
densities = np.array([f(0) for f in density_profile])


' --------------------------------------------------------------------------- '
' --------------- Solve for the field and either save or plot --------------- '
' --------------------------------------------------------------------------- '

# Position of boundaries in um.
boundary_pos_lower_plate = [-13000.37, -8000.37, -6000.37, -0.37, -0.07]
sensor_plate_layer_thickness = [0.07, 0.3, 0.02, 5e-3, 100, 5e-3, 0.02,
                                5e3, 3e3]

sensor_plate_boundary_pos = np.round(
    [sum(sensor_plate_layer_thickness[:i+1])
     for i in range(len(sensor_plate_layer_thickness))], 5)


dis_vector = np.zeros(14)
dis_vector[5:-1] = 1

for gap_size, _, _ in CANNEX_data:

    # Make un-displaced boundary position list.
    boundary_pos_gap0 = [0, gap_size]
    boundary_pos_sensor_plate0 = list(sensor_plate_boundary_pos + gap_size)
    boundary_pos0 = np.array(boundary_pos_lower_plate[1:]
                             + boundary_pos_gap0
                             + boundary_pos_sensor_plate0[:-1])

    for displacement in [-dis, dis]:

        path = "Data/" + folder + "/Boundary Data(_%.3fum)(%.3fum)(%i)" % (
            gap_size, displacement, index)
        meshname = "CANNEX(%.3fum)(%.3fum)" % (gap_size, displacement)

        if exists(path):
            pass
        else:
            mkdir(path)

        # Define new boundary positions (with displacement).
        boundary_pos = boundary_pos0 + displacement*dis_vector

        # Define arrays used to find k's in vacuum regions.
        X_vac_L = np.linspace(boundary_pos[4], boundary_pos[5], 100001)
        X_vac_R = np.linspace(boundary_pos[12], boundary_pos[13], 100001)

        # Iterate over beta parameter.
        for lb in log_beta:

            name = path + "/LogB%.3f" % lb

            # Skip if needed.
            if len(log_beta) > 1 and exists(name) is True:
                continue

            print(name)

            beta = 10**lb
            M = M_pl/beta                                # eV
            VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

            # Get alpha and field scale.
            alpha = alpha_calculator_chameleon(
                n, M, Lambda_DE, p0=density_scale, L=length_scale,
                p0_NonEVUnits=density_unit, L_NonEVUnits=length_unit)

            s = Chameleon(alpha, n, mesh_name=meshname, dimension=1,
                          symmetry="translation symmetry", deg_V=3)

            s.solve_static(density_profiles=density_profile, maxiter=100,
                           tol_du=5e-8)

            # Record field values at boundaries and vacuum k's.
            field_max_L = max([s.field(xi, 0) for xi in X_vac_L])
            field_max_R = max([s.field(xi, 0) for xi in X_vac_R])

            # Save gradients at sensor boundaries.
            s.calc_field_grad_vector()
            grad_L = s.field_grad(boundary_pos[5], 0)[0]
            grad_R = s.field_grad(boundary_pos[12], 0)[0]

            with open(name, "w") as tf:
                tf.write(str([s.field(xi, 0) for xi in boundary_pos]
                             + [(field_max_L, field_max_R, grad_L, grad_R)]))


' --------------------------------------------------------------------------- '
' --------------------- Use saved data to generate plot --------------------- '
' --------------------------------------------------------------------------- '

for gap_size, target_pressure, target_pressure_grad in CANNEX_data:

    pressure_grad_0 = []
    pressure_grad_1, pressure_grad_2, pressure_grad_3 = [], [], []

    for lb in log_beta:

        name = "LogB%.3f" % lb

        beta = 10**lb
        M = M_pl/beta                                # eV
        VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

        alpha = alpha_calculator_chameleon(
            n, M, Lambda_DE, p0=density_scale, L=length_scale,
            p0_NonEVUnits=density_unit, L_NonEVUnits=length_unit)

        C = eV4_to_pN_per_cm2*VEV*density/M

        Y0 = calc_rescaled_pressure_gradient_V0(name, sensor_plate_values,
                                                gap_size, dis)

        Y1 = calc_rescaled_pressure_gradient_V1(name, sensor_plate_values,
                                                gap_size, dis)

        Y2 = calc_rescaled_pressure_gradient_V2(name, gap_size, dis)
        Y3 = calc_rescaled_pressure_gradient_V3(name, gap_size, dis, alpha)

        pressure_grad_0.append(C*Y0)
        pressure_grad_1.append(C*Y1)
        pressure_grad_2.append(C*Y2)
        pressure_grad_3.append(C*Y3)

        print(C*check_boundary_constraint(name, densities, gap_size, dis))

    if False:
        # Plot pressure gradient against beta (Lambda is fixed).
        fig3, ax3 = plt.subplots(figsize=(8, 6))
        # ax3.set_ylabel(r"$| \partial p_z|/\left( pN/cm^{-2}/\mu m \right)$")
        ax3.set_xlabel(r"$Log(\beta)$")

        ax3.plot(log_beta, pressure_grad_0, label="pressure grad_v0")
        ax3.plot(log_beta, pressure_grad_1, label="pressure grad_v1")
        ax3.plot(log_beta, pressure_grad_2, label="pressure grad_v2")
        ax3.plot(log_beta, pressure_grad_3, label="pressure grad_v3")

        ax3.legend()

    ' ------------------------------------------------------------------ '
    ' -------------- Make constraint plots using pressure -------------- '
    ' ------------------------------------------------------------------ '

    if True:
        U = (length**0.8)*(density**0.6)  # a constant.

        fig4, ax4 = plt.subplots(figsize=(8, 6))
        ax4.set_ylabel(r"$Log \left( \frac{\Lambda}{eV} \right)$")
        ax4.set_xlabel(r"$Log \left( \frac{M}{M_{PL}} \right)$")

        # ax4.set_ylim([-4, 1])
        # ax4.set_xlim([-18, 1])

        ax4.set_ylim([-1.5, 1])
        ax4.set_xlim([-9, -3])

        ax4.axhline(y=np.log10(Lambda_DE))

        eq_curve, eq_curve_grad_0, eq_curve_grad_1 = [], [], []
        eq_curve_grad_2, eq_curve_grad_3 = [], []

        for lb, p1_grad_0, p1_grad_1, p1_grad_2, p1_grad_3 in zip(
                log_beta, pressure_grad_1, pressure_grad_1,
                pressure_grad_2, pressure_grad_3):

            beta = 10**lb
            M1 = M_pl/beta                           # eV

            # Get alpha and field scale.
            alpha = alpha_calculator_chameleon(
                n, M1, Lambda_DE, p0=density_scale, L=length_scale,
                p0_NonEVUnits=density_unit, L_NonEVUnits=length_unit)

            M2_grad_0 = M1*np.sqrt(abs(p1_grad_0)/target_pressure_grad)
            Lambda2_grad_0 = U*(alpha**0.4)/(M2_grad_0**0.6)
            eq_curve_grad_0.append((M2_grad_0, Lambda2_grad_0))

            M2_grad_1 = M1*np.sqrt(abs(p1_grad_1)/target_pressure_grad)
            Lambda2_grad_1 = U*(alpha**0.4)/(M2_grad_1**0.6)
            eq_curve_grad_1.append((M2_grad_1, Lambda2_grad_1))

            M2_grad_2 = M1*np.sqrt(abs(p1_grad_2)/target_pressure_grad)
            Lambda2_grad_2 = U*(alpha**0.4)/(M2_grad_2**0.6)
            eq_curve_grad_2.append((M2_grad_2, Lambda2_grad_2))

            M2_grad_3 = M1*np.sqrt(abs(p1_grad_3)/target_pressure_grad)
            Lambda2_grad_3 = U*(alpha**0.4)/(M2_grad_3**0.6)
            eq_curve_grad_3.append((M2_grad_3, Lambda2_grad_3))

        # Plot equal pressure grad curve.
        X0 = np.array([np.log10(para[0]/M_pl) for para in eq_curve_grad_0])
        Y0 = np.array([np.log10(para[1]) for para in eq_curve_grad_0])

        X1 = np.array([np.log10(para[0]/M_pl) for para in eq_curve_grad_1])
        Y1 = np.array([np.log10(para[1]) for para in eq_curve_grad_1])

        X2 = np.array([np.log10(para[0]/M_pl) for para in eq_curve_grad_2])
        Y2 = np.array([np.log10(para[1]) for para in eq_curve_grad_2])

        X3 = np.array([np.log10(para[0]/M_pl) for para in eq_curve_grad_3])
        Y3 = np.array([np.log10(para[1]) for para in eq_curve_grad_3])

        ax4.plot(X0, Y0, color="blue", linestyle="solid", label="V0")
        ax4.plot(X1, Y1, color="red", linestyle="dashed", label="V1")
        ax4.plot(X2, Y2, color="blue", linestyle="dashed", label="V2")
        ax4.plot(X2, Y2, color="green", linestyle="dashdot", label="V3")

        ' Add line showing when Compton wavelength in sheild is 10% its width '

        Comp_SheildL_ratio = 0.1
        SheildL = 3000  # um
        Comp_um = Comp_SheildL_ratio*SheildL

        Comp_eV = Comp_um*length
        density_AL_eV = Al(0)*density

        constant = 4*(Comp_eV**4)*(density_AL_eV**3)/(M_pl**3)

        beta = (constant/(Lambda_DE**5))**(-1/3)
        # print(np.log10(beta))

        C = 0.2*np.log10(constant)

        log_M = np.linspace(-10, 2, 801)
        log_Lam = C - 0.6*log_M

        M = 10**log_M
        Lam = 10**log_Lam

        ax4.plot(log_M, log_Lam, color="black", linestyle="solid")

        ax4.legend()

    ' ---------------------------------------------------------------------- '
    ' ------------- Calculate Compton wavelength inside sheild ------------- '
    ' ---------------------------------------------------------------------- '

    beta = 10**min(log_beta)
    beta = 10**(-0.5)
    M = M_pl/beta                               # eV

    alpha = alpha_calculator_chameleon(n, M, Lambda_DE, p0=rescaled_density_Al,
                                       L=1000,
                                       p0_NonEVUnits=density_unit,
                                       L_NonEVUnits=length_unit)

    Comp_mm = np.sqrt(alpha/2)

    ratio_Sheild_Comp_L = Comp_mm/3.0

    print(ratio_Sheild_Comp_L)
