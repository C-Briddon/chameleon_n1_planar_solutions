#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Sep 15 12:50:08 2026

@author: chad-briddon

Use analytic solution to compute pressure gradient on sensor plate in the
CANNEX experiment.

Boundary value data saved to :
    Using SELCIE                                - (1)
    Analytic using above for initial guess      - (2)
    Analytic using default initial guess        - (3)
    Analytic using last solution as new guess   - (4)

"""

from _initalise import np, plt, mkdir, exists, n, Lambda_DE, M_pl, Al, vac, Pt
from _initalise import W, Si, Cu, SiO2, density, length
from _initalise import density_unit, length_unit, density_scale, length_scale
from _initalise import eV4_to_pN_per_cm2, kg_per_m3_2_eV4, units

from chameleon_n1_planar_solutions.solutions import planar_solution

from SELCIE.Misc import alpha_calculator_chameleon  # v2.0.0
from timeit import default_timer


plt.rc('axes', labelsize=15)
plt.rc('legend', fontsize=15)

dis = 0.01


' --------------------------------------------------------------------------- '


log_beta0 = list(np.round(np.linspace(-1.0, 6.0, 141), 4))
log_beta1 = list(np.round(np.linspace(-1.0, 6.0, 141), 4))[10:]


i = 25
# Note converted second column to pN/cm^2 and third to pN/cm^2/um.
CANNEX_data0 = [
    (3.0000000000000000, 10.090243035439571000, 14.603095459424381),
    (3.2393254869831290,  7.239265226328643000,  9.616859314745363),
    (3.4977432035394953,  5.209746816906757000,  6.349530521313371),
    (3.7767762353825017,  3.762123975244741500,  4.2019586220269085),
    (4.0780691726355770,  2.726937132507061500,  2.7869309141499744),
    (4.4033978028662080,  1.984441567560577600,  1.8537823604368068),
    (4.7546795773833400,  1.450062943850155800,  1.2390100958957337),
    (5.1339849124853420,  1.064043298534854200,  0.8310695867563316),
    (5.5435493922668740,  0.784126522542000400,  0.5593909954110098),
    (5.9857869449066390,  0.580416627413294250,  0.3778709727083459),
    (6.4633040700956520,  0.431703095079227900,  0.25626667114744717),
    (6.9789152014608790,  0.322856224000782670,  0.17421719563186385),
    (7.5356592945287405,  0.243029522294287660,  0.11868869083852226),
    (8.1368177379960860,  0.184404164598048070,  0.08105980073851838),
    (8.7859336938757110,  0.141312259088962540,  0.05550583770155003),
    (9.4868329805051400,  0.109620633779362030,  0.038101006347565733),
    (10.243646621500805,  0.086306098001573950,  0.026241357648188666),
    (11.060835193558726,  0.069152083210239560,  0.018173194139536157),
    (11.943215116604916,  0.056530489575896050,  0.012673582724586214),
    (12.895987041246831,  0.047243421645446780,  0.008922231009587215),
    (13.924766500838338,  0.040409825053424410,  0.006364210902611688),
    (15.035617008818167,  0.035381711990196174,  0.004624206234762901),
    (16.235085796393910,  0.031682156319832695,  0.0034367708044077834),
    (17.530242401205530,  0.028960087581117610,  0.002626631165599906),
    (18.928720334405797,  0.026957237257455670,  0.0020744135766666874),
    (20.438762071738836,  0.025483652537965060,  0.0016982308441742522),
    (22.069267633789240,  0.024399480963449340,  0.001441350587685605),
    (23.829847041728447,  0.023601812867855470,  0.00126593269871583),
    (25.730876957726823,  0.023014949847032000,  0.0011462887868655936),
    (27.783561843863803,  0.022583211440469780,  0.0010645558592928105)][i:i+1]


'''
Note in paper "https://arxiv.org/pdf/2405.14638", Hauke uses 2*sigma as the
constraint. Above values are for 1*sigma, so must modify to get consistent
constraint.
'''
CANNEX_data = [(cd[0], 2*cd[1], 2*cd[2]) for cd in CANNEX_data0]


' ---------------------- Define densities of materials ---------------------- '

# Assign correct density to each layer ('left --> right' == 'bottom --> top').
lower_plate = [Al, Cu, SiO2, W, Pt]
gap = [vac]
sensor_plate = [Pt, W, Pt, W, Si, W, Pt, vac, Al]

density_profile = np.array(lower_plate + gap + sensor_plate)


# Convert densites to natural units.
density_profile *= density_unit.to(units.kg*units.m**(-3))*kg_per_m3_2_eV4


' --------------------------------------------------------------------------- '
' --------------- Solve for the field and either save or plot --------------- '
' --------------------------------------------------------------------------- '

# Position of boundaries in um.
boundary_pos_lower_plate = [-13000.37, -8000.37, -6000.37, -0.37, -0.07]
sensor_plate_layer_thickness = [0.07, 0.3, 0.02, 5e-3, 100, 5e-3, 0.02,
                                5e3, 3e3]

sensor_plate_boundary_pos = np.round(
    [sum(sensor_plate_layer_thickness[:i+1])
     for i in range(len(sensor_plate_layer_thickness))], 5)


dis_vector = np.zeros(14)
dis_vector[5:] = 1


for gap_size, target_pressure, target_pressure_grad in CANNEX_data:

    # Make un-displaced boundary position list.
    boundary_pos_gap0 = [0, gap_size]
    boundary_pos_sensor_plate0 = list(sensor_plate_boundary_pos + gap_size)
    boundary_pos0 = np.array(boundary_pos_lower_plate[1:] + boundary_pos_gap0
                             + boundary_pos_sensor_plate0[:-1])

    pressure_dis = []

    for displacement in [-dis, dis]:

        # path0 = "Data/gradient/Boundary Data(_%.3fum)(%.3fum)(1)" % (
        #     gap_size, displacement)
        path0 = "Data/field/Boundary Data(_%.3fum)(1)" % gap_size

        path = "Data/gradient/Boundary Data(_%.3fum)(%.3fum)(4)" % (
            gap_size, displacement)

        if exists(path):
            pass
        else:
            mkdir(path)

        ' -------------------- Assign boundary locations -------------------- '

        # Define new boundary positions (with displacement).
        boundary_pos = boundary_pos0 + displacement*dis_vector
        print(boundary_pos)

        ' --------------------- Solve for field profile --------------------- '

        # For (4). Rescale guess by sqrt(M_new/M_old).
        boundary_guess_hold = None

        # Choose initial guess.
        boundary_guess = []
        boundary_guess = None

        if False:
            # Load a specific initial guess.
            with open(
                    "Data/gradient/Boundary Data(_%.3fum)(%.3fum)(2)/LogB4.750"
                    % (gap_size, displacement), "r") as txt_file:
                boundary_guess = np.array(eval(txt_file.read()))

        # Iterate over beta parameter.
        for lb in reversed(log_beta1):

            name0 = path0 + "/LogB%.3f" % lb
            name = path + "/LogB%.3f" % lb

            beta = 10**lb
            M = M_pl/beta                                # eV
            VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

            # Skip if needed.
            if len(log_beta1) > 1 and exists(name) is True:
                with open(name, "r") as txt_file:
                    boundary_guess = np.array(eval(txt_file.read()))
                    boundary_guess_hold = boundary_guess/np.sqrt(M)
                continue

            print(name)

            # Load solution from saved SELCIE data.
            if path[-2] == "2":
                with open(name0, "r") as txt_file:
                    boundary_guess = np.array(eval(txt_file.read()))*VEV

            elif path[-2] == "3":
                boundary_guess = None

            elif path[-2] == "4":
                if boundary_guess_hold is None:
                    pass
                else:
                    boundary_guess = boundary_guess_hold*np.sqrt(M)

            # Solve for field profile.
            t0 = default_timer()
            func, boundary_values, _ = planar_solution(
                Lambda_DE, M, densities=density_profile,
                boundary_positions=boundary_pos, boundary_guess=boundary_guess,
                density_NonEVUnits=None, length_NonEVUnits=length_unit,
                use_boundary_guess=False)

            t1 = default_timer()
            print("Time is :", t1-t0)

            print(boundary_guess)
            print(boundary_values)
            print()

            boundary_guess = boundary_values
            boundary_guess_hold = boundary_guess/np.sqrt(M)

            ' -------------- Record field values at boundaries -------------- '
            with open(name, "w") as tf:
                tf.write(str(list(boundary_values)))

        continue
        ' ------------------------------------------------------------------ '
        ' ---------- Use save boundary values to compute pressure ---------- '
        ' ------------------------------------------------------------------ '

        def calc_rescaled_pressure(boundary_values):
            boundary_values_sensor = np.array(boundary_values[5:-1])

            layer_density = [0] + [sp for sp in sensor_plate[:-2]] + [0]

            p_diff = np.array([(p1 - p0) for p0, p1 in zip(layer_density[:-1],
                                                           layer_density[1:])])

            return abs(np.dot(boundary_values_sensor, p_diff))

        # Make plot for fixed Lambda value.
        pressure0 = []
        pressure = []

        for lb in log_beta1:

            name = path + "/LogB%.3f" % lb

            beta = 10**lb
            M = M_pl/beta                                # eV

            C = density/M

            with open(name, "r") as txt_file:
                bv = np.array(eval(txt_file.read()))

            pressure.append(
                eV4_to_pN_per_cm2*C*calc_rescaled_pressure(boundary_values=bv))

        for lb in log_beta0:

            name0 = path0 + "/LogB%.3f" % lb

            beta = 10**lb
            M = M_pl/beta                                # eV
            VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

            C = VEV*density/M

            with open(name0, "r") as txt_file:
                bv0 = np.array(eval(txt_file.read()))

            pressure0.append(eV4_to_pN_per_cm2*C*calc_rescaled_pressure(
                boundary_values=bv0))

        # Plot pressure against beta (Lambda is fixed).
        fig3, ax3 = plt.subplots(figsize=(8, 6))
        fig3.suptitle("d = %f" % gap_size)
        ax3.set_ylabel(r"$|p_z| / \left( pN/cm^{-2} \right)$")
        ax3.set_xlabel(r"$Log(\beta)$")

        ax3.plot(log_beta0, pressure0, label="Numeric", linestyle="solid")
        ax3.plot(log_beta1, pressure, label="Analytic", linestyle="dashed")

        fig3.legend()

        # Save to calculate gradient.
        pressure_dis.append(np.array(pressure))

    continue

    # Calculate gradient.
    pressure_grad = (pressure_dis[1] - pressure_dis[0])/(2*dis)

    ' ------------------------------------------------------------------ '
    ' -------------- Make constraint plots using pressure -------------- '
    ' ------------------------------------------------------------------ '

    if True:
        U = (length**0.8)*(density**0.6)  # a constant.

        fig4, ax4 = plt.subplots(figsize=(8, 6))
        ax4.set_ylabel(r"$Log \left( \frac{\Lambda}{eV} \right)$")
        ax4.set_xlabel(r"$Log \left( \frac{M}{M_{PL}} \right)$")

        ax4.set_ylim([-4, 1])
        ax4.set_xlim([-18, 1])

        ax4.axhline(y=np.log10(Lambda_DE))

        eq_curve, eq_curve_grad = [], []
        for lb, p1, p1_grad in zip(log_beta1, pressure, pressure_grad):

            beta = 10**lb
            M1 = M_pl/beta                           # eV

            # Get alpha and field scale.
            alpha = alpha_calculator_chameleon(
                n, M1, Lambda_DE, p0=density_scale, L=length_scale,
                p0_NonEVUnits=density_unit, L_NonEVUnits=length_unit)

            M2 = M1*np.sqrt(p1/target_pressure)
            M2_grad = M1*np.sqrt(abs(p1_grad)/target_pressure_grad)

            Lambda2 = U*(alpha**0.4)/(M2**0.6)
            Lambda2_grad = U*(alpha**0.4)/(M2_grad**0.6)

            eq_curve.append((M2, Lambda2))
            eq_curve_grad.append((M2_grad, Lambda2_grad))

        # Plot equal pressure curve.
        X = np.array([np.log10(para[0]/M_pl) for para in eq_curve])
        Y = np.array([np.log10(para[1]) for para in eq_curve])

        ax4.plot(X, Y, color="blue", linestyle="solid", label="pressue")

        X = np.array([np.log10(para[0]/M_pl) for para in eq_curve_grad])
        Y = np.array([np.log10(para[1]) for para in eq_curve_grad])

        ax4.plot(X, Y, color="red", linestyle="solid", label="pressue grad")

        ' Add line showing when Compton wavelength in sheild is 10% its width '

        Comp_SheildL_ratio = 0.1
        SheildL = 3000  # um
        Comp_um = Comp_SheildL_ratio*SheildL

        Comp_eV = Comp_um*length
        density_AL_eV = Al*density

        constant = 4*(Comp_eV**4)*(density_AL_eV**3)/(M_pl**3)

        beta = (constant/(Lambda_DE**5))**(-1/3)
        # print(np.log10(beta))

        C = 0.2*np.log10(constant)

        log_M = np.linspace(-10, 2, 801)
        log_Lam = C - 0.6*log_M

        M = 10**log_M
        Lam = 10**log_Lam

        ax4.plot(log_M, log_Lam, color="black", linestyle="solid")

        ax4.legend()

    ' ---------------------------------------------------------------------- '
    ' ------------- Calculate Compton wavelength inside sheild ------------- '
    ' ---------------------------------------------------------------------- '

    beta = 10**min(log_beta1)
    beta = 10**(-0.5)
    M = M_pl/beta                               # eV

    alpha = alpha_calculator_chameleon(n, M, Lambda_DE, p0=Al, L=1000,
                                       p0_NonEVUnits=density_unit,
                                       L_NonEVUnits=length_unit)

    Comp_mm = np.sqrt(alpha/2)

    ratio_Sheild_Comp_L = Comp_mm/3.0

    print(ratio_Sheild_Comp_L)
