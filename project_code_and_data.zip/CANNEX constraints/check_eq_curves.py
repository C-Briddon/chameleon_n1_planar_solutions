#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May 14 18:21:53 2026

@author: chad-briddon

Check that the parameter space curves predicted to give equal pressure do.

*This code ran using SELCIE v2.0.0.

"""

import numpy as np
import matplotlib.pyplot as plt

from SELCIE.Solvers import Chameleon
from SELCIE.Misc import alpha_calculator_chameleon, units, constants

plt.rc('axes', labelsize=15)
plt.rc('legend', fontsize=15)


# Beta. Single value gives plot, and multiple saves boundary values.
# p = 1e-2
parameters = [(2.4114899055733034e+26, 0.02527294609917007),
              (9.475481069144927e+25, 0.011119016613838772),
              (1.8469873398639266e+25, 0.007449871622326509),
              (2.231119101056792e+24, 0.006651406454470609),
              (2.3082915410894725e+23, 0.006517075376502748),
              (2.3123578775161857e+22, 0.006510196696699319),
              (2.2265365025704682e+21, 0.006659616925817538)]
# p = 1e-3
parameters = [(7.625800656116013e+26, 0.01266647794105421),
              (2.9964102104305395e+26, 0.005572709177345535),
              (5.840686803465516e+25, 0.0037337805492721433),
              (7.055418090446851e+24, 0.003333600000646708),
              (7.299458773542879e+23, 0.0032662749792898267),
              (7.312317658383803e+22, 0.0032628274727881383),
              (7.040926641628027e+21, 0.003337714984067852)]
# p = 1e-4
parameters = [(2.4114899055733037e+27, 0.006348277039077827),
              (9.475481069144927e+26, 0.0027929706964031215),
              (1.8469873398639266e+26, 0.0018713231444610224),
              (2.231119101056792e+25, 0.0016707577623439967),
              (2.308291541089472e+24, 0.0016370153211362445),
              (2.3123578775161858e+23, 0.001635287474889751),
              (2.226536502570468e+22, 0.0016728201395012619)]
'''

alpha = alpha_calculator_chameleon(n=1, M=1.22e26, Lam=2.4e-3, p0=1, L=1,
                                   p0_NonEVUnits=units.g/units.cm**3,
                                   L_NonEVUnits=units.um)
'''


' -------------------------------------------------------------------------- '
' ----------- Choose physical scales, other parameters, and mesh ----------- '
' -------------------------------------------------------------------------- '

n = 1

density_scale = 1.0                              # g/cm^3
length_scale = 1                                 # um

M_pl = 1.22e28                                   # eV


meshname = "CANNEX(MovingSensor)"


' -------------------- Convert density and length to eV -------------------- '

# Density.
kg_per_m3_2_eV4 = (constants.hbar.value**3)*(constants.c.value**5)/(
    constants.e.value**4)

density = 1                                      # g/cm^3
density_NonEVUnits = units.g/units.cm**3

density *= density_NonEVUnits.to(units.kg*units.m**(-3))*kg_per_m3_2_eV4


# Length.
_per_m_2_eV = constants.c.value*constants.hbar.value/constants.e.value

length = 1                                       # um
length_NonEVUnits = units.um

length *= length_NonEVUnits.to(units.m)/_per_m_2_eV


'''
U = (length**0.8)*(density**0.6)*(alpha**0.4)  # a constant.


M_list = [M_pl, M_pl/1e1, M_pl/1e2, M_pl/1e3]

parameters = [(Mi, U/(Mi**0.6)) for Mi in M_list]
'''


' -------------------------------------------------------------------------- '
' -------------------- Physical dimensionful parameters -------------------- '
' -------------------------------------------------------------------------- '

# densities need verifying against a good source. Cuurently google ai answears.

light_speed = 299792458.0                        # m/s

density_Al = 2.7                    # g/cm^3  (https://www.mit.edu/~6.777/matprops/aluminum.htm)
density_vac = 1.189e-13             # g/cm^3
density_Pt = 21.45                  # g/cm^3  (https://www.bullionbypost.co.uk/index/platinum/density-of-platinum/)
density_W = 19.3                    # g/cm^3  (https://www.wolfram.at/en/raw-materials/what-is-tungsten/)
density_Si = 2.33                   # g/cm^3  (https://lampz.tugraz.at/~hadley/memm/materials/silicon/silicon.php)
density_Cu = 8.96                   # g/cm^3  (https://www.princeton.edu/~maelabs/mae324/glos324/copper.htm)
density_SiO2 = 2.65                 # g/cm^3  (https://crystal-gmbh.com/shared/downloads/datenblaetter/substrates_de/SiO2_sc_Quartz.pdf)


# Rescale densities.

rescaled_density_Al = density_Al / density_scale
rescaled_density_vac = density_vac / density_scale
rescaled_density_Pt = density_Pt / density_scale
rescaled_density_W = density_W / density_scale
rescaled_density_Si = density_Si / density_scale
rescaled_density_Cu = density_Cu / density_scale
rescaled_density_SiO2 = density_SiO2 / density_scale


# Position of boundaries in um.

boundary_pos_lower_plate = [-13000.37, -8000.37, -6000.37, -0.37, -0.07]
boundary_pos_gap = [0, 50]
boundary_pos_sensor_plate = [50.07, 50.37, 50.39, 50.395, 150.395, 150.4,
                             150.42, 5150.42, 8150.42]

boundary_pos = np.array(boundary_pos_lower_plate[1:] + boundary_pos_gap
                        + boundary_pos_sensor_plate[:-1])


' --------------------------------------------------------------------------- '
' ----------------------------- Setup functions ----------------------------- '
' --------------------------------------------------------------------------- '


def Al(x):
    return rescaled_density_Al


def vacuum(x):
    return rescaled_density_vac


def Pt(x):
    return rescaled_density_Pt


def W(x):
    return rescaled_density_W


def Si(x):
    return rescaled_density_Si


def Cu(x):
    return rescaled_density_Cu


def SiO2(x):
    return rescaled_density_SiO2


lower_plate = [Pt, W, SiO2, Cu, Al]
gap = [vacuum]
sensor_plate = [Pt, W, Pt, W, Si, W, Pt, vacuum, Al]

density_profile = lower_plate + gap + sensor_plate


' -------------------------------------------------------------------------- '
' --------------- Solve for the field and calculate pressure --------------- '
' -------------------------------------------------------------------------- '


eV4_to_Pa = (constants.c.value*constants.hbar.value)**3/constants.e.value**4
Pa_to_pN_per_cm2 = 1e8

eV4_to_pN_per_cm2 = eV4_to_Pa*Pa_to_pN_per_cm2


def calc_rescaled_pressure(boundary_values):
    boundary_values_sensor = np.array(boundary_values[5:-1])

    layer_density = [0] + [sp(0) for sp in sensor_plate[:-2]] + [0]

    p_diff = np.array([(p1 - p0) for p0, p1 in zip(layer_density[:-1],
                                                   layer_density[1:])])

    return abs(np.dot(boundary_values_sensor, p_diff))


###############################################################################
'''
# Get target pressure.

const = 7.113420042557768e+41
pt = 1e-2

pt /= eV4_to_pN_per_cm2

M = np.sqrt(const/pt)
Lam = U/(M**0.6)


parameters = [(M, Lam)]
print(parameters)
'''

###############################################################################


for M, Lam in parameters:

    VEV = np.sqrt((M*Lam**5)/density)         # eV

    # Get alpha and field scale.
    alpha = alpha_calculator_chameleon(n, M, Lam, p0=density_scale,
                                       L=length_scale,
                                       p0_NonEVUnits=units.g/units.cm**3,
                                       L_NonEVUnits=units.um)

    s = Chameleon(alpha, n, mesh_name=meshname, dimension=1,
                  symmetry="translation symmetry")

    s.solve_static(density_profiles=density_profile, maxiter=20,
                   display_progress=False)

    ' ------------------- Make plot of field profile ------------------- '

    # Plot full field.
    X_min = -13000.37
    X_max = 8150.42

    X_full = np.linspace(X_min, X_max, 2115080)
    field_full = np.array([s.field(xi, 0) for xi in X_full])

    fig1, ax1 = plt.subplots(figsize=(8, 6))
    ax1.set_ylabel(r"$\hat{\phi}$")
    ax1.set_xlabel(r"$z/\mu m$")
    ax1.set_xlim([X_min, X_max])

    ax1.axvspan(X_min, 0, alpha=0.4)  # Fill in lower plate.
    ax1.axvspan(50, boundary_pos_sensor_plate[-3], alpha=0.4,
                color='lightcoral')  # Fill in sensor plate.
    ax1.axvspan(boundary_pos_sensor_plate[-2], X_max, alpha=0.4,
                color='lightcoral')  # Fill in sensor plate.

    ax1.plot(X_full, field_full)

    plt.show()

    # Plot field zoomed in onto a specific section.
    X2_min, X2_max = -20, 70
    X2_min, X2_max = -20, 180

    X_zoom = np.linspace(X2_min, X2_max, 9001)

    field_zoom = np.array([s.field(xi, 0) for xi in X_zoom])

    fig2, ax2 = plt.subplots(figsize=(8, 6))
    ax2.set_ylabel(r"$\hat{\phi}$")
    ax2.set_xlabel(r"$z/\mu m$")
    ax2.set_xlim([X2_min, X2_max])

    ax2.axvspan(X2_min, 0, alpha=0.4)  # Fill in lower plate.
    ax2.axvspan(50, min(X2_max, boundary_pos[-2]), alpha=0.4,
                color='lightcoral')  # Fill in sensor plate.

    plt.plot(X_zoom, field_zoom)

    plt.show()

    # Calc pressure.
    bv = [s.field(xi, 0) for xi in boundary_pos]
    C = VEV*density/M
    pressure = C*calc_rescaled_pressure(boundary_values=bv)
    print(pressure*eV4_to_pN_per_cm2)
