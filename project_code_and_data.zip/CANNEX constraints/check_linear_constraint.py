#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 10 10:25:30 2026

@author: chad-briddon

Check solutons agree with constraint.

"""

from _initalise import np, Lambda_DE, M_pl
from _initalise import Al, vac, Pt, W, Si, Cu, SiO2, density
from _initalise import kg_per_m3_2_eV4, density_unit

from astropy import units
from chameleon_n1_planar_solutions.chameleon_identities import calc_VEV


' -------------------------------------------------------------------------- '
' ----------------------- Define densities of layers ----------------------- '
' -------------------------------------------------------------------------- '

# Assign correct density to each layer ('left --> right' == 'bottom --> top').
lower_plate = [Al, Cu, SiO2, W, Pt]
gap = [vac]
sensor_plate = [Pt, W, Pt, W, Si, W, Pt, vac, Al]

densities = np.array(lower_plate + gap + sensor_plate)


' -------------------------------------------------------------------------- '
' --------------------- Use example of boundary values --------------------- '
' -------------------------------------------------------------------------- '

beta_log = -0.5
beta = 10**beta_log
M = M_pl/beta
VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

field_boundaries = np.array([0.4313613349279117, 0.4327881366740818,
                             0.9569266091487438, 0.9571960898801957,
                             0.9572592650799833, 0.9599633307950745,
                             0.9600263446202193, 0.9602976731574877,
                             0.9603158338399707, 0.9603203755411664,
                             1.0592364584069978, 1.0592418282772242,
                             1.0592633139138858, 1.041119837836376])*VEV


' --------------------------------------------------------------------------- '
' ---------- Begin calculation (as would be done in solution code) ---------- '
' --------------------------------------------------------------------------- '

densities_eV = densities *\
    density_unit.to(units.kg*units.m**(-3))*kg_per_m3_2_eV4


field_VEVs = calc_VEV(Lambda=Lambda_DE, M=M, density=densities_eV)

' ---------------------------- Make new objects ---------------------------- '

A = (densities_eV[1:] - densities_eV[:-1])/2
M = 1  # np.mean(densities_eV)

A /= M
C = (densities_eV[-1]*field_VEVs[-1] - densities_eV[0]*field_VEVs[0])/M


# The actual calculation for the constraint residual.
Res = C - np.dot(A, field_boundaries)
print("Residual is :", Res)

# Res2 = Y2 - np.dot(dP, np.tanh(x))
# print("Residual is :", Res2)
