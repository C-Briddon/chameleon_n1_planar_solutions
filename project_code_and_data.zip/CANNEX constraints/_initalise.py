#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun  2 12:16:58 2026

@author: chad-briddon

Initialise constant values to be used in the simulation.

"""

import numpy as np
import matplotlib.pyplot as plt

from os import mkdir
from os.path import exists
from astropy import units, constants


plt.rc('axes', labelsize=15)
plt.rc('legend', fontsize=15)


' --------------------------------------------------------------------------- '
' ---------------------------------- Model ---------------------------------- '
' --------------------------------------------------------------------------- '

n = 1
Lambda_DE = 2.4e-3                               # eV
M_pl = 2.4e27                                    # eV


' --------------------------------------------------------------------------- '
' --------------------------- Set physical scales --------------------------- '
' --------------------------------------------------------------------------- '

density_scale = 1.0                              # g/cm^3
length_scale = 1.0                               # um

density_unit = units.g/units.cm**3
length_unit = units.um


# Conversion constants.
_per_m_2_eV = constants.c.value*constants.hbar.value/constants.e.value

kg_per_m3_2_eV4 = (constants.hbar.value**3)*(constants.c.value**5)/(
    constants.e.value**4)

eV4_to_Pa = (constants.c.value*constants.hbar.value)**3/constants.e.value**4
Pa_to_pN_per_cm2 = 1e8

eV4_to_pN_per_cm2 = eV4_to_Pa*Pa_to_pN_per_cm2


# Physcal scales in eV's
density = density_scale *\
    density_unit.to(units.kg*units.m**(-3))*kg_per_m3_2_eV4

length = length_scale*length_unit.to(units.m)/_per_m_2_eV


' -------------------------------------------------------------------------- '
' --------------------------- Material densities --------------------------- '
' -------------------------------------------------------------------------- '

density_Al = 2.7                    # g/cm^3  (https://www.mit.edu/~6.777/matprops/aluminum.htm)
#density_vac = 1.189e-13             # g/cm^3
density_vac = 5.30e-15
density_Pt = 21.45                  # g/cm^3  (https://www.bullionbypost.co.uk/index/platinum/density-of-platinum/)
density_W = 19.3                    # g/cm^3  (https://www.wolfram.at/en/raw-materials/what-is-tungsten/)
density_Si = 2.33                   # g/cm^3  (https://lampz.tugraz.at/~hadley/memm/materials/silicon/silicon.php)
density_Cu = 8.96                   # g/cm^3  (https://www.princeton.edu/~maelabs/mae324/glos324/copper.htm)
density_SiO2 = 2.65                 # g/cm^3  (https://crystal-gmbh.com/shared/downloads/datenblaetter/substrates_de/SiO2_sc_Quartz.pdf)


# Rescale densities.

Al = density_Al / density_scale
vac = density_vac / density_scale
Pt = density_Pt / density_scale
W = density_W / density_scale
Si = density_Si / density_scale
Cu = density_Cu / density_scale
SiO2 = density_SiO2 / density_scale


' --------------------------------------------------------------------------- '
' --------------------------------------------------------------------------- '
