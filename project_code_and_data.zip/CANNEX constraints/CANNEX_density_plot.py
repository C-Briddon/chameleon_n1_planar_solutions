#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun May 10 14:16:53 2026

@author: chad-briddon

Make figure to illustrate the layers of the CANNEX setup and the materials
composing each layer.

"""

import numpy as np
import matplotlib.pyplot as plt


density_Al = 2.7                                 # g/cm^3
density_vac = 5.30e-15                           # g/cm^3
density_Pt = 21.45                               # g/cm^3
density_W = 19.3                                 # g/cm^3
density_Si = 2.33                                # g/cm^3
density_Cu = 8.96                                # g/cm^3
density_SiO2 = 2.65                              # g/cm^3

density_max = 21.45


' --------------------------------------------------------------------------- '
' ---------------------------------- Setup ---------------------------------- '
' --------------------------------------------------------------------------- '

# Note below has origin at junction of vacuum and (fixed) bottom plate.


gap_vacuum = 50                    # Can vary (10-50 or up to 6000).


# Lower plate (top-to-bottom).
LP_Pt = 0.07
LP_W = 0.30
LP_SiO2 = 6000
PL_Cu = 2000

PL_Al = 5000


lower_plate_layer_thickness = np.array([5000, 2000, 6000, 0.30, 0.07])

lower_plate_boundary_pos = np.array([-13000.37, -8000.37, -6000.37, -0.37,
                                     -0.07])


# Sensor plate (top-to-bottom).
SP_Al = 3e3
SP_vacuum = 5e3
SP_Pt = 0.02
SP_W = 5e-3
SP_Si = 100
SP_W = 5e-3
SP_Pt = 0.02
SP_W = 0.3
SP_Pt = 0.07


sensor_plate_layer_thickness = np.array([0.07, 0.3, 0.02, 5e-3, 100, 5e-3,
                                         0.02, 5e3, 3e3])

sensor_plate_boundary_pos = np.array([50.07, 50.37, 50.39, 50.395, 150.395,
                                      150.4, 150.42, 5150.42, 8150.42])


# Material names and densities (g/cm^3) bottom-to-top.

lp_material = [('Al', density_Al), ('Cu', density_Cu), ('SiO2', density_SiO2),
               ('W', density_W), ('Pt', density_Pt)]


vac_material = [('vac', density_vac)]


sp_material = [('Pt', density_Pt), ('W', density_W), ('Pt', density_Pt),
               ('W', density_W), ('Si', density_Si), ('W', density_W),
               ('Pt', density_Pt), ('vac', density_vac), ('Al', density_Al)]


' --------------------------------------------------------------------------- '
' ---------------------------- Make illustartion ---------------------------- '
' --------------------------------------------------------------------------- '

r = 5  # Factor to adjust size of layers on plot.


# Convert the lengths to a log scale so can see the smaller layers.
lp_thickness_log = np.log10(lower_plate_layer_thickness) + r
sp_thickness_log = np.log10(sensor_plate_layer_thickness) + r


# Make plot.
fig, ax = plt.subplots(figsize=(8, 6))

ax.set_yticks([])
ax.set_xticks([])

x = 0

# Lower plate.
for t, m, layer_thickness in zip(lp_thickness_log, lp_material,
                                 lower_plate_layer_thickness):
    name = m[0]
    density = m[1]

    shade = np.sqrt(density/density_max)

    ax.axhspan(x, x+t, alpha=shade, color='cornflowerblue')

    # Add text label.
    ax.text(0.5, x + t/2,
            r"$%s (%.2f \ g/cm^3, %.2f \ \mu m)$" % (name, density,
                                                     layer_thickness),
            horizontalalignment='center', verticalalignment='center')

    x += t


# Vacuum gap.
t = np.log10(gap_vacuum) + r

ax.axhspan(x, x+t, alpha=0)

ax.text(0.5, x + t/2,
        r"$vac (0.00 \ g/cm^3, %.2f \ \mu m)$" % gap_vacuum,
        horizontalalignment='center', verticalalignment='center')

x += t


# Sensor layer.
for t, m, layer_thickness in zip(sp_thickness_log, sp_material,
                                 sensor_plate_layer_thickness):
    name = m[0]
    density = m[1]

    shade = np.sqrt(density/density_max)

    ax.axhspan(x, x+t, alpha=shade, color='lightcoral')

    # Add text label.
    ax.text(0.5, x + t/2,
            r"$%s (%.2f \ g/cm^3, %.2f \ \mu m)$" % (name, density,
                                                     layer_thickness),
            horizontalalignment='center', verticalalignment='center')

    x += t


ax.set_ylim([0, x])
fig.savefig("Images/CANNEX_setup", dpi=300, bbox_inches='tight')
