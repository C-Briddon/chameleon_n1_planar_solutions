#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 29 15:40:33 2026

@author: chad-briddon

Use SELCIE to compute the boundary values, and therefore the pressure on sensor
plate in the CANNEX experiment. Can use then plug the boundary values into
analytic equations to confirm them.

Use analytic values as initial guesses and compute the pressure gradient.

*This code ran using SELCIE v2.0.0.

"""

from _initalise import np, plt, mkdir, exists
from _initalise import n, Lambda_DE, M_pl
from _initalise import density_Al, density_vac, density_Pt, density_W
from _initalise import density_Si, density_Cu, density_SiO2, density, length
from _initalise import eV4_to_pN_per_cm2, density_scale, length_scale
from _initalise import length_unit, density_unit

from SELCIE.Solvers import Chameleon
from SELCIE.Misc import alpha_calculator_chameleon


plt.rc('axes', labelsize=15)
plt.rc('legend', fontsize=15)

dis = 0.1


NoVac_Options = None

if NoVac_Options is None:
    pass

elif NoVac_Options == 1:
    density_vac *= 1e11

elif NoVac_Options == 2:
    density_vac *= 0

elif NoVac_Options == 3:
    density_vac *= 1e9


' --------------------------------------------------------------------------- '


log_beta = list(np.round(np.linspace(-1.00, 6.0, 141), 4))


# Note converted second column to pN/cm^2 and third to pN/cm^2/um.
i = 27
CANNEX_data0 = [
    (3.0000000000000000, 10.090243035439571000, 14.603095459424381),
    (3.2393254869831290,  7.239265226328643000,  9.616859314745363),
    (3.4977432035394953,  5.209746816906757000,  6.349530521313371),
    (3.7767762353825017,  3.762123975244741500,  4.2019586220269085),
    (4.0780691726355770,  2.726937132507061500,  2.7869309141499744),
    (4.4033978028662080,  1.984441567560577600,  1.8537823604368068),
    (4.7546795773833400,  1.450062943850155800,  1.2390100958957337),
    (5.1339849124853420,  1.064043298534854200,  0.8310695867563316),
    (5.5435493922668740,  0.784126522542000400,  0.5593909954110098),
    (5.9857869449066390,  0.580416627413294250,  0.3778709727083459),
    (6.4633040700956520,  0.431703095079227900,  0.25626667114744717),
    (6.9789152014608790,  0.322856224000782670,  0.17421719563186385),
    (7.5356592945287405,  0.243029522294287660,  0.11868869083852226),
    (8.1368177379960860,  0.184404164598048070,  0.08105980073851838),
    (8.7859336938757110,  0.141312259088962540,  0.05550583770155003),
    (9.4868329805051400,  0.109620633779362030,  0.038101006347565733),
    (10.243646621500805,  0.086306098001573950,  0.026241357648188666),
    (11.060835193558726,  0.069152083210239560,  0.018173194139536157),
    (11.943215116604916,  0.056530489575896050,  0.012673582724586214),
    (12.895987041246831,  0.047243421645446780,  0.008922231009587215),
    (13.924766500838338,  0.040409825053424410,  0.006364210902611688),
    (15.035617008818167,  0.035381711990196174,  0.004624206234762901),
    (16.235085796393910,  0.031682156319832695,  0.0034367708044077834),
    (17.530242401205530,  0.028960087581117610,  0.002626631165599906),
    (18.928720334405797,  0.026957237257455670,  0.0020744135766666874),
    (20.438762071738836,  0.025483652537965060,  0.0016982308441742522),
    (22.069267633789240,  0.024399480963449340,  0.001441350587685605),
    (23.829847041728447,  0.023601812867855470,  0.00126593269871583),
    (25.730876957726823,  0.023014949847032000,  0.0011462887868655936),
    (27.783561843863803,  0.022583211440469780,  0.0010645558592928105)][i:i+1]


'''
Note in paper "https://arxiv.org/pdf/2405.14638", Hauke uses 2*sigma as the
constraint. Above values are for 1*sigma, so must modify to get consistent
constraint.
'''
CANNEX_data = [(cd[0], 2*cd[1], 2*cd[2]) for cd in CANNEX_data0]


' -------------------------------------------------------------------------- '
' -------------------- Physical dimensionful parameters -------------------- '
' -------------------------------------------------------------------------- '

# Rescale densities.

rescaled_density_Al = density_Al / density_scale
rescaled_density_vac = density_vac / density_scale
rescaled_density_Pt = density_Pt / density_scale
rescaled_density_W = density_W / density_scale
rescaled_density_Si = density_Si / density_scale
rescaled_density_Cu = density_Cu / density_scale
rescaled_density_SiO2 = density_SiO2 / density_scale


' --------------------------------------------------------------------------- '
' ----------------------------- Setup functions ----------------------------- '
' --------------------------------------------------------------------------- '


def Al(x):
    return rescaled_density_Al


def vacuum(x):
    return rescaled_density_vac


def Pt(x):
    return rescaled_density_Pt


def W(x):
    return rescaled_density_W


def Si(x):
    return rescaled_density_Si


def Cu(x):
    return rescaled_density_Cu


def SiO2(x):
    return rescaled_density_SiO2


lower_plate = [Pt, W, SiO2, Cu, Al]
gap = [vacuum]
sensor_plate = [Pt, W, Pt, W, Si, W, Pt, vacuum, Al]

density_profile = lower_plate + gap + sensor_plate


' --------------------------------------------------------------------------- '
' --------- Make function to load previus solution as initial guess --------- '
' --------------------------------------------------------------------------- '

# Wasn't quicker.
'''
# Set densities for analytic solver.
lower_plate0 = [rescaled_density_Al, rescaled_density_Cu,
                rescaled_density_SiO2, rescaled_density_W, rescaled_density_Pt]
gap0 = [rescaled_density_vac]
sensor_plate0 = [
    rescaled_density_Pt, rescaled_density_W, rescaled_density_Pt,
    rescaled_density_W, rescaled_density_Si, rescaled_density_W,
    rescaled_density_Pt, rescaled_density_vac, rescaled_density_Al]

density_profile0 = np.array(lower_plate0 + gap0 + sensor_plate0)


def load_initial_guess(gap_size, lb, boundary_pos):

    name = getcwd()[:-len("CANNEX constraints (grad)")] + \
        "CANNEX constraints/Data/gradient/" + \
        "Boundary Data(_%.3fum)(1)/LogB%.3f" % (gap_size, lb)

    # Load boundary values.
    beta = 10**lb
    M = M_pl/beta                                # eV
    VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

    with open(name, "r") as txt_file:
        bv = np.array(eval(txt_file.read()))*VEV

    # Generate function to compute the field profile.
    func, _ = planar_solution(Lambda_DE, M, densities=density_profile0,
                              boundary_positions=boundary_pos,
                              boundary_guess=bv,
                              density_NonEVUnits=density_unit,
                              length_NonEVUnits=length_unit,
                              use_boundary_guess=True)

    def f(x):
        return func([x[0]])/VEV

    return f
'''

' --------------------------------------------------------------------------- '
' --------------- Solve for the field and either save or plot --------------- '
' --------------------------------------------------------------------------- '

# Position of boundaries in um.
boundary_pos_lower_plate = [-13000.37, -8000.37, -6000.37, -0.37, -0.07]
sensor_plate_layer_thickness = [0.07, 0.3, 0.02, 5e-3, 100, 5e-3, 0.02,
                                5e3, 3e3]

sensor_plate_boundary_pos = np.round(
    [sum(sensor_plate_layer_thickness[:i+1])
     for i in range(len(sensor_plate_layer_thickness))], 5)


dis_vector = np.zeros(14)
dis_vector[5:] = 1

for gap_size, _, _ in CANNEX_data:

    # Make un-displaced boundary position list.
    boundary_pos_gap0 = [0, gap_size]
    boundary_pos_sensor_plate0 = list(sensor_plate_boundary_pos + gap_size)
    boundary_pos0 = np.array(boundary_pos_lower_plate[1:] + boundary_pos_gap0
                             + boundary_pos_sensor_plate0[:-1])

    for displacement in [-dis, dis]:

        path = "Data/gradient/Boundary Data(_%.3fum)(%.3fum)(1)" % (
            gap_size, displacement)
        meshname = "CANNEX(%.3fum)(%.3fum)" % (gap_size, displacement)

        # Modify path if we are using a different vacuum value.
        if NoVac_Options is None:
            pass

        elif NoVac_Options == 1:
            path = "Data/gradient/Boundary Data" + \
                "(_%.3fum)(%.3fum)(NoVac)(1)" % (gap_size, displacement)

        elif NoVac_Options == 2:
            path = "Data/gradient/Boundary Data" + \
                "(_%.3fum)(%.3fum)(TrueVac)(1)" % (gap_size, displacement)

        elif NoVac_Options == 3:
            path = "Data/gradient/Boundary Data" + \
                "(_%.3fum)(%.3fum)(PartialVac)(1)" % (gap_size, displacement)

        if exists(path):
            pass
        else:
            mkdir(path)

        # Define new boundary positions (with displacement).
        boundary_pos = boundary_pos0 + displacement*dis_vector
        print(boundary_pos)

        # Iterate over beta parameter.
        for lb in log_beta:

            name = path + "/LogB%.3f" % lb

            # Skip if needed.
            if len(log_beta) > 1 and exists(name) is True:
                continue

            print(name)

            # Load initial guess.
            '''
            initial_guess_f = load_initial_guess(gap_size, lb, boundary_pos0)
            initial_profiles = [initial_guess_f
                                for i, _ in enumerate(density_profile)]
            '''

            beta = 10**lb
            M = M_pl/beta                                # eV
            VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

            # Get alpha and field scale.
            alpha = alpha_calculator_chameleon(
                n, M, Lambda_DE, p0=density_scale, L=length_scale,
                p0_NonEVUnits=density_unit, L_NonEVUnits=length_unit)

            s = Chameleon(alpha, n, mesh_name=meshname, dimension=1,
                          symmetry="translation symmetry")

            s.solve_static(density_profiles=density_profile, maxiter=100,
                           tol_du=5e-8)

            # Record field values at boundaries.
            with open(name, "w") as tf:
                tf.write(str([s.field(xi, 0) for xi in boundary_pos]))


' --------------------------------------------------------------------------- '
' --------------------- Use saved data to generate plot --------------------- '
' --------------------------------------------------------------------------- '

for gap_size, target_pressure, target_pressure_grad in CANNEX_data:

    pressure_dis = []

    for displacement in [-dis, dis]:

        path = "Data/gradient/Boundary Data(_%.3fum)(%.3fum)(1)" % (
            gap_size, displacement)
        meshname = "CANNEX(%.3fum)(%.3fum)" % (gap_size, displacement)

        # Modify path if we are using a different vacuum value.
        if NoVac_Options is None:
            pass

        elif NoVac_Options == 1:
            path = "Data/gradient/Boundary Data" + \
                "(_%.3fum)(%.3fum)(NoVac)(1)" % (gap_size, displacement)

        elif NoVac_Options == 2:
            path = "Data/gradient/Boundary Data" + \
                "(_%.3fum)(%.3fum)(TrueVac)(1)" % (gap_size, displacement)

        elif NoVac_Options == 3:
            path = "Data/gradient/Boundary Data" + \
                "(_%.3fum)(%.3fum)(PartialVac)(1)" % (gap_size, displacement)

        # Make function to compute pressure.
        def calc_rescaled_pressure(boundary_values):
            boundary_values_sensor = np.array(boundary_values[5:-1])

            layer_density = [0] + [sp(0) for sp in sensor_plate[:-2]] + [0]

            p_diff = np.array([(p1 - p0) for p0, p1 in zip(layer_density[:-1],
                                                           layer_density[1:])])

            return abs(np.dot(boundary_values_sensor, p_diff))

        # Make plot for fixed Lambda value.
        pressure = []

        for lb in log_beta:

            name = path + "/LogB%.3f" % lb

            beta = 10**lb
            M = M_pl/beta                                # eV
            VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

            C = VEV*density/M

            with open(name, "r") as txt_file:
                bv = np.array(eval(txt_file.read()))

            pressure.append(
                eV4_to_pN_per_cm2*C*calc_rescaled_pressure(boundary_values=bv))

        pressure_dis.append(np.array(pressure))

    # Calculate pressure gradient.
    pressure_grad = (pressure_dis[1] - pressure_dis[0])/(2*dis)

    if False:
        # Plot pressure gradient against beta (Lambda is fixed).
        fig3, ax3 = plt.subplots(figsize=(8, 6))
        # ax3.set_ylabel(r"$| \partial p_z|/\left( pN/cm^{-2}/\mu m \right)$")
        ax3.set_xlabel(r"$Log(\beta)$")

        ax3.plot(log_beta, pressure, label="pressure")
        ax3.plot(log_beta, pressure_grad, label="pressure grad")

        ax3.legend()

    ' ------------------------------------------------------------------ '
    ' -------------- Make constraint plots using pressure -------------- '
    ' ------------------------------------------------------------------ '

    if True:
        U = (length**0.8)*(density**0.6)  # a constant.

        fig4, ax4 = plt.subplots(figsize=(8, 6))
        ax4.set_ylabel(r"$Log \left( \frac{\Lambda}{eV} \right)$")
        ax4.set_xlabel(r"$Log \left( \frac{M}{M_{PL}} \right)$")

        ax4.set_ylim([-4, 1])
        ax4.set_xlim([-18, 1])

        ax4.axhline(y=np.log10(Lambda_DE))

        eq_curve, eq_curve_grad = [], []
        for lb, p1, p1_grad in zip(log_beta, pressure, pressure_grad):

            beta = 10**lb
            M1 = M_pl/beta                           # eV

            # Get alpha and field scale.
            alpha = alpha_calculator_chameleon(
                n, M1, Lambda_DE, p0=density_scale, L=length_scale,
                p0_NonEVUnits=density_unit, L_NonEVUnits=length_unit)

            M2 = M1*np.sqrt(p1/target_pressure)
            M2_grad = M1*np.sqrt(abs(p1_grad)/target_pressure_grad)

            Lambda2 = U*(alpha**0.4)/(M2**0.6)
            Lambda2_grad = U*(alpha**0.4)/(M2_grad**0.6)

            eq_curve.append((M2, Lambda2))
            eq_curve_grad.append((M2_grad, Lambda2_grad))

        # Plot equal pressure curve.
        X = np.array([np.log10(para[0]/M_pl) for para in eq_curve])
        Y = np.array([np.log10(para[1]) for para in eq_curve])

        ax4.plot(X, Y, color="blue", linestyle="solid", label="pressue")

        X = np.array([np.log10(para[0]/M_pl) for para in eq_curve_grad])
        Y = np.array([np.log10(para[1]) for para in eq_curve_grad])

        ax4.plot(X, Y, color="red", linestyle="solid", label="pressue grad")

        ' Add line showing when Compton wavelength in sheild is 10% its width '

        Comp_SheildL_ratio = 0.1
        SheildL = 3000  # um
        Comp_um = Comp_SheildL_ratio*SheildL

        Comp_eV = Comp_um*length
        density_AL_eV = Al(0)*density

        constant = 4*(Comp_eV**4)*(density_AL_eV**3)/(M_pl**3)

        beta = (constant/(Lambda_DE**5))**(-1/3)
        # print(np.log10(beta))

        C = 0.2*np.log10(constant)

        log_M = np.linspace(-10, 2, 801)
        log_Lam = C - 0.6*log_M

        M = 10**log_M
        Lam = 10**log_Lam

        ax4.plot(log_M, log_Lam, color="black", linestyle="solid")

        ax4.legend()

    ' ---------------------------------------------------------------------- '
    ' ------------- Calculate Compton wavelength inside sheild ------------- '
    ' ---------------------------------------------------------------------- '

    beta = 10**min(log_beta)
    beta = 10**(-0.5)
    M = M_pl/beta                               # eV

    alpha = alpha_calculator_chameleon(n, M, Lambda_DE, p0=rescaled_density_Al,
                                       L=1000,
                                       p0_NonEVUnits=density_unit,
                                       L_NonEVUnits=length_unit)

    Comp_mm = np.sqrt(alpha/2)

    ratio_Sheild_Comp_L = Comp_mm/3.0

    print(ratio_Sheild_Comp_L)
