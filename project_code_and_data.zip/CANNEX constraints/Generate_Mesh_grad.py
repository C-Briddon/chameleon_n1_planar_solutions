#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 29 16:40:39 2026

@author: chad-briddon

Generate mesh of the CANNEX experiment.


Layer specifications.
---------------------

sensor(movable), from top to bottom:

    Material, thickness

    Al, 3mm
    vacuum, 5mm
    Pt, 20nm
    W, 5nm
    Si, 100um
    W, 5nm
    Pt, 20 nm
    W, 300 nm
    Pt, 70 nm

vacuum gap 10-50 um (or up to 6 mm but then with more error)

lower plate, from top to bottom:

    Material, thickness

    Pt 70 nm
    W, 300nm
    SiO2 6 mm
    Cu, 2 mm

then follows a complex mixture of materials with gaps but that may
neither be 1d nor easy to model, so for your calculation, you may just
assume 5 mm Al and then vacuum.


Note will map left -> right as bottom -> top. x=x is at interface of lower
plate and vacuum.

This version allows for displacements of the sensor plate.

*This code ran using SELCIE v2.0.0.

"""

import sys
import numpy as np
from SELCIE.Mesh import MeshingTools_1D


' --------------------- Set Parameters (in units of um) --------------------- '


# Lower plate (top-to-bottom).
LP_Pt = 0.07
LP_W = 0.30
LP_SiO2 = 6000
PL_Cu = 2000

PL_Al = 5000

# Righter entries are further from gap (start set at zero).
lower_plate_boundary_pos = [-0.07, -0.37, -6000.37, -8000.37, -13000.37]


# Sensor plate (top-to-bottom).
SP_Al = 3e3
SP_vacuum = 5e3
SP_Pt = 0.02
SP_W = 5e-3
SP_Si = 100
SP_W = 5e-3
SP_Pt = 0.02
SP_W = 0.3
SP_Pt = 0.07

# Righter entries are further from gap.
sensor_plate_layer_thickness = [0.07, 0.3, 0.02, 5e-3, 100, 5e-3, 0.02,
                                5e3, 3e3]

sensor_plate_layer_thickness[-1] += 2000  # Extend.


' ----------------------------- Construct Mesh ----------------------------- '


def make_mesh(filename, gap, displacement):
    'This version allows the sensor plate to be dispaced by some amount.'

    sensor_plate_boundary_pos = np.round(
        [sum(sensor_plate_layer_thickness[:i+1])
         for i in range(len(sensor_plate_layer_thickness))], 5)

    # Construct mesh.
    MT = MeshingTools_1D(display_messages=True)

    # Lower plate (fixed).
    L_id = []

    for x in lower_plate_boundary_pos:
        L_id += MT.create_1D_line(x_start=0, x_end=x, embed=L_id)
        MT.create_subdomain(CellSizeMin=1e-4, CellSizeMax=1, DistMax=1000)

    # Vacuum gap.
    Gap = MT.create_1D_line(x_start=lower_plate_boundary_pos[0],
                            x_end=gap+displacement, embed=L_id)
    MT.create_subdomain(CellSizeMin=1e-4, CellSizeMax=1, DistMax=1000)

    # Sensor plate.
    S_id = []

    for x in sensor_plate_boundary_pos:
        y = gap + x + displacement

        S_id += MT.create_1D_line(x_start=1, x_end=y, embed=Gap+S_id)
        MT.create_subdomain(CellSizeMin=1e-4, CellSizeMax=1,
                            DistMin=0.3, DistMax=1000)

    MT.generate_mesh(filename, show_mesh=False)
    MT.msh_2_xdmf(filename, auto_override=True)

    return None


if __name__ == "__main__":
    CANNEX_data = [3.0000000000000000,
                   3.2393254869831290,
                   3.4977432035394953,
                   3.7767762353825017,
                   4.0780691726355770,
                   4.4033978028662080,
                   4.7546795773833400,
                   5.1339849124853420,
                   5.5435493922668740,
                   5.9857869449066390,
                   6.4633040700956520,
                   6.9789152014608790,
                   7.5356592945287405,
                   8.1368177379960860,
                   8.7859336938757110,
                   9.4868329805051400,
                   10.243646621500805,
                   11.060835193558726,
                   11.943215116604916,
                   12.895987041246831,
                   13.924766500838338,
                   15.035617008818167,
                   16.235085796393910,
                   17.530242401205530,
                   18.928720334405797,
                   20.438762071738836,
                   22.069267633789240,
                   23.829847041728447,
                   25.730876957726823,
                   27.783561843863803]

    dis = [-0.05, 0.05, 0.00]

    args = sys.argv  # Allows for entering values on command line.

    # First argument is always file location.
    i = int(args[1])
    # j = int(args[2])
    j = 1

    gap_size = CANNEX_data[i]
    displacement = dis[j]

    meshname = "CANNEX(%.3fum)(%.3fum)" % (gap_size, displacement)

    make_mesh(meshname, gap_size, displacement)
