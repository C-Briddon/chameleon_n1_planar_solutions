#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 19 16:33:06 2026

@author: chad-briddon

Generate mesh of the Casimir experiment / an approximation of CANNEX.

From previuos version : increased mesh refinement.

*This code ran using SELCIE v2.0.0.

"""

from SELCIE.Mesh import MeshingTools_1D


' --------------------- Set Parameters (in units of um) --------------------- '


# Lower plate (top-to-bottom).
lower_plate_boundary_pos = [-13000.37, 0]


# Sensor plate (top-to-bottom).
sensor_plate_boundary_pos = [50, 150.42, 5150.42, 8150.42]


' ----------------------------- Construct Mesh ----------------------------- '

Extended = True

filename = "CANNEX(Approx)(2)"

if Extended:
    filename += "(Extended)"


L_id = []
MT = MeshingTools_1D(display_messages=True)

L_id += MT.create_1D_line(x_start=-13000.37, x_end=0, embed=L_id)    # Wall
MT.create_subdomain(CellSizeMin=1e-4, CellSizeMax=0.1, DistMax=1000)

L_id += MT.create_1D_line(x_start=-1, x_end=50, embed=L_id)          # Vacuum
MT.create_subdomain(CellSizeMin=1e-4, CellSizeMax=0.1, DistMax=1000)

L_id += MT.create_1D_line(x_start=49, x_end=150.42, embed=L_id)      # Sensor
MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.1, DistMin=0.3,
                    DistMax=1000)

L_id += MT.create_1D_line(x_start=150, x_end=5150.42, embed=L_id)    # Vacuum
MT.create_subdomain(CellSizeMin=1e-5, CellSizeMax=0.1, DistMax=1000)


# Shield
if Extended:
    L_id += MT.create_1D_line(x_start=5150, x_end=8150.42+3000, embed=L_id)
else:
    L_id += MT.create_1D_line(x_start=5150, x_end=8150.42, embed=L_id)

MT.create_subdomain(CellSizeMin=1e-4, CellSizeMax=0.1, DistMax=1000)


MT.generate_mesh(filename, show_mesh=True)
MT.msh_2_xdmf(filename, auto_override=True)
