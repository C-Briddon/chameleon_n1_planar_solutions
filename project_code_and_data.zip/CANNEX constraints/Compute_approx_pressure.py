#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 22 11:52:50 2026

@author: chad-briddon

Use analytic solution to compute pressure on sensor plate in the CANNEX
experiment.

* This version approximates the sensor and wall to be a single material each. *

Boundary value data saved to :
    Using SELCIE                                - Boundary Data(Apx)(1)
    Analytic using above for initial guess      - Boundary Data(Apx)(2)
    Analytic using default initial guess        - Boundary Data(Apx)(3)
    Analytic using last solution as new guess   - Boundary Data(Apx)(4)

"""

from _initalise import np, plt, mkdir, exists, Lambda_DE, M_pl
from _initalise import Al, vac, Pt, W, Si, Cu, SiO2
from _initalise import density, length, density_unit, length_unit
from _initalise import eV4_to_pN_per_cm2, kg_per_m3_2_eV4, units

from SELCIE.Misc import alpha_calculator_chameleon  # v2.0.0
from chameleon_n1_planar_solutions.solutions import planar_solution


log_beta0 = list(np.round(np.linspace(-1.0, 6.0, 141), 4))
log_beta1 = list(np.round(np.linspace(-1.0, 6.0, 141), 6))

path0 = "Data/field/Boundary Data(Apx)(_20.439um)(1)"
path = "Data/field/Boundary Data(Apx)(_20.439um)(4)"
gap_size = 20.438762071738836


if exists(path):
    pass
else:
    mkdir(path)

' ---------------------- Define densities of materials ---------------------- '

# Calculate average densities for the wall and plate.
wall_layer_thickness = np.array([5000, 2000, 6000, 0.3, 0.07])
wall_layer_density = np.array([Al, Cu, SiO2, W, Pt])

p_wall = np.dot(wall_layer_thickness,
                wall_layer_density)/np.sum(wall_layer_thickness)


sensor_layer_thickness = np.array([0.07, 0.3, 0.02, 5e-3, 100, 5e-3, 0.02])
sensor_layer_density = np.array([Pt, W, Pt, W, Si, W, Pt])

p_sensor = np.dot(sensor_layer_thickness,
                  sensor_layer_density)/np.sum(sensor_layer_thickness)


density_profile = np.array([p_wall, vac, p_sensor, vac, Al])

# Convert densites to natural units.
C = density_unit.to(units.kg*units.m**(-3))*kg_per_m3_2_eV4


' ------------------------ Assign boundary locations ------------------------ '


boundary_pos = np.array([0, gap_size, gap_size+100.42, gap_size+5100.42])


' ------------------------- Solve for field profile ------------------------- '

# For (4). Rescale guess by sqrt(M_new/M_old).
boundary_guess_hold = None

# Choose initial guess.
boundary_guess = []
boundary_guess = None

if False:
    with open("Data/field/Boundary Data(Apx)(_20.438um)(2)/LogB0.500",
              "r") as txt_file:
        boundary_guess = np.array(eval(txt_file.read()))

for lb in reversed(log_beta1):

    name0 = path0 + "/LogB%.3f" % lb
    name = path + "/LogB%.3f" % lb

    beta = 10**lb
    M = M_pl/beta                                # eV
    VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

    # Skip if needed.
    if len(log_beta1) > 1 and exists(name) is True:
        with open(name, "r") as txt_file:
            boundary_guess = np.array(eval(txt_file.read()))
            boundary_guess_hold = boundary_guess/np.sqrt(M)
        continue

    print(name)

    # Load solution from saved SELCIE data.
    if path[-2] == "2":
        with open(name0, "r") as txt_file:
            boundary_guess = VEV*np.array(eval(txt_file.read()))

    elif path[-2] == "3":
        boundary_guess = None
        # if abs(lb + 0.2) < 1e-6:
        #     continue

    elif path[-2] == "4":
        if boundary_guess_hold is None:
            pass
        else:
            boundary_guess = boundary_guess_hold*np.sqrt(M)

    # Solve for field profile.
    func, boundary_values, _ = planar_solution(Lambda_DE, M,
                                               densities=density_profile,
                                               boundary_positions=boundary_pos,
                                               boundary_guess=boundary_guess,
                                               density_NonEVUnits=density_unit,
                                               length_NonEVUnits=length_unit,
                                               use_boundary_guess=False)

    print(boundary_guess)
    print(boundary_values)
    print()

    boundary_guess = boundary_values
    boundary_guess_hold = boundary_guess/np.sqrt(M)

    if len(log_beta1) > 1:
        ' ---------------- Record field values at boundaries ---------------- '
        with open(name, "w") as tf:
            tf.write(str(list(boundary_values)))
    else:
        print("BV :", boundary_values)

        ' ------------------- Make plot of field profile ------------------- '

        # Plot full field.
        X_min = -13000.37
        X_max = 8150.42

        X_full = np.linspace(X_min, X_max, 2115080)

        field_full = func(X_full)

        fig1, ax1 = plt.subplots(figsize=(8, 6))
        ax1.set_ylabel(r"$\phi / eV$")
        ax1.set_xlabel(r"$z/\mu m$")
        ax1.set_xlim([X_min, X_max])

        # Fill lower plate.
        ax1.axvspan(X_min, 0, alpha=0.4)
        # sensor.
        ax1.axvspan(gap_size, gap_size+100.42, alpha=0.4, color='lightcoral')
        # shield.
        ax1.axvspan(gap_size+5100.42, X_max, alpha=0.4, color='lightcoral')

        ax1.plot(X_full, field_full)

        plt.show()

        if len(log_beta1) == 1:
            fig1.savefig("Images/field_LogB%.3f(full)(Apx)(1).png" % lb,
                         dpi=300, bbox_inches='tight')

        # Plot field zoomed in onto a specific section.
        X2_min, X2_max = -20, 70
        X2_min, X2_max = -20, 180

        X_zoom = np.linspace(X2_min, X2_max, 9001)

        field_zoom = func(X_zoom)

        fig2, ax2 = plt.subplots(figsize=(8, 6))
        ax2.set_ylabel(r"$\phi / eV$")
        ax2.set_xlabel(r"$z/\mu m$")
        ax2.set_xlim([X2_min, X2_max])

        ax2.axvspan(X2_min, 0, alpha=0.4)  # Fill lower plate.
        ax2.axvspan(gap_size, min(X2_max, gap_size+100.42), alpha=0.4,
                    color='lightcoral')  # Fill sensor plate.

        plt.plot(X_zoom, field_zoom)

        plt.show()

' -------------------------------------------------------------------------- '
' -------------- Use save boundary values to compute pressure -------------- '
' -------------------------------------------------------------------------- '


def calc_rescaled_pressure(boundary_values):
    return abs(p_sensor*(boundary_values[1] - boundary_values[2]))


# Make plot for fixed Lambda value.

pressure0 = []
pressure = []

if path[-2] == "3":
    log_beta1.pop(16)

for lb in log_beta1:

    name = path + "/LogB%.3f" % lb

    beta = 10**lb
    M = M_pl/beta                                # eV
    VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

    C = density/M

    with open(name, "r") as txt_file:
        bv = np.array(eval(txt_file.read()))

    pressure.append(C*calc_rescaled_pressure(boundary_values=bv))

for lb in log_beta0:

    name0 = path0 + "/LogB%.3f" % lb

    beta = 10**lb
    M = M_pl/beta                                # eV
    VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

    C = VEV*density/M

    with open(name0, "r") as txt_file:
        bv0 = np.array(eval(txt_file.read()))

    pressure0.append(C*calc_rescaled_pressure(boundary_values=bv0))


# Rescale pressure from natural units to pN/cm^2.
pressure0 = eV4_to_pN_per_cm2*np.array(pressure0)
pressure = eV4_to_pN_per_cm2*np.array(pressure)


# Plot pressure against beta (Lambda is fixed).
fig3, ax3 = plt.subplots(figsize=(8, 6))
ax3.set_ylabel(r"$|p_z| / \left( pN/cm^{-2} \right)$")
ax3.set_xlabel(r"$Log(\beta)$")

# ax3.set_ylim([0.00004, 0.00008])
# ax3.set_xlim([0.75, 1.2])

# ax3.set_ylim([0.00002, 0.000110])
# ax3.set_xlim([-0.2, 0.5])

ax3.plot(log_beta0, pressure0, label="Numeric", linestyle="solid")
ax3.plot(log_beta1, pressure, label="Analytic", linestyle="dashed")

fig3.legend()


' -------------------------------------------------------------------------- '
' ------------------ Make constraint plots using pressure ------------------ '
' -------------------------------------------------------------------------- '

U = (length**0.8)*(density**0.6)  # a constant.


fig4, ax4 = plt.subplots(figsize=(8, 6))
ax4.set_ylabel(r"$Log \left( \frac{\Lambda}{eV} \right)$")
ax4.set_xlabel(r"$Log \left( \frac{M}{M_{PL}} \right)$")

ax4.set_ylim([-4, 1])
ax4.set_xlim([-18, 1])

ax4.axhline(y=np.log10(Lambda_DE))


# target_pressure = [1, 1e-1, 1e-2, 1e-3, 1e-4]
target_pressure = [1e-3, 1e-4, 1e-5]
eq_curves = []


for p2 in target_pressure:
    eq_curves.append([])

    for lb, p1 in zip(log_beta1, pressure):

        beta = 10**lb
        M1 = M_pl/beta                           # eV

        # Get alpha and field scale.
        n = 1
        alpha = alpha_calculator_chameleon(n, M1, Lambda_DE, p0=1,
                                           L=1,
                                           p0_NonEVUnits=density_unit,
                                           L_NonEVUnits=length_unit)

        M2 = M1*np.sqrt(p1/p2)
        Lambda2 = U*(alpha**0.4)/(M2**0.6)

        eq_curves[-1].append((M2, Lambda2))


# Plot equal pressure curve.
for eq_curve in eq_curves:
    X = np.array([np.log10(para[0]/M_pl) for para in eq_curve])
    Y = np.array([np.log10(para[1]) for para in eq_curve])

    ax4.plot(X, Y, color="blue", linestyle="solid")
