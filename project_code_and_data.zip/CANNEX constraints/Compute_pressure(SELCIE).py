#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun May 10 10:22:08 2026

@author: chad-briddon

Use SELCIE to compute the boundary values, and therefore the pressure on sensor
plate in the CANNEX experiment. Can use then plug the boundary values into
analytic equations to confirm them.

Files labelled only by numbers are using a vacuum gap of 50 um.

*This code ran using SELCIE v2.0.0.

"""

from _initalise import np, plt, mkdir, exists
from _initalise import n, Lambda_DE, M_pl
from _initalise import density_Al, density_vac, density_Pt, density_W
from _initalise import density_Si, density_Cu, density_SiO2, density, length
from _initalise import eV4_to_pN_per_cm2, density_scale, length_scale
from _initalise import length_unit, density_unit

# from Generate_Mesh import make_mesh
from SELCIE.Solvers import Chameleon
from SELCIE.Misc import alpha_calculator_chameleon


plt.rc('axes', labelsize=15)
plt.rc('legend', fontsize=15)


NoVac_Options = None

if NoVac_Options is None:
    pass

elif NoVac_Options == 1:
    density_vac *= 5e11

elif NoVac_Options == 2:
    density_vac *= 0

elif NoVac_Options == 3:
    density_vac *= 1e9


' --------------------------------------------------------------------------- '


log_beta = list(np.round(np.linspace(-1.0, 6.0, 141), 4))

i = 0
CANNEX_data0 = [(3.0000000000000000, 10.09024303543957100),
                (3.2393254869831290, 7.239265226328643000),
                (3.4977432035394953, 5.209746816906757000),
                (3.7767762353825017, 3.762123975244741500),
                (4.0780691726355770, 2.726937132507061500),
                (4.4033978028662080, 1.984441567560577600),
                (4.7546795773833400, 1.450062943850155800),
                (5.1339849124853420, 1.064043298534854200),
                (5.5435493922668740, 0.784126522542000400),
                (5.9857869449066390, 0.580416627413294250),
                (6.4633040700956520, 0.431703095079227900),
                (6.9789152014608790, 0.322856224000782670),
                (7.5356592945287405, 0.243029522294287660),
                (8.1368177379960860, 0.184404164598048070),
                (8.7859336938757110, 0.141312259088962540),
                (9.4868329805051400, 0.109620633779362030),
                (10.243646621500805, 0.086306098001573950),
                (11.060835193558726, 0.069152083210239560),
                (11.943215116604916, 0.056530489575896050),
                (12.895987041246831, 0.047243421645446780),
                (13.924766500838338, 0.040409825053424410),
                (15.035617008818167, 0.035381711990196174),
                (16.235085796393910, 0.031682156319832695),
                (17.530242401205530, 0.028960087581117610),
                (18.928720334405797, 0.026957237257455670),
                (20.438762071738836, 0.025483652537965060),
                (22.069267633789240, 0.024399480963449340),
                (23.829847041728447, 0.023601812867855470),
                (25.730876957726823, 0.023014949847032000),
                (27.783561843863803, 0.022583211440469780)][i:i+1]

# CANNEX_data0 = [(30, 0.022583211440469780), (35, 0.022583211440469780),
#                 (40, 0.022583211440469780), (45, 0.022583211440469780)]


'''
Note in paper "https://arxiv.org/pdf/2405.14638", Hauke uses 2*sigma as the
constraint. Above values are for 1*sigma, so must modify to get consistent
constraint.
'''
CANNEX_data = [(cd[0], 2*cd[1]) for cd in CANNEX_data0]


' -------------------------------------------------------------------------- '
' -------------------- Physical dimensionful parameters -------------------- '
' -------------------------------------------------------------------------- '

# Rescale densities.

rescaled_density_Al = density_Al / density_scale
rescaled_density_vac = density_vac / density_scale
rescaled_density_Pt = density_Pt / density_scale
rescaled_density_W = density_W / density_scale
rescaled_density_Si = density_Si / density_scale
rescaled_density_Cu = density_Cu / density_scale
rescaled_density_SiO2 = density_SiO2 / density_scale


' --------------------------------------------------------------------------- '
' ----------------------------- Setup functions ----------------------------- '
' --------------------------------------------------------------------------- '


def Al(x):
    return rescaled_density_Al


def vacuum(x):
    return rescaled_density_vac


def Pt(x):
    return rescaled_density_Pt


def W(x):
    return rescaled_density_W


def Si(x):
    return rescaled_density_Si


def Cu(x):
    return rescaled_density_Cu


def SiO2(x):
    return rescaled_density_SiO2


lower_plate = [Pt, W, SiO2, Cu, Al]
gap = [vacuum]
sensor_plate = [Pt, W, Pt, W, Si, W, Pt, vacuum, Al]

density_profile = lower_plate + gap + sensor_plate


' --------------------------------------------------------------------------- '
' --------------- Solve for the field and either save or plot --------------- '
' --------------------------------------------------------------------------- '

for gap_size, target_pressure in CANNEX_data:

    path = "Data/field/Boundary Data(_%.3fum)(1)" % gap_size
    meshname = "CANNEX(%.3fum)" % gap_size

    # Modify path if we are using a different vacuum value.
    if NoVac_Options is None:
        pass

    elif NoVac_Options == 1:
        path = "Data/field/Boundary Data(_%.3fum)(NoVac)(1)" % gap_size

    elif NoVac_Options == 2:
        path = "Data/field/Boundary Data(_%.3fum)(TrueVac)" % gap_size

    elif NoVac_Options == 3:
        path = "Data/field/Boundary Data(_%.3fum)(PartialVac)(1)" % gap_size

    # path = "Data/field/Boundary Data(_%.3fum)(Si1um)(1)" % gap_size
    # meshname = "CANNEX(%.3fum)(Si1um)" % gap_size

    # make_mesh(meshname, gap_size)

    if exists(path):
        pass
    else:
        mkdir(path)

    # Position of boundaries in um.
    boundary_pos_lower_plate = [-13000.37, -8000.37, -6000.37, -0.37, -0.07]
    boundary_pos_gap = [0, gap_size]

    sensor_plate_layer_thickness = [0.07, 0.3, 0.02, 5e-3, 100, 5e-3, 0.02,
                                    5e3, 3e3]

    # sensor_plate_layer_thickness = [0.07, 0.3, 0.02, 5e-3, 1, 5e-3, 0.02,
    #                                 5e3, 3e3]

    sensor_plate_boundary_pos = np.round(
        [sum(sensor_plate_layer_thickness[:i+1])
         for i in range(len(sensor_plate_layer_thickness))], 5)

    boundary_pos_sensor_plate = list(sensor_plate_boundary_pos + gap_size)

    boundary_pos = np.array(boundary_pos_lower_plate[1:] + boundary_pos_gap
                            + boundary_pos_sensor_plate[:-1])

    # Iterate over beta parameter.
    for lb in log_beta:

        name = path + "/LogB%.3f" % lb
        '''
        alpha_new = alpha_calculator_chameleon(n, M_pl/10**lb, Lambda_DE,
                                               p0=rescaled_density_vac,
                                               L=length_scale,
                                               p0_NonEVUnits=units.g/units.cm**3,
                                               L_NonEVUnits=units.um)

        comp_V = np.sqrt(alpha_new/2)
        print(comp_V)
        '''

        # Skip if needed.
        if len(log_beta) > 1 and exists(name) is True:
            continue

        print(name)

        beta = 10**lb
        M = M_pl/beta                                # eV
        VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

        # Get alpha and field scale.
        alpha = alpha_calculator_chameleon(n, M, Lambda_DE, p0=density_scale,
                                           L=length_scale,
                                           p0_NonEVUnits=density_unit,
                                           L_NonEVUnits=length_unit)

        s = Chameleon(alpha, n, mesh_name=meshname, dimension=1,
                      symmetry="translation symmetry")

        s.solve_static(density_profiles=density_profile, maxiter=100,
                       tol_du=5e-8)

        if len(log_beta) > 1:
            ' -------------- Record field values at boundaries -------------- '
            with open(name, "w") as tf:
                tf.write(str([s.field(xi, 0) for xi in boundary_pos]))

        else:

            ' ----------------- Make plot of field profile ----------------- '

            s.field.vector()[:] *= VEV  # Puts in units of eV.

            # Plot full field.
            X_min = -13000.37
            X_max = 8150.42

            X_full = np.linspace(X_min, X_max, 2115080)
            field_full = np.array([s.field(xi, 0) for xi in X_full])

            fig1, ax1 = plt.subplots(figsize=(8, 6))
            ax1.set_ylabel(r"$\phi / eV$")
            ax1.set_xlabel(r"$z/\mu m$")
            ax1.set_xlim([X_min, X_max])

            ax1.axvspan(X_min, 0, alpha=0.4)  # Fill in lower plate.
            ax1.axvspan(50, boundary_pos_sensor_plate[-3], alpha=0.4,
                        color='lightcoral')  # Fill in sensor plate.
            ax1.axvspan(boundary_pos_sensor_plate[-2], X_max, alpha=0.4,
                        color='lightcoral')  # Fill in sensor plate.

            ax1.plot(X_full, field_full)

            plt.show()

            if len(log_beta) == 1:
                fig1.savefig("Images/field_LogB%.3f(full).png" % lb,
                             dpi=300, bbox_inches='tight')

            # Plot field zoomed in onto a specific section.
            X2_min, X2_max = -20, 70
            X2_min, X2_max = -20, 180

            X_zoom = np.linspace(X2_min, X2_max, 9001)

            field_zoom = np.array([s.field(xi, 0) for xi in X_zoom])

            fig2, ax2 = plt.subplots(figsize=(8, 6))
            ax2.set_ylabel(r"$\phi / eV$")
            ax2.set_xlabel(r"$z/\mu m$")
            ax2.set_xlim([X2_min, X2_max])

            ax2.axvspan(X2_min, 0, alpha=0.4)  # Fill in lower plate.
            ax2.axvspan(50, min(X2_max, boundary_pos[-2]), alpha=0.4,
                        color='lightcoral')  # Fill in sensor plate.

            plt.plot(X_zoom, field_zoom)

            plt.show()

            # Make sure boundary conditions are correct
            VEV_Al = VEV/np.sqrt(rescaled_density_Al)
            print("Boundary values : %f and %f" % (field_full[1]/VEV_Al,
                                                   field_full[-1]/VEV_Al))

            if len(log_beta) == 1:
                fig2.savefig("Images/field_LogB%.3f(sensor).png" % lb,
                             dpi=300, bbox_inches='tight')

    # continue
    ' ---------------------------------------------------------------------- '
    ' ------------ Use save boundary values to compute pressure ------------ '
    ' ---------------------------------------------------------------------- '

    def calc_rescaled_pressure(boundary_values):
        boundary_values_sensor = np.array(boundary_values[5:-1])

        layer_density = [0] + [sp(0) for sp in sensor_plate[:-2]] + [0]

        p_diff = np.array([(p1 - p0) for p0, p1 in zip(layer_density[:-1],
                                                       layer_density[1:])])

        return abs(np.dot(boundary_values_sensor, p_diff))

    def calc_rescaled_pressure_approx(boundary_values):
        boundary_values_sensor = np.array(boundary_values[5:-1])

        thickness = np.array([0.07, 0.3, 0.02, 5e-3, 100, 5e-3, 0.02])
        layer_density = np.array([p(0) for p in sensor_plate[:-2]])

        p_mean = np.dot(thickness, layer_density)/np.sum(thickness)

        return abs(
            p_mean*(boundary_values_sensor[0] - boundary_values_sensor[-1]))

    # Make plot for fixed Lambda value.
    pressure = []
    pressure_apx = []

    for lb in log_beta:

        name = path + "/LogB%.3f" % lb

        beta = 10**lb
        M = M_pl/beta                                # eV
        VEV = np.sqrt((M*Lambda_DE**5)/density)      # eV

        C = VEV*density/M

        with open(name, "r") as txt_file:
            bv = np.array(eval(txt_file.read()))

        pressure.append(C*calc_rescaled_pressure(boundary_values=bv))
        pressure_apx.append(
            C*calc_rescaled_pressure_approx(boundary_values=bv))

    # Rescale pressure from natural units to pN/cm^2.
    pressure = eV4_to_pN_per_cm2*np.array(pressure)
    pressure_apx = eV4_to_pN_per_cm2*np.array(pressure_apx)

    # Plot pressure against beta (Lambda is fixed).
    fig3, ax3 = plt.subplots(figsize=(8, 6))
    ax3.set_ylabel(r"$|p_z| / \left( pN/cm^{-2} \right)$")
    ax3.set_xlabel(r"$Log(\beta)$")

    ax3.plot(log_beta, pressure, label="exact")
    ax3.plot(log_beta, pressure_apx, label="approx")

    fig3.legend()
    plt.show()

    ' ---------------------------------------------------------------------- '
    ' ---------------- Make constraint plots using pressure ---------------- '
    ' ---------------------------------------------------------------------- '

    U = (length**0.8)*(density**0.6)  # a constant.

    fig4, ax4 = plt.subplots(figsize=(8, 6))
    ax4.set_ylabel(r"$Log \left( \frac{\Lambda}{eV} \right)$")
    ax4.set_xlabel(r"$Log \left( \frac{M}{M_{PL}} \right)$")

    # ax4.set_ylim([-4, 1])
    # ax4.set_xlim([-18, 1])

    # ax4.axhline(y=np.log10(Lambda_DE))

    # target_pressure = [1, 1e-1, 1e-2, 1e-3, 1e-4]
    # target_pressure = [10]#[1e-3, 1e-4, 1e-5]
    eq_curves = []

    # for p2 in target_pressure:
    for p2 in [target_pressure]:
        eq_curves.append([])

        for lb, p1 in zip(log_beta, pressure):

            beta = 10**lb
            M1 = M_pl/beta                           # eV

            # Get alpha and field scale.
            alpha = alpha_calculator_chameleon(
                n, M1, Lambda_DE, p0=density_scale, L=length_scale,
                p0_NonEVUnits=density_unit, L_NonEVUnits=length_unit)

            M2 = M1*np.sqrt(p1/p2)
            Lambda2 = U*(alpha**0.4)/(M2**0.6)

            eq_curves[-1].append((M2, Lambda2))

    # Plot equal pressure curve.
    for eq_curve in eq_curves:
        X = np.array([np.log10(para[0]/M_pl) for para in eq_curve])
        Y = np.array([np.log10(para[1]) for para in eq_curve])

        ax4.plot(X, Y, color="blue", linestyle="solid")

    plt.show()

    ' ---------------------------------------------------------------------- '
    ' ------------- Calculate Compton wavelength inside sheild ------------- '
    ' ---------------------------------------------------------------------- '

    beta = 10**min(log_beta)
    beta = 10**(-0.5)
    M = M_pl/beta                               # eV

    alpha = alpha_calculator_chameleon(n, M, Lambda_DE, p0=rescaled_density_Al,
                                       L=1000,
                                       p0_NonEVUnits=density_unit,
                                       L_NonEVUnits=length_unit)

    Comp_mm = np.sqrt(alpha/2)

    ratio_Sheild_Comp_L = Comp_mm/3.0

    print(ratio_Sheild_Comp_L)
