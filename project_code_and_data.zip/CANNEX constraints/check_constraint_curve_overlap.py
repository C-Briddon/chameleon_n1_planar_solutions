#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul  3 14:56:28 2026

@author: chad-briddon

Check when contours overlap.

"""

from _initalise import np, plt, n, Lambda_DE, M_pl, Al, vac, Pt, W, Si
from _initalise import density, length, density_unit, length_unit
from _initalise import eV4_to_pN_per_cm2

from SELCIE.Misc import alpha_calculator_chameleon  # v2.0.0


plt.rc('axes', labelsize=15)
plt.rc('legend', fontsize=15)

' --------------------------------------------------------------------------- '
' --------------------------------------------------------------------------- '
'### Add CANNEX pressure sensitivity curves to plot ###'

log_beta_list = [list(np.round(np.linspace(-1.00, 6.0, 141), 4))[10:]
                 for i in range(30)]  # v..1


log_beta_list[0][77] = 3.351
log_beta_list[0][78] = 3.401
log_beta_list[0][31] = 1.060


for log_beta in log_beta_list:
    log_beta[0] = -0.49522391889673023


sensor_plate = [Pt, W, Pt, W, Si, W, Pt, vac, Al]


def calc_rescaled_pressure(boundary_values):
    boundary_values_sensor = np.array(boundary_values[5:-1])

    layer_density = [0] + [sp for sp in sensor_plate[:-2]] + [0]

    p_diff = np.array([(p1 - p0) for p0, p1 in zip(layer_density[:-1],
                                                   layer_density[1:])])

    return abs(np.dot(boundary_values_sensor, p_diff))


' -------------------------------------------------------------------------- '
' --------------------- Plot for different vacuum gaps --------------------- '
' -------------------------------------------------------------------------- '

CANNEX_data0 = [(3.0000000000000000, 10.09024303543957100),
                (3.2393254869831290, 7.239265226328643000),
                (3.4977432035394953, 5.209746816906757000),
                (3.7767762353825017, 3.762123975244741500),
                (4.0780691726355770, 2.726937132507061500),
                (4.4033978028662080, 1.984441567560577600),
                (4.7546795773833400, 1.450062943850155800),
                (5.1339849124853420, 1.064043298534854200),
                (5.5435493922668740, 0.784126522542000400),
                (5.9857869449066390, 0.580416627413294250),
                (6.4633040700956520, 0.431703095079227900),
                (6.9789152014608790, 0.322856224000782670),
                (7.5356592945287405, 0.243029522294287660),
                (8.1368177379960860, 0.184404164598048070),
                (8.7859336938757110, 0.141312259088962540),
                (9.4868329805051400, 0.109620633779362030),
                (10.243646621500805, 0.086306098001573950),
                (11.060835193558726, 0.069152083210239560),
                (11.943215116604916, 0.056530489575896050),
                (12.895987041246831, 0.047243421645446780),
                (13.924766500838338, 0.040409825053424410),
                (15.035617008818167, 0.035381711990196174),
                (16.235085796393910, 0.031682156319832695),
                (17.530242401205530, 0.028960087581117610),
                (18.928720334405797, 0.026957237257455670),
                (20.438762071738836, 0.025483652537965060),
                (22.069267633789240, 0.024399480963449340),
                (23.829847041728447, 0.023601812867855470),
                (25.730876957726823, 0.023014949847032000),
                (27.783561843863803, 0.022583211440469780)]


'''
Note in paper "https://arxiv.org/pdf/2405.14638", Hauke uses 2*sigma as the
constraint. Above values are for 1*sigma, so must modify to get consistent
constraint.
'''
CANNEX_data = [(cd[0], 2*cd[1]) for cd in CANNEX_data0]


folders = ["Data/field/Boundary Data(_%.3fum)(5)" % cd[0]
           for cd in CANNEX_data]
target_pressures = [cd[1] for cd in CANNEX_data]
eq_curves = []


for folder, target_pressure, log_beta in zip(folders, target_pressures,
                                             log_beta_list):

    pressure = []

    for lb in log_beta:
        name = folder + "/LogB%.3f" % lb

        beta = 10**lb
        M = M_pl/beta                                  # eV
        C = density/M

        with open(name, "r") as txt_file:
            bv = np.array(eval(txt_file.read()))

        pressure.append(C*calc_rescaled_pressure(boundary_values=bv))

    # Rescale pressure from natural units to pN/cm^2.
    pressure = eV4_to_pN_per_cm2*np.array(pressure)

    # Add constraint lines from pressure.
    U = (length**0.8)*(density**0.6)  # a constant.

    eq_curves.append([])

    for lb, p1 in zip(log_beta, pressure):

        beta = 10**lb
        M1 = M_pl/beta                           # eV

        # Get alpha and field scale.
        alpha = alpha_calculator_chameleon(
            n, M1, Lambda_DE, p0=1.0, L=1.0,
            p0_NonEVUnits=density_unit, L_NonEVUnits=length_unit)

        M2 = M1*np.sqrt(p1/target_pressure)
        Lambda2 = U*(alpha**0.4)/(M2**0.6)

        eq_curves[-1].append((M2, Lambda2))


' -------------------------------------------------------------------------- '
' ----------------------- Make coloured contour plot ----------------------- '
' -------------------------------------------------------------------------- '

fig3, ax3 = plt.subplots(figsize=(8, 6))


ax3.set_ylabel(r"$\Lambda / {\rm eV}$")
ax3.set_xlabel(r"$M / M_{\rm pl}$")


ax3.set_ylim([5.6e-3, 1e-2])
ax3.set_xlim([1e-6, 1e-2])

ax3.set_yscale('log')
ax3.set_xscale('log')


' --------------------- Add lines for choosen distances --------------------- '

# Plot for single slice (constant Compton wavelength).
fig2, ax2 = plt.subplots(figsize=(8, 6))

ax2.set_ylabel(r"$\Lambda / {\rm eV}$")
ax2.set_xlabel(r"$M / M_{\rm pl}$")

# ax2.set_yscale('log')
# ax2.set_xscale('log')

# ax2.set_ylim([1e-3, 3e-1])
# ax2.set_xlim([-3.5, -2.8])

Is = [25, 26]  # 57
Is = [25, 27]  # 51
Is = [25, 28]  # 47
Is = [25, 29]  # 44


X1 = np.array([np.log10(para[0]/M_pl) for para in eq_curves[Is[0]]])
Y1 = np.array([np.log10(para[1]) for para in eq_curves[Is[0]]])
ax2.plot(X1, Y1, color="red", linestyle="solid")


X2 = np.array([np.log10(para[0]/M_pl) for para in eq_curves[Is[1]]])
Y2 = np.array([np.log10(para[1]) for para in eq_curves[Is[1]]])
ax2.plot(X2, Y2, color="black", linestyle="solid")


fig3, ax3 = plt.subplots(figsize=(8, 6))

ax3.set_ylabel(r"$\delta \Lambda / {\rm eV}$")
ax3.set_xlabel(r"$M / M_{\rm pl}$")

dY = abs(Y1-Y2)

ax3.plot(X1, dY, color="black", linestyle="solid")

I_min = np.argmin(dY)

plt.axvline(X1[I_min], linestyle="dashed", color="red")


' --------------------------------------------------------------------------- '

fig4, ax4 = plt.subplots(figsize=(8, 6))

ax4.set_yscale('log')
ax4.set_xscale('log')


# Plot equal pressure curve.
gap_size1 = CANNEX_data[Is[0]][0]

X1 = np.array([para[0]/M_pl for para in eq_curves[Is[0]]])
Y1 = np.array([para[1] for para in eq_curves[Is[0]]])

ax4.plot(X1, Y1, color="black", linestyle="solid", linewidth=0.8)


# Plot equal pressure curve.
gap_size2 = CANNEX_data[Is[1]][0]

X2 = np.array([para[0]/M_pl for para in eq_curves[Is[1]]])
Y2 = np.array([para[1] for para in eq_curves[Is[1]]])

ax4.plot(X2, Y2, color="black", linestyle="solid", linewidth=0.8)

ax4.plot(X1[I_min], Y1[I_min], "r.")


print(I_min)
